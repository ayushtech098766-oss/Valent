import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '15mb' }));

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

// APIs
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok' });
});

app.post('/api/ocr', async (req, res) => {
  try {
    const { image } = req.body;
    if (!image) {
      return res.status(400).json({ error: 'Missing image' });
    }

    if (!process.env.GEMINI_API_KEY) {
      console.warn('GEMINI_API_KEY is not configured on the server, skipping auto-fill scanner.');
      return res.status(200).json({ amount: null, utr: null });
    }

    // Strip out base64 prefix if present
    let mimeType = 'image/png';
    let base64Data = image;
    if (image.startsWith('data:')) {
      const matches = image.match(/^data:([a-zA-Z0-9]+\/[a-zA-Z0-9-.+]+);base64,(.+)$/);
      if (matches && matches.length === 3) {
        mimeType = matches[1];
        base64Data = matches[2];
      }
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: [
        {
          inlineData: {
            mimeType,
            data: base64Data
          }
        },
        {
          text: `You are a high-fidelity UPI payment receipt analyzer. Your goal is 100% perfect, flawless extraction of the 12-digit numeric UTR code and payment amount.

Please inspect the provided payment receipt image and extract:

1. 'amount' (number): The bold successful transfer amount (e.g., if you see "₹1", return 1. If you see "₹500", return 500). Extract ONLY the numeric value as a float or integer, with no commas or symbols.

2. 'utr' (string): The UPI Unique Transaction Reference (UTR) or UPI Ref No.
   - **CRITICAL**: The UTR is ALWAYS exactly 12 pure consecutive digits (comprising only digits 0-9, such as '223933030912'). It must contain NO letters, spaces, or dashes.
   - **PREVENT ENDING DIGIT CONFUSION**: Be highly cautious of the final digits. For instance, in the user's PhonePe screenshot, the UTR is visible as "UTR: 223933030912" (where the last two digits are "12" [one, two]). 
     Do NOT confuse the ending digits '12' with '17' or '72'. A '1' is a straight vertical line, and a '2' has a curved top and flat horizontal base. Zoom in mentally on the digits and transcribe each of the 12 digits one-by-one (e.g., 2, 2, 3, 9, 3, 3, 0, 3, 0, 9, 1, 2) rather than guessing.
   - **DO NOT CONFUSE ALPHANUMERIC STRINGS**: Ignore alphanumeric strings like "T2606041433410793328391". NEVER extract a value starting with 'T'. Only extract the 12-digit numeric UTR.
   - Look next to or below the labels "UTR", "UPI Ref No", "Ref No", "Ref ID", "Reference No.", "UPI Transaction ID", or near the debited bank details layer. Check character-by-character meticulously.`
        }
      ],
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            amount: {
              type: Type.NUMBER,
              description: 'The payment amount successfully transferred as a float or integer'
            },
            utr: {
              type: Type.STRING,
              description: 'The 12-digit pure numeric UTR (Unique Transaction Reference) code. Never return alphanumeric values such as transaction IDs.'
            }
          }
        }
      }
    });

    const parsedJson = JSON.parse(response.text || '{}');
    res.json(parsedJson);
  } catch (error) {
    console.error('OCR Extraction failed:', error);
    res.status(500).json({ error: 'Failed to process screenshot' });
  }
});

async function main() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

main().catch(err => {
  console.error('Failed to start server:', err);
});
