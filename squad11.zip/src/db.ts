import { User, Match, MatchPlayer, MatchSubmission, MatchChatMsg, Transaction, PromoBanner, SupportMessage } from './types';
import { db, isConfigured } from './firebase';
import { doc, setDoc, deleteDoc, getDoc, collection, onSnapshot, getDocs, runTransaction } from 'firebase/firestore';

// Helper to prevent transaction hang on slow cellular connection or iframe/mobile web
const withTimeout = <T>(promise: Promise<T>, ms: number = 4000): Promise<T> => {
  return Promise.race([
    promise,
    new Promise<never>((_, reject) =>
      setTimeout(() => reject(new Error("Network timeout: Live database connection is unstable.")), ms)
    )
  ]);
};

// Storage Helper
const getJSON = <T>(key: string, defaultValue: T): T => {
  const item = localStorage.getItem(key);
  if (!item) return defaultValue;
  try {
    return JSON.parse(item) as T;
  } catch (e) {
    return defaultValue;
  }
};

const dispatchDbUpdate = () => {
  if (typeof window !== 'undefined') {
    setTimeout(() => {
      window.dispatchEvent(new Event('valent_db_update'));
    }, 0);
  }
};

const setJSON = (key: string, data: any) => {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (error: any) {
    console.warn('LocalStorage quota warning:', error);
  }
  dispatchDbUpdate();
};

// Seed default matches matching VALENT Lobby terminology
export const generateDefaultMatches = (): Match[] => {
  return [];
};

export const clearFirestoreCollection = async (collectionName: string) => {
  if (!isConfigured || !db) return;
  try {
    const colRef = collection(db, collectionName);
    const snapshot = await getDocs(colRef);
    const promises = snapshot.docs.map(docSnap => deleteDoc(doc(db, collectionName, docSnap.id)));
    await Promise.all(promises);
    console.log(`Successfully wiped Firestore collection: ${collectionName}`);
  } catch (err) {
    console.warn(`Failed to clean Firestore collection ${collectionName}:`, err);
  }
};

let isRemoteDatabaseSeeded = false;

export const initializeDB = () => {
  // Ensure basic user container exists
  if (!localStorage.getItem('valent_users')) {
    setJSON('valent_users', []);
    setJSON('valent_current_user', null);
  } else {
    // If the authorized owner exists, ensure they are always admin
    const users = getJSON<User[]>('valent_users', []);
    let updated = false;
    const mapped = users.map(u => {
      if (u.phone === '9260914905' && (!u.is_admin || u.role !== 'admin')) {
        u.is_admin = true;
        u.role = 'admin';
        updated = true;
      }
      return u;
    });
    if (updated) {
      setJSON('valent_users', mapped);
    }
  }

  // Pure zero-glitch system boot clean-up script
  const hasCleanedV4 = localStorage.getItem('valent_system_v4_accounts_cleaned') === 'true';
  if (!hasCleanedV4) {
    localStorage.setItem('valent_db_clearing', 'true');
    console.log("SYSTEM BOOT INITIATING CLOUD/OFFLINE USER ACCOUNT CLEANUP VERSION 4...");

    // Filter local users to keep the master owner account safe
    const localUsers = getJSON<User[]>('valent_users', []);
    const adminOwner = localUsers.find(u => u.phone === '9260914905');

    // Reset local lists to pristine state
    const prunedUsers = adminOwner ? [adminOwner] : [];
    setJSON('valent_users', prunedUsers);
    setJSON('valent_matches', []);
    setJSON('valent_transactions', []);
    setJSON('valent_support_messages', []);

    // Check if current user is not the owner, clear their session safely
    const currentUser = getJSON<User | null>('valent_current_user', null);
    if (currentUser && currentUser.phone !== '9260914905') {
      localStorage.removeItem('valent_current_user');
    }

    if (isConfigured && db) {
      Promise.all([
        clearFirestoreCollection('valent_users'),
        clearFirestoreCollection('valent_transactions'),
        clearFirestoreCollection('valent_support_messages'),
        clearFirestoreCollection('valent_matches')
      ]).then(() => {
        // Now sync the owner back if they exist to keep them safe on the cloud
        if (adminOwner) {
          syncItemToFirestore('valent_users', adminOwner.id, adminOwner);
        }
        localStorage.setItem('valent_db_clearing', 'false');
        localStorage.setItem('valent_system_v4_accounts_cleaned', 'true');
        console.log("SYSTEM USER SWEEP AND DATABASE PURGE SCRIPT COMPLETED SUCCESSFULLY!");
        window.dispatchEvent(new Event('valent_db_update'));
      }).catch(err => {
        console.error("Firestore cleanup task failed:", err);
        localStorage.setItem('valent_db_clearing', 'false');
        localStorage.setItem('valent_system_v4_accounts_cleaned', 'true');
      });
    } else {
      localStorage.setItem('valent_db_clearing', 'false');
      localStorage.setItem('valent_system_v4_accounts_cleaned', 'true');
    }
  }

  // Ensure matches container exists
  if (!localStorage.getItem('valent_matches')) {
    setJSON('valent_matches', []);
  }

  // Ensure banners are seeded ONLY ONCE locally!
  if (!localStorage.getItem('valent_banners_seeded_v1')) {
    const banners = getJSON<PromoBanner[]>('valent_promo_banners', []);
    if (banners.length === 0) {
      const defaultBanners: PromoBanner[] = [
        {
          id: 'banner-1',
          imageUrl: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=800&q=80',
          title: '🔥 Welcome to VALENT: High-Octane Direct Wagering Lobbies!',
          linkUrl: '',
          active: true,
          created_at: new Date().toISOString()
        },
        {
          id: 'banner-2',
          imageUrl: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=800&q=80',
          title: '⚡ Instant UPI deposit protection and 100% automated payouts!',
          linkUrl: '',
          active: true,
          created_at: new Date().toISOString()
        }
      ];
      setJSON('valent_promo_banners', defaultBanners);
    }
    localStorage.setItem('valent_banners_seeded_v1', 'true');
  }

  // Transactions
  if (!localStorage.getItem('valent_transactions')) {
    setJSON('valent_transactions', []);
  }

  // Admin Payments
  if (!localStorage.getItem('valent_admin_payment_settings')) {
    setJSON('valent_admin_payment_settings', {
      upiId: 'valent.pay@okaxis',
      qrCodeUrl: ''
    });
  }

  // Support Messages Init
  if (!localStorage.getItem('valent_support_messages')) {
    setJSON('valent_support_messages', []);
  }

  localStorage.setItem('valent_seeded_v1_total_wipe', 'true');
  localStorage.setItem('valent_seeded', 'true');
  localStorage.setItem('valent_matches_seeded_v1', 'true');

  // Sync firestore
  if (isConfigured && db) {
    setupCollectionSync('valent_matches', 'valent_matches');
    setupCollectionSync('valent_users', 'valent_users');
    setupCollectionSync('valent_transactions', 'valent_transactions');
    setupCollectionSync('valent_promo_banners', 'valent_promo_banners');
    setupCollectionSync('valent_support_messages', 'valent_support_messages');

    // Get system setup state to see if remote DB is empty/unseeded
    getDoc(doc(db, 'settings', 'system_state')).then((snap) => {
      if (snap.exists() && snap.data().seeded) {
        isRemoteDatabaseSeeded = true;
      } else {
        // Not remote seeded yet! This is a fresh blank database.
        // We only seed promotional banners to keep it clean and prevent resuscitating deleted matches or players!
        console.log("Empty or unseeded remote database detected. Seeding only initial promo banners to Firestore...");
        const localBanners = getJSON<PromoBanner[]>('valent_promo_banners', []);
        
        localBanners.forEach(b => syncItemToFirestore('valent_promo_banners', b.id, b));
        
        setDoc(doc(db, 'settings', 'system_state'), { seeded: true }).then(() => {
          isRemoteDatabaseSeeded = true;
          window.dispatchEvent(new Event('valent_db_update'));
        }).catch(err => {
          console.warn("Error marking remote database as seeded:", err);
          isRemoteDatabaseSeeded = true;
        });
      }
    }).catch(err => {
      console.warn("Error checking system_state in firebase:", err);
      // Fallback in case of temporary issues
      isRemoteDatabaseSeeded = true;
    });

    // Sync global rules bi-directionally inside valent_global_configurations/rules
    try {
      onSnapshot(doc(db, 'valent_global_configurations', 'rules'), (snapshot) => {
        if (snapshot.exists()) {
          const remoteValue = snapshot.data().value || '';
          const localValue = localStorage.getItem('valent_global_rules') || '';
          if (remoteValue !== localValue) {
            localStorage.setItem('valent_global_rules', remoteValue);
            window.dispatchEvent(new Event('valent_db_update'));
          }
        } else {
          const localValue = localStorage.getItem('valent_global_rules') || '';
          if (localValue) {
            setDoc(doc(db, 'valent_global_configurations', 'rules'), { value: localValue }).catch(err => {
              console.warn('Failed pushing initial local rules:', err);
            });
          }
        }
      });
    } catch (e) {
      console.warn('Failed rules snapshot sink:', e);
    }

    // Sync admin payment settings bi-directionally
    try {
      onSnapshot(doc(db, 'settings', 'payment_settings'), (snapshot) => {
        if (snapshot.exists()) {
          const remoteSettings = snapshot.data() as PaymentSettings;
          const localSettings = getAdminPaymentSettings();
          if (JSON.stringify(remoteSettings) !== JSON.stringify(localSettings)) {
            setJSON('valent_admin_payment_settings', remoteSettings);
          }
        } else {
          const localSettings = getAdminPaymentSettings();
          if (localSettings) {
            setDoc(doc(db, 'settings', 'payment_settings'), JSON.parse(JSON.stringify(localSettings))).catch(err => {
              console.warn('Failed pushing initial local payment settings:', err);
            });
          }
        }
      });
    } catch (e) {
      console.warn('Failed payment settings snapshot sink:', e);
    }
  }
};

// Listeners helper for real-time updates
const setupCollectionSync = (collectionName: string, localStorageKey: string) => {
  if (!isConfigured || !db) return;
  try {
    onSnapshot(collection(db, collectionName), (snapshot) => {
      // If the database is active in a full wipe, ignore remote items to prevent a sync deadlock
      if (localStorage.getItem('valent_db_clearing') === 'true') {
        console.log(`Skipping onSnapshot sync for ${collectionName} due to active database clearing.`);
        return;
      }

      // Cooldown prevention during local saves to avoid snapshot race-conditions throwing away local edits!
      const lastWriteTime = parseInt(localStorage.getItem(`valent_last_write_${localStorageKey}`) || '0', 10);
      if (Date.now() - lastWriteTime < 3500) {
        return;
      }

      const remoteData: any[] = [];
      snapshot.docs.forEach((docSnap) => {
        remoteData.push({ ...docSnap.data(), id: docSnap.id });
      });

      const localData = getJSON<any[]>(localStorageKey, []);

      // Sort both datasets identically so comparison is order-independent and stable
      const sortedRemote = [...remoteData];
      const sortedLocal = [...localData];

      if (collectionName === 'valent_matches') {
        const sortFn = (a: any, b: any) => {
          const getIdNum = (idStr: string) => {
            const numStr = (idStr || '').replace('ematch-', '');
            const val = parseInt(numStr, 10);
            return isNaN(val) ? 0 : val;
          };
          const valA = getIdNum(a.id);
          const valB = getIdNum(b.id);
          if (valA > 100000 || valB > 100000) {
            return valB - valA;
          }
          return valA - valB;
        };
        sortedRemote.sort(sortFn);
        sortedLocal.sort(sortFn);
      } else if (collectionName === 'valent_transactions') {
        const sortFn = (a: any, b: any) => new Date(b.created_at || 0).getTime() - new Date(a.created_at || 0).getTime();
        sortedRemote.sort(sortFn);
        sortedLocal.sort(sortFn);
      } else {
        const sortFn = (a: any, b: any) => (a.id || '').localeCompare(b.id || '');
        sortedRemote.sort(sortFn);
        sortedLocal.sort(sortFn);
      }

      if (JSON.stringify(sortedLocal) !== JSON.stringify(sortedRemote)) {
        // Write the consistently sorted data back to ensure stability
        localStorage.setItem(localStorageKey, JSON.stringify(sortedRemote));
        window.dispatchEvent(new Event('valent_db_update'));
      }
    });
  } catch (err) {
    console.warn(`Failed syncing collection: ${collectionName}`, err);
  }
};

const syncItemToFirestore = async (collectionName: string, id: string, item: any) => {
  if (!isConfigured || !db) return;
  try {
    await setDoc(doc(db, collectionName, id), JSON.parse(JSON.stringify(item)));
  } catch (e) {
    console.warn(`Failed syncing item to firestore ${collectionName}/${id}:`, e);
  }
};

const deleteItemFromFirestore = async (collectionName: string, id: string) => {
  if (!isConfigured || !db) return;
  try {
    await deleteDoc(doc(db, collectionName, id));
  } catch (e) {
    console.warn(`Failed deleting item from firestore ${collectionName}/${id}:`, e);
  }
};

// Core match operations
export const getMatches = (): Match[] => {
  return getJSON<Match[]>('valent_matches', []);
};

export const saveMatches = (matches: Match[]) => {
  const oldMatches = getMatches();
  setJSON('valent_matches', matches);
  localStorage.setItem('valent_last_write_valent_matches', Date.now().toString());

  if (isConfigured && db) {
    // Find changed on live firestore
    matches.forEach(m => {
      syncItemToFirestore('valent_matches', m.id, m);
    });
    const oldIds = oldMatches.map(o => o.id);
    const newIds = new Set(matches.map(n => n.id));
    oldIds.filter(id => !newIds.has(id)).forEach(deletedId => {
      deleteItemFromFirestore('valent_matches', deletedId);
    });
  }
  window.dispatchEvent(new Event('valent_db_update'));
};

// Users data persistence
export const getUsers = (): User[] => {
  const users = getJSON<User[]>('valent_users', []);
  let updated = false;
  const mapped = users.map(u => {
    if (u.phone === '9260914905') {
      if (!u.is_admin || u.role !== 'admin') {
        u.is_admin = true;
        u.role = 'admin';
        updated = true;
      }
    } else {
      // Security override: demote any other user if they have the admin role
      if (u.role === 'admin') {
        u.role = 'player';
        u.is_admin = false;
        updated = true;
      } else if (u.role === 'wallet_manager' || u.role === 'chat_manager') {
        if (!u.is_admin) {
          u.is_admin = true;
          updated = true;
        }
      } else if (u.is_admin) {
        u.is_admin = false;
        updated = true;
      }
    }
    return u;
  });
  if (updated) {
    setJSON('valent_users', mapped);
  }
  return mapped;
};

export const saveUsers = (users: User[]) => {
  const mapped = users.map(u => {
    if (u.phone === '9260914905') {
      u.is_admin = true;
      u.role = 'admin';
    } else {
      if (u.role === 'admin') {
        u.role = 'player';
      }
      if (u.role === 'wallet_manager' || u.role === 'chat_manager') {
        u.is_admin = true;
      } else {
        u.is_admin = false;
      }
    }
    return u;
  });
  setJSON('valent_users', mapped);

  // Sync currently logged in user to avoid stale user balances or profile info
  const liveUser = getJSON<User | null>('valent_current_user', null);
  if (liveUser) {
    const updatedCurrentUser = mapped.find(u => u.id === liveUser.id);
    if (updatedCurrentUser) {
      setJSON('valent_current_user', updatedCurrentUser);
    }
  }

  localStorage.setItem('valent_last_write_valent_users', Date.now().toString());
  if (isConfigured && db) {
    mapped.forEach(u => {
      syncItemToFirestore('valent_users', u.id, u);
    });
  }
  window.dispatchEvent(new Event('valent_db_update'));
};

export const getCurrentUser = (): User | null => {
  let user = getJSON<User | null>('valent_current_user', null);
  if (user) {
    // Lookup latest user from the full users collection
    const allUsers = getJSON<User[]>('valent_users', []);
    const latestUser = allUsers.find(u => u.id === user.id);
    if (latestUser) {
      // If balance, role, or credentials changed, sync them in real time
      if (
        user.username !== latestUser.username ||
        JSON.stringify(user.wallet) !== JSON.stringify(latestUser.wallet) ||
        user.role !== latestUser.role ||
        user.is_admin !== latestUser.is_admin ||
        user.isBanned !== latestUser.isBanned ||
        user.ign !== latestUser.ign
      ) {
        user = { ...user, ...latestUser };
        setJSON('valent_current_user', user);
      }
    }

    if (user.phone === '9260914905') {
      if (!user.is_admin || user.role !== 'admin') {
        user.is_admin = true;
        user.role = 'admin';
        setJSON('valent_current_user', user);
      }
    } else {
      if (user.role === 'admin') {
        user.role = 'player';
        user.is_admin = false;
        setJSON('valent_current_user', user);
      } else if (user.role === 'wallet_manager' || user.role === 'chat_manager' || user.role === 'rules_manager') {
        if (!user.is_admin) {
          user.is_admin = true;
          setJSON('valent_current_user', user);
        }
      } else if (user.is_admin) {
        user.is_admin = false;
        setJSON('valent_current_user', user);
      }
    }
  }
  return user;
};

export const setCurrentUser = (user: User | null) => {
  setJSON('valent_current_user', user);
  if (user) {
    // Also save in full user array lists
    const users = getUsers();
    const idx = users.findIndex(u => u.id === user.id);
    if (idx !== -1) {
      users[idx] = user;
      saveUsers(users);
    }
  }
};

export const getTransactions = (): Transaction[] => {
  return getJSON<Transaction[]>('valent_transactions', []);
};

export const saveTransactions = (txs: Transaction[]) => {
  setJSON('valent_transactions', txs);
  localStorage.setItem('valent_last_write_valent_transactions', Date.now().toString());
  if (isConfigured && db) {
    txs.forEach(t => {
      syncItemToFirestore('valent_transactions', t.id, t);
    });
  }
  window.dispatchEvent(new Event('valent_db_update'));
};

export interface PaymentSettings {
  upiId: string;
  qrCodeUrl: string;
  whatsappGroupUrl?: string;
}

export const getAdminPaymentSettings = (): PaymentSettings => {
  return getJSON<PaymentSettings>('valent_admin_payment_settings', {
    upiId: '',
    qrCodeUrl: '',
    whatsappGroupUrl: ''
  });
};

export const saveAdminPaymentSettings = (settings: PaymentSettings) => {
  setJSON('valent_admin_payment_settings', settings);
  if (isConfigured && db) {
    setDoc(doc(db, 'settings', 'payment_settings'), JSON.parse(JSON.stringify(settings))).catch(err => {
      console.warn('Failed syncing payment settings to firestore:', err);
    });
  }
};

export const getGlobalRules = (): string => {
  return localStorage.getItem('valent_global_rules') || '';
};

export const saveGlobalRules = (rules: string) => {
  localStorage.setItem('valent_global_rules', rules);
  if (isConfigured && db) {
    setDoc(doc(db, 'valent_global_configurations', 'rules'), { value: rules }).catch(err => {
      console.warn('Failed syncing rules to firestore:', err);
    });
  }
  window.dispatchEvent(new Event('valent_db_update'));
};

export const getPromoBanners = (): PromoBanner[] => {
  return getJSON<PromoBanner[]>('valent_promo_banners', []);
};

export const savePromoBanners = (banners: PromoBanner[]) => {
  const oldBanners = getPromoBanners();
  setJSON('valent_promo_banners', banners);
  localStorage.setItem('valent_last_write_valent_promo_banners', Date.now().toString());

  if (isConfigured && db) {
    banners.forEach(b => {
      syncItemToFirestore('valent_promo_banners', b.id, b);
    });
    const oldIds = oldBanners.map(o => o.id);
    const newIds = new Set(banners.map(n => n.id));
    oldIds.filter(id => !newIds.has(id)).forEach(deletedId => {
      deleteItemFromFirestore('valent_promo_banners', deletedId);
    });
  }
  window.dispatchEvent(new Event('valent_db_update'));
};

export const resetDatabase = () => {
  localStorage.removeItem('valent_seeded_v1_total_wipe');
  localStorage.removeItem('valent_users');
  localStorage.removeItem('valent_current_user');
  localStorage.removeItem('valent_matches');
  localStorage.removeItem('valent_promo_banners');
  localStorage.removeItem('valent_transactions');
  localStorage.removeItem('valent_admin_payment_settings');
  localStorage.removeItem('valent_support_messages');
  initializeDB();
};

export const devWipeAllDatabase = async () => {
  // Lock sync listeners during deletion to prevent any race state updates
  localStorage.setItem('valent_db_clearing', 'true');
  
  localStorage.clear();
  
  if (isConfigured && db) {
    try {
      await Promise.all([
        clearFirestoreCollection('valent_users'),
        clearFirestoreCollection('valent_transactions'),
        clearFirestoreCollection('valent_support_messages'),
        clearFirestoreCollection('valent_matches')
      ]);
      
      // Reseed default matches directly to Firestore
      const defaultMatches = generateDefaultMatches();
      for (const m of defaultMatches) {
        await setDoc(doc(db, 'valent_matches', m.id), m);
      }
      
      // Reset remote system_state seed lock
      await setDoc(doc(db, 'settings', 'system_state'), { seeded: true });
    } catch (e) {
      console.error("Error during Firestore developer database wipe:", e);
    }
  }
  
  localStorage.setItem('valent_db_clearing', 'false');
  localStorage.setItem('valent_seeded_v1_total_wipe', 'true');
  localStorage.setItem('valent_seeded', 'true');
  localStorage.setItem('valent_matches_seeded_v1', 'true');
  
  // Reload browser to initialize fresh state beautifully
  window.location.reload();
};

export const forceSyncAll = async () => {
  if (!isConfigured || !db) return;
  try {
    getMatches().forEach(m => syncItemToFirestore('valent_matches', m.id, m));
    getUsers().forEach(u => syncItemToFirestore('valent_users', u.id, u));
    getTransactions().forEach(t => syncItemToFirestore('valent_transactions', t.id, t));
    getPromoBanners().forEach(b => syncItemToFirestore('valent_promo_banners', b.id, b));
    getSupportMessages().forEach(m => syncItemToFirestore('valent_support_messages', m.id, m));
    window.dispatchEvent(new Event('valent_db_update'));
  } catch (e) {
    console.error('Manual force sync failed:', e);
  }
};

export const getSupportMessages = (): SupportMessage[] => {
  return getJSON<SupportMessage[]>('valent_support_messages', []);
};

export const saveSupportMessages = (messages: SupportMessage[]) => {
  setJSON('valent_support_messages', messages);
  localStorage.setItem('valent_last_write_valent_support_messages', Date.now().toString());
  if (isConfigured && db) {
    messages.forEach(m => {
      syncItemToFirestore('valent_support_messages', m.id, m);
    });
  }
  window.dispatchEvent(new Event('valent_db_update'));
};

export const isQuotaExceeded = () => false;
export const setQuotaExceeded = (val: boolean) => {};

/**
 * Concurrent Conflict Prevention Atomic Join Match Transaction
 */
export const joinMatchAtomic = async (
  matchId: string, 
  userId: string, 
  ign: string, 
  level: number,
  allocatedTeam: 'A' | 'B',
  assignedPosition: number
): Promise<{ success: boolean; error?: string; updatedUser?: User; updatedMatch?: Match }> => {
  if (!isConfigured || !db) {
    return { success: false, error: "Database offline fallback." };
  }

  const matchRef = doc(db, 'valent_matches', matchId);
  const userRef = doc(db, 'valent_users', userId);

  try {
    const result = await withTimeout(runTransaction(db, async (transaction) => {
      // 1. Fetch live Match and User doc
      const matchSnap = await transaction.get(matchRef);
      if (!matchSnap.exists()) {
        throw new Error("Esports combat lobby is not alive in remote logs.");
      }
      const match = matchSnap.data() as Match;

      const userSnap = await transaction.get(userRef);
      if (!userSnap.exists()) {
        throw new Error("Competitor identity profile is missing on remote check.");
      }
      const user = userSnap.data() as User;

      // 2. Race condition checks
      const players = match.players || [];
      if (players.some((p: any) => p.userId === userId)) {
        throw new Error("Lobby lock failure: You have already registered inside this room!");
      }

      if (match.spotsFilled >= match.spotsTotal) {
        throw new Error("Slot Already Taken: This custom room is fully occupied!");
      }

      if (players.some((p: any) => p.team === allocatedTeam && p.position === assignedPosition)) {
        throw new Error("Slot Already Taken: Another competitor just booked this exact grid layout!");
      }

      // Wallet priority checks
      const cost = match.entryFee;
      let deposit = user.wallet?.deposit || 0;
      let winnings = user.wallet?.winnings || 0;
      const bonus = user.wallet?.bonus || 0;
      const totalBalance = deposit + winnings;

      if (totalBalance < cost) {
        throw new Error("Insufficient Balance to register inside this esports arena!");
      }

      // Deduct prioritization
      if (deposit >= cost) {
        deposit -= cost;
      } else {
        const carry = cost - deposit;
        deposit = 0;
        winnings -= carry;
      }

      // Construct profiles
      const updatedUser = { ...user };
      updatedUser.ign = ign;
      updatedUser.wallet = { deposit, winnings, bonus };

      let referralTx: any = null;
      let inviterUpdate: any = null;

      if (!updatedUser.hasJoinedFirstGame) {
        updatedUser.hasJoinedFirstGame = true;
        if (updatedUser.referredByUserId) {
          const inviterRef = doc(db, 'valent_users', updatedUser.referredByUserId);
          const inviterSnap = await transaction.get(inviterRef);
          if (inviterSnap.exists()) {
            const inviter = inviterSnap.data() as User;
            const newDeposit = (inviter.wallet?.deposit || 0) + 25;
            
            inviterUpdate = {
              ref: inviterRef,
              data: {
                ...inviter,
                wallet: {
                  ...(inviter.wallet || { deposit: 0, winnings: 0, bonus: 0 }),
                  deposit: newDeposit
                }
              }
            };

            const referralTxId = `tx-referral-reward-${Date.now()}`;
            referralTx = {
              ref: doc(db, 'valent_transactions', referralTxId),
              data: {
                id: referralTxId,
                userId: inviter.id,
                type: 'deposit',
                amount: 25,
                status: 'approved',
                created_at: new Date().toISOString(),
                matchTitle: "Referral Reward",
                note: `Referral Reward: @${user.username} entered first esports match!`
              }
            };
            updatedUser.isReferralRewardPaid = true;
          }
        }
      }

      // Main registration withdrawal ticket
      const joinTxId = `tx-entry-${Date.now()}`;
      const joinTx = {
        ref: doc(db, 'valent_transactions', joinTxId),
        data: {
          id: joinTxId,
          userId: user.id,
          type: 'withdrawal',
          amount: cost,
          status: 'approved',
          created_at: new Date().toISOString(),
          matchId: match.id,
          matchTitle: match.title
        }
      };

      // Populate roster entries
      const newPlayer: MatchPlayer = {
        userId: user.id,
        username: user.username,
        ign: ign,
        level: level,
        team: allocatedTeam,
        status: 'READY',
        position: assignedPosition
      };

      const updatedPlayers = [...players, newPlayer];
      const nextSpotsFilled = match.spotsFilled + 1;
      let nextStatus = match.status;
      if (nextSpotsFilled >= match.spotsTotal && nextStatus === 'PENDING_START') {
        nextStatus = 'ROOM_READY';
      }

      const updatedMatch = {
        ...match,
        players: updatedPlayers,
        spotsFilled: nextSpotsFilled,
        status: nextStatus
      };

      // 3. Command writes atomic sync
      transaction.update(userRef, {
        ign: updatedUser.ign,
        wallet: updatedUser.wallet,
        hasJoinedFirstGame: updatedUser.hasJoinedFirstGame,
        isReferralRewardPaid: updatedUser.isReferralRewardPaid || false
      });
      transaction.update(matchRef, {
        players: updatedMatch.players,
        spotsFilled: updatedMatch.spotsFilled,
        status: updatedMatch.status
      });
      transaction.set(joinTx.ref, joinTx.data);
      if (inviterUpdate) {
        transaction.update(inviterUpdate.ref, {
          wallet: inviterUpdate.data.wallet
        });
      }
      if (referralTx) {
        transaction.set(referralTx.ref, referralTx.data);
      }

      return { updatedUser, updatedMatch };
    }), 4000);

    return { 
      success: true, 
      updatedUser: result.updatedUser, 
      updatedMatch: result.updatedMatch 
    };
  } catch (err: any) {
    console.error("Atomic transaction safety abort:", err);
    return { success: false, error: err.message || String(err) };
  }
};

/**
 * Concurrent Conflict Prevention Atomic Teammate Reservation transaction
 */
export const reserveTeammateAtomic = async (
  matchId: string,
  captainId: string,
  teammateIgn: string,
  teammateLevel: number,
  myTeam: 'A' | 'B',
  teammatePosition: number
): Promise<{ success: boolean; error?: string; updatedUser?: User; updatedMatch?: Match }> => {
  if (!isConfigured || !db) {
    return { success: false, error: "Database offline fallback." };
  }

  const matchRef = doc(db, 'valent_matches', matchId);
  const userRef = doc(db, 'valent_users', captainId);

  try {
    const result = await withTimeout(runTransaction(db, async (transaction) => {
      // 1. Fetch live states
      const matchSnap = await transaction.get(matchRef);
      if (!matchSnap.exists()) {
        throw new Error("Lobby room not found inside records.");
      }
      const match = matchSnap.data() as Match;

      const userSnap = await transaction.get(userRef);
      if (!userSnap.exists()) {
        throw new Error("Captain profile not found.");
      }
      const user = userSnap.data() as User;

      const players = match.players || [];
      const currentTeamCount = players.filter((p: any) => p.team === myTeam).length;
      if (currentTeamCount >= (match.spotsTotal / 2)) {
        throw new Error("Slot Already Taken: This squad roster team is already full!");
      }

      const cost = match.entryFee;
      let deposit = user.wallet?.deposit || 0;
      let winnings = user.wallet?.winnings || 0;
      const bonus = user.wallet?.bonus || 0;
      const totalBalance = deposit + winnings;

      if (totalBalance < cost) {
        throw new Error("Insufficient Balance! Teammate reservation wagers cannot be processed.");
      }

      if (players.some((p: any) => p.team === myTeam && p.position === teammatePosition)) {
        throw new Error("Slot Already Taken: Another team participant has claimed this grid coordinate.");
      }

      // Deduct reservation priority cash
      if (deposit >= cost) {
        deposit -= cost;
      } else {
        const carry = cost - deposit;
        deposit = 0;
        winnings -= carry;
      }

      const updatedUser = {
        ...user,
        wallet: { deposit, winnings, bonus }
      };

      const reservedPlayerId = `reserved-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
      const reservedPlayer: MatchPlayer = {
        userId: reservedPlayerId,
        username: `${user.username}'s Teammate`,
        ign: teammateIgn,
        level: teammateLevel,
        team: myTeam,
        status: 'READY',
        position: teammatePosition
      };

      const updatedPlayers = [...players, reservedPlayer];
      const nextSpotsFilled = match.spotsFilled + 1;
      let nextStatus = match.status;
      if (nextSpotsFilled >= match.spotsTotal && nextStatus === 'PENDING_START') {
        nextStatus = 'ROOM_READY';
      }

      const updatedMatch = {
        ...match,
        players: updatedPlayers,
        spotsFilled: nextSpotsFilled,
        status: nextStatus
      };

      const reserveTxId = `tx-reserve-${Date.now()}`;
      const reserveTx = {
        ref: doc(db, 'valent_transactions', reserveTxId),
        data: {
          id: reserveTxId,
          userId: user.id,
          type: 'withdrawal',
          amount: cost,
          status: 'approved',
          created_at: new Date().toISOString(),
          matchId: match.id,
          matchTitle: `${match.title} (Teammate slot reserved)`
        }
      };

      // 2. Commit transaction updates
      transaction.update(userRef, {
        wallet: updatedUser.wallet
      });
      transaction.update(matchRef, {
        players: updatedMatch.players,
        spotsFilled: updatedMatch.spotsFilled,
        status: updatedMatch.status
      });
      transaction.set(reserveTx.ref, reserveTx.data);

      return { updatedUser, updatedMatch };
    }), 4000);

    return {
      success: true,
      updatedUser: result.updatedUser,
      updatedMatch: result.updatedMatch
    };
  } catch (err: any) {
    console.error("Reserve teammate atomic failed:", err);
    return { success: false, error: err.message || String(err) };
  }
};
