import React, { useState, useEffect } from 'react';
import { Match, MatchFormat, User, PromoBanner } from '../types';
import { getMatches, getCurrentUser, getPromoBanners, saveMatches, getGlobalRules } from '../db';
import {
  Flame,
  Award,
  Users,
  Layers,
  MapPin,
  Coins,
  ArrowRight,
  Sparkles,
  PlayCircle,
  Clock,
  ShieldCheck,
  ShieldAlert,
  X,
} from 'lucide-react';

interface HomeFeedProps {
  onSelectMatch: (match: Match) => void;
  onNavigateToWallet: () => void;
}

export default function HomeFeed({ onSelectMatch, onNavigateToWallet }: HomeFeedProps) {
  const [currentUser, setLocalCurrentUser] = useState<User | null>(() => getCurrentUser());
  const [matches, setMatches] = useState<Match[]>([]);
  const [banners, setBanners] = useState<PromoBanner[]>([]);
  const [globalRules, setGlobalRules] = useState<string>('');
  const [showRulesOverlay, setShowRulesOverlay] = useState<boolean>(false);
  const [currentBannerIdx, setCurrentBannerIdx] = useState<number>(0);
  const [selectedFormat, setSelectedFormat] = useState<MatchFormat | 'ALL' | 'teamvsteam'>('ALL');
  const [tick, setTick] = useState<number>(0);

  useEffect(() => {
    const reload = () => {
      setLocalCurrentUser(getCurrentUser());
      setMatches(getMatches());
      setBanners(getPromoBanners().filter((b) => b.active !== false));
      setGlobalRules(getGlobalRules());
    };
    reload();
    window.addEventListener('valent_db_update', reload);
    
    const interval = setInterval(() => {
      setTick((t) => t + 1);

      // Auto-live and auto-reveal transition evaluator when countdown reaches 0
      const currentMatches = getMatches();
      let changed = false;
      const nowMs = Date.now();
      const updated = currentMatches.map(m => {
        let matchCopy = { ...m };
        let localChanged = false;

        // Auto-live transition (Starts in reaches 0)
        if (matchCopy.status !== 'LIVE' && matchCopy.status !== 'COMPLETED' && matchCopy.matchStartTime) {
          const startTimeMs = new Date(matchCopy.matchStartTime).getTime();
          if (nowMs >= startTimeMs) {
            localChanged = true;
            matchCopy.status = 'LIVE' as const;
          }
        }

        // Auto-room reveal transition (Reveal ends & credentials exist)
        if (matchCopy.status === 'PENDING_START' && matchCopy.roomId && matchCopy.roomPassword && matchCopy.credentialsRevealTime) {
          const revealTimeMs = new Date(matchCopy.credentialsRevealTime).getTime();
          if (nowMs >= revealTimeMs) {
            localChanged = true;
            matchCopy.status = 'ROOM_READY' as const;
          }
        }

        if (localChanged) {
          changed = true;
          return matchCopy;
        }
        return m;
      });

      if (changed) {
        saveMatches(updated);
        window.dispatchEvent(new Event('valent_db_update'));
      }
    }, 1000);

    return () => {
      window.removeEventListener('valent_db_update', reload);
      clearInterval(interval);
    };
  }, []);

  // Combined wallet balances calculator (Deposit and Winnings)
  const totalCombinedBalance = currentUser
    ? Math.max(0, currentUser.wallet.deposit) + Math.max(0, currentUser.wallet.winnings)
    : 0;

  // Filter matches based on the selected squad format
  const filteredMatches = matches.filter(m => {
    if (selectedFormat === 'ALL') return true;
    if (selectedFormat === 'teamvsteam') {
      return m.format_type === 'teamvsteam4v4' || m.format_type === 'teamvsteam6v6';
    }
    return m.format_type === selectedFormat;
  });

  const formats: { key: MatchFormat | 'ALL' | 'teamvsteam'; label: string }[] = [
    { key: 'ALL', label: 'All Lobbies' },
    { key: '4v4', label: '4v4 Squad' },
    { key: '6v6', label: '6v6 Clash' },
    { key: 'BR', label: 'BR Mode' },
    { key: 'teamvsteam', label: 'Team vs Team' }
  ];

  return (
    <div className="max-w-md mx-auto p-4 space-y-5 animate-fade-in text-white pb-28">
      
      {/* Top Welcome Panel */}
      <div className="flex items-center justify-between pb-1">
        <div>
          <span className="text-[10px] font-mono text-[#00FFCC] uppercase tracking-widest block font-bold">
            ⚔️ VALENT LOBBIES
          </span>
          <h1 className="text-lg font-display font-black text-white tracking-wide uppercase flex items-center gap-1">
            <span>{currentUser?.username || 'Survivor'}</span>
            <Flame className="w-5 h-5 text-[#FF4500] fill-current animate-pulse" />
          </h1>
        </div>

        {/* Balance Capsule */}
        <button
          onClick={onNavigateToWallet}
          className="bg-[#13192B] border border-[#222D4A] rounded-full px-3.5 py-1.5 flex items-center gap-2 hover:border-[#FF4500] transition-all cursor-pointer backdrop-blur-md shadow-lg"
        >
          <div className="w-5 h-5 bg-gradient-to-br from-[#FF4500] to-[#C60000] rounded-full flex items-center justify-center font-display font-black text-white text-[11px] leading-none shrink-0" style={{ textShadow: '0 1px 2px rgba(0,0,0,0.5)' }}>
            ₹
          </div>
          <span className="text-xs font-mono font-extrabold text-[#FF4D4D]">
            ₹{totalCombinedBalance.toFixed(0)}
          </span>
          <span className="text-[9px] text-[#00FFCC] font-mono leading-none border border-[#00FFCC]/20 px-1.5 py-0.5 rounded-full bg-[#00FFCC]/5 font-bold">
            WALLET
          </span>
        </button>
      </div>

      {/* Slide Banners for Promos */}
      {banners.length > 0 && (
        <div className="relative overflow-hidden rounded-2xl border border-[#222D4A] bg-[#0E1321] transition-all hover:border-[#FF4500]/30 shadow-xl select-none">
          <div className="relative h-32 w-full overflow-hidden">
            {banners.map((b, idx) => {
              const isActive = idx === currentBannerIdx;
              return (
                <div
                  key={b.id}
                  className={`absolute inset-0 w-full h-full transition-all duration-700 ease-in-out flex flex-col justify-end p-4 ${
                    isActive ? 'opacity-100 scale-100 z-10' : 'opacity-0 scale-95 pointer-events-none z-0'
                  }`}
                >
                  <img
                    src={b.imageUrl}
                    alt={b.title || 'Esports Tournament'}
                    className="absolute inset-0 w-full h-full object-cover opacity-60"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0A0E17] via-[#0A0E17]/25 to-transparent pointer-events-none" />
                  <div className="relative z-10 space-y-1">
                    <h2 className="text-white font-display font-black text-xs uppercase tracking-wider drop-shadow-md">
                      {b.title}
                    </h2>
                    <span className="inline-flex items-center gap-1 text-[9px] text-[#00FFCC] font-mono uppercase font-black">
                      <span>Instant Matchmaker Rules</span>
                      <ArrowRight className="w-2.5 h-2.5 text-[#00FFCC]" />
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
          {banners.length > 1 && (
            <div className="absolute bottom-2 right-3 z-25 flex gap-1">
              {banners.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setCurrentBannerIdx(idx)}
                  className={`w-1.5 h-1.5 rounded-full ${
                    idx === currentBannerIdx ? 'bg-[#FF4500] w-3' : 'bg-gray-600'
                  }`}
                />
              ))}
            </div>
          )}
        </div>
      )}

      {/* 🔮 BILLION DOLLAR COGNITIVE MINI CARD & RULEBOOK COMPLIANCE */}
      <div
        onClick={() => setShowRulesOverlay(true)}
        className="bg-gradient-to-r from-[#121829] via-[#1A122B] to-[#121829] border border-amber-500/30 hover:border-amber-400 rounded-xl p-3.5 shadow-md relative overflow-hidden flex items-center justify-between cursor-pointer transition-all hover:scale-[1.01] active:scale-[0.99] select-none group"
      >
        <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/5 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute top-0 left-0 w-[2px] h-full bg-gradient-to-b from-amber-500 to-orange-500" />
        
        <div className="flex items-center gap-3">
          <div className="p-2 bg-amber-500/10 border border-amber-500/20 rounded-xl text-amber-500 group-hover:bg-amber-500/20 transition-all shrink-0">
            <ShieldAlert className="w-4 h-4 animate-pulse" />
          </div>
          <div className="text-left">
            <span className="text-[9px] font-mono text-amber-500 uppercase tracking-widest block font-black">
              ★ OFFICIAL COMPLIANCE
            </span>
            <h2 className="text-xs font-display font-black uppercase text-white tracking-wide flex items-center gap-1.5">
              VALENT Fair-Play Directives
              <span className="text-[8px] text-[#00FFCC] bg-[#00FFCC]/10 border border-[#00FFCC]/20 px-1 py-0.2 rounded font-mono uppercase animate-pulse">READ</span>
            </h2>
          </div>
        </div>
        
        <div className="flex items-center gap-1 bg-[#13192B] border border-[#222D4A] rounded-lg px-2.5 py-1.5 text-amber-500 font-mono text-[9px] font-bold shadow-md shrink-0">
          <span>VIEW RULES</span>
          <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform text-amber-500" />
        </div>
      </div>

      {/* 🔮 OVERLAY PORTAL OF GLOBAL COMPLIANCE TOURNAMENT FAIR-PLAY RULES */}
      {showRulesOverlay && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/92 backdrop-blur-xl animate-fade-in select-none">
          <div className="bg-gradient-to-br from-[#121829] via-[#0D1222] to-[#080B14] border border-amber-500/40 rounded-3xl p-6 md:p-8 max-w-xl w-full shadow-[0_0_80px_rgba(245,158,11,0.18)] relative overflow-hidden space-y-6">
            <div className="absolute top-0 right-0 w-56 h-56 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute top-0 left-0 w-full h-[3px] bg-gradient-to-r from-amber-500 via-orange-550 to-amber-500" />
            
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="p-3.5 bg-amber-500/10 border border-amber-500/25 rounded-2xl text-amber-500 shrink-0">
                  <ShieldAlert className="w-7 h-7" />
                </div>
                <div className="text-left">
                  <span className="text-xs font-mono text-amber-500 uppercase tracking-widest block font-extrabold">
                    ★ CRITICAL RULEBOOK & COMPLIANCE
                  </span>
                  <h2 className="text-base md:text-lg font-display font-black uppercase text-white tracking-wide">
                    Tournament Fair-Play Directives
                  </h2>
                </div>
              </div>
              
              <button
                onClick={() => setShowRulesOverlay(false)}
                className="p-2 bg-[#13192B] border border-[#222D4A] hover:bg-red-500/15 hover:border-red-500 hover:text-red-500 rounded-xl text-gray-400 transition-all cursor-pointer shrink-0"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Rules Text Content Screen - Made larger and highly readable in clean font */}
            <div className="bg-[#0A0E17]/95 border border-[#222D4A]/65 rounded-2xl p-6 space-y-4 relative overflow-hidden max-h-[380px] overflow-y-auto text-left shadow-inner">
              <div className="text-sm md:text-base font-sans leading-relaxed text-gray-200 whitespace-pre-wrap select-text tracking-wide font-semibold pr-2">
                {globalRules ? globalRules : (
`⚠️ NO HACKS, SCRIPTS OR CHEATING.
🚫 Manipulating matches, spoofing levels, or utilizing third-party tools will trigger an immediate permanent device BAN and result in total payout credit forfeiture.

⚔️ RESULT COMPLIANCE:
• Submitting match screenshots is absolute. The VALENT scorecard summary screen must display IGN, level, kill counts, and match placement clearly.
• Submissions must be uploaded within 15 minutes of custom lobby tournament completion.

👑 DECISION FINALITY:
• Under dispute alerts, the designated custom Admin holds extreme and final master decisions. Compliance failures or toxic behavior locks payout queues permanently.`
                )}
              </div>
            </div>

            <div className="flex items-center justify-between text-xs font-mono border-t border-[#222D4A]/55 pt-4.5">
              <span className="text-gray-400">Security Clearance Verified</span>
              <span className="text-amber-500 font-black flex items-center gap-1.5">
                <span className="w-2 h-2 bg-amber-500 rounded-full animate-ping animate-pulse" />
                LIVE BINDING VERIFIED RULES
              </span>
            </div>

            <div className="flex justify-end pt-1">
              <button
                onClick={() => setShowRulesOverlay(false)}
                className="px-6 py-2.5 bg-gradient-to-r from-amber-600 to-orange-500 border border-amber-500/50 hover:from-amber-500 hover:to-orange-400 text-white rounded-xl text-xs font-display font-black uppercase tracking-widest transition-all cursor-pointer shadow-[0_4px_12px_rgba(245,158,11,0.2)] shrink-0"
              >
                I Understand Rules & Agree
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 🧭 Esports Tab Filters */}
      <div className="space-y-3.5">
        <div className="flex items-center justify-between pl-1">
          <h3 className="text-sm font-display text-[#00FFCC] uppercase font-black tracking-widest flex items-center gap-2">
            <Layers className="w-4.5 h-4.5 text-[#00FFCC]" />
            <span>Select Match Type</span>
          </h3>
          <span className="text-xs font-mono text-gray-400 uppercase font-bold">{filteredMatches.length} Lobbies Available</span>
        </div>

        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-none no-wrap">
          {formats.map((f) => {
            const isSelected = selectedFormat === f.key;
            return (
              <button
                key={f.key}
                onClick={() => setSelectedFormat(f.key)}
                className={`px-4 py-2.5 text-xs font-mono font-black rounded-xl uppercase tracking-wider transition-all border shrink-0 cursor-pointer ${
                  isSelected
                    ? 'bg-gradient-to-r from-[#FF4500] to-[#C60000] text-white border-[#FF4500] shadow-[0_0_15px_rgba(255,69,0,0.35)]'
                    : 'bg-[#13192B] text-gray-300 border-[#222D4A] hover:border-gray-500 hover:text-white'
                }`}
              >
                {f.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Match Grid Board Cards (Small and Compact) */}
      <div className="space-y-4">
        {filteredMatches.length === 0 ? (
          <div className="p-16 text-center bg-[#13192B]/50 border border-[#222D4A]/50 rounded-2.5xl">
            <Users className="w-12 h-12 text-gray-500 mx-auto mb-4" />
            <h4 className="font-mono text-gray-300 font-bold uppercase text-sm">No Custom Rooms Configured</h4>
          </div>
        ) : (
          filteredMatches.map((m) => {
            const isJoined = currentUser ? m.players.some(p => p.userId === currentUser.id) : false;
            const spotsRemaining = m.spotsTotal - m.spotsFilled;
            const isFull = spotsRemaining <= 0;

            const percent = Math.min(100, (m.spotsFilled / m.spotsTotal) * 100);

            let formatBadgeColor = 'bg-blue-950/40 text-blue-400 border-blue-500/40';
            if (m.format_type === '4v4') formatBadgeColor = 'bg-pink-955/40 text-pink-400 border-pink-500/40';
            if (m.format_type === '6v6') formatBadgeColor = 'bg-purple-955/40 text-purple-400 border-purple-500/40';
            if (m.format_type === 'BR') formatBadgeColor = 'bg-indigo-955/40 text-indigo-400 border-indigo-500/40';
            if (m.format_type === 'teamvsteam4v4' || m.format_type === 'teamvsteam6v6') {
              formatBadgeColor = 'bg-amber-955/40 text-amber-400 border-amber-500/40';
            }

            // Timer Calculations
            const now = new Date();
            const revealTime = m.credentialsRevealTime ? new Date(m.credentialsRevealTime) : null;
            const startTime = m.matchStartTime ? new Date(m.matchStartTime) : null;

            const isRevealReached = !revealTime || now >= revealTime;
            const isLiveLocked = (startTime && now >= startTime) || m.status === 'LIVE' || m.status === 'COMPLETED';

            const renderLiveTimerBadge = () => {
              if (startTime && now < startTime) {
                const totalStartDiff = startTime.getTime() - now.getTime();
                const totalMins = Math.floor(totalStartDiff / 60000);
                const totalSecs = Math.floor((totalStartDiff % 60000) / 1000).toString().padStart(2, '0');

                let isBeforeReveal = false;
                let revealMins = 0;
                let revealSecs = "00";

                if (revealTime && now < revealTime) {
                  isBeforeReveal = true;
                  const revealDiff = revealTime.getTime() - now.getTime();
                  revealMins = Math.floor(revealDiff / 60000);
                  revealSecs = Math.floor((revealDiff % 60000) / 1000).toString().padStart(2, '0');
                }

                return (
                  <div className="flex flex-col items-end gap-1 font-mono text-[9px] font-black uppercase text-right leading-none">
                    <span className="text-[#00FFCC] bg-[#00FFCC]/5 border border-[#00FFCC]/20 px-2 py-0.5 rounded-md animate-pulse">
                      ⚔️ Starts in: {totalMins}:{totalSecs}
                    </span>
                    {isBeforeReveal ? (
                      <span className="text-amber-450 bg-amber-500/5 border border-amber-500/15 px-1.5 py-0.5 rounded-md">
                        🔑 ID Reveal: {revealMins}:{revealSecs}
                      </span>
                    ) : (
                      <span className="text-emerald-450 bg-emerald-500/5 border border-emerald-500/15 px-1.5 py-0.5 rounded-md">
                        🔑 ID Released & Ready
                      </span>
                    )}
                  </div>
                );
              } else if (isLiveLocked) {
                return (
                  <span className="text-[10px] font-mono font-black bg-red-500/10 text-red-500 border border-red-500/30 px-2 py-0.5 rounded-lg uppercase">
                    🔴 Live & Locked
                  </span>
                );
              } else if (m.status === 'ROOM_READY') {
                return (
                  <span className="text-[10px] font-mono font-black bg-emerald-500/10 text-[#00FFCC] border border-[#00FFCC]/30 px-2 py-0.5 rounded-lg uppercase">
                    🔑 ID Released
                  </span>
                );
              } else {
                return (
                  <span className="text-[10px] font-mono font-black bg-gray-500/10 text-gray-400 border border-gray-500/30 px-2 py-0.5 rounded-lg uppercase">
                    ⏳ Waiting
                  </span>
                );
              }
            };

            return (
              <div
                key={m.id}
                onClick={() => onSelectMatch(m)}
                className={`bg-[#0D1426] border border-[#222D4A] rounded-2xl overflow-hidden shadow-xl hover:border-[#FF4500]/50 hover:shadow-[0_0_20px_rgba(255,69,0,0.15)] active:scale-[0.99] transition-all cursor-pointer relative ${
                  isJoined ? 'border-[#FF4500] shadow-[0_0_15px_rgba(255,69,0,0.3)] ring-1 ring-[#FF4500]/30' : ''
                }`}
              >
                {/* Compact Header: Title and format badge */}
                <div className="px-4 py-3 bg-[#060911]/90 border-b border-[#222D4A]/50 flex justify-between items-center gap-3">
                  <h4 className="font-display text-sm font-black text-white uppercase truncate flex-1 flex items-center gap-2">
                    <PlayCircle className="w-5 h-5 text-[#FF4500] shrink-0" />
                    <span>{m.title}</span>
                  </h4>
                  <span className={`text-[10px] px-2.5 py-0.5 rounded-md font-mono font-black border uppercase tracking-wider ${formatBadgeColor}`}>
                    {m.format_type === 'teamvsteam4v4' ? 'Team 4v4' : m.format_type === 'teamvsteam6v6' ? 'Team 6v6' : m.format_type}
                  </span>
                </div>

                {/* Card Main specs */}
                <div className="p-4 space-y-4">
                  {/* Big visual stat indicators - Redesigned to be highly prominent & readable */}
                  <div className="grid grid-cols-2 gap-3.5">
                    {/* Prize pool block (Glowing cyan) */}
                    <div className="bg-[#13192B]/90 border border-[#00FFCC]/20 rounded-xl p-3 text-center flex flex-col justify-center shadow-[inset_0_0_12px_rgba(0,255,204,0.03)]">
                      <span className="text-[9px] font-mono font-bold text-[#00FFCC]/80 uppercase tracking-widest block mb-0.5">Prize Pool</span>
                      <span className="text-lg font-display font-black text-[#00FFCC]">₹{m.prizePool}</span>
                    </div>

                    {/* Entry fee block (Vibrant orange) */}
                    <div className="bg-[#13192B] border border-[#222D4A] rounded-xl p-3 text-center flex flex-col justify-center">
                      <span className="text-[9px] font-mono font-bold text-gray-400 uppercase tracking-widest block mb-0.5">Entry Fee</span>
                      <span className="text-lg font-display font-black text-orange-400">₹{m.entryFee}</span>
                    </div>
                  </div>

                  {/* Individual Winner Payout Info Card */}
                  {m.prizePerPlayer && m.prizePerPlayer > 0 ? (
                    <div className="bg-[#111625] border border-[#223354] rounded-xl px-3.5 py-3 flex items-center justify-between text-left shadow-inner">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/25 flex items-center justify-center text-lg shadow-[0_0_8px_rgba(245,158,11,0.1)] shrink-0">
                          🏆
                        </div>
                        <div className="space-y-0.5">
                          <span className="text-[10px] font-mono font-bold text-amber-400 uppercase tracking-widest block">INDIVIDUAL WINNER PAYOUT</span>
                          <span className="text-[9px] text-gray-400 font-medium block">Each member of the winning slot receives:</span>
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <span className="text-sm font-mono font-black text-[#00FFCC] bg-black/40 px-3 py-1.5 rounded-lg border border-[#222D4A] shadow-inner block">
                          ₹{m.prizePerPlayer}
                        </span>
                      </div>
                    </div>
                  ) : null}

                  {/* Secondary info bar (Map & timer) */}
                  <div className="flex items-center justify-between text-xs font-mono pt-2 border-t border-[#222D4A]/30">
                    <div className="flex items-center gap-1.5 text-gray-300">
                      <span>🗺️ Map:</span>
                      <span className="text-white font-extrabold uppercase tracking-wide">{m.mapName}</span>
                    </div>
                    <div>
                      {renderLiveTimerBadge()}
                    </div>
                  </div>

                  {/* Seat fillings and Action */}
                  <div className="flex items-center justify-between gap-4 pt-1">
                    <div className="flex-1 space-y-1.5">
                      <div className="flex justify-between items-center text-xs font-mono text-gray-400">
                        <span className="font-extrabold text-gray-200">{m.spotsFilled} / {m.spotsTotal} Joined</span>
                        {isLiveLocked ? (
                          <span className="text-red-500 font-extrabold text-[10px] uppercase tracking-wider">LOCKED</span>
                        ) : isFull ? (
                          <span className="text-orange-500 font-bold text-[10px] uppercase tracking-wider">LOBBY FULL</span>
                        ) : (
                          <span className="text-[#00FFCC] font-bold text-[10px] uppercase tracking-wider">{spotsRemaining} left</span>
                        )}
                      </div>
                      <div className="w-full h-2 bg-[#060911] rounded-full overflow-hidden border border-[#222D4A]/30">
                        <div
                          className="h-full bg-gradient-to-r from-[#FF4500] to-orange-400 transition-all duration-300 rounded-full"
                          style={{ width: `${percent}%` }}
                        />
                      </div>
                    </div>

                    <div className="shrink-0">
                      {isJoined ? (
                        <div className="px-3.5 py-2.5 bg-[#FF4500]/10 border border-[#FF4500]/30 rounded-xl text-[10.5px] font-mono font-black uppercase text-[#FF4500] flex items-center gap-1.5">
                          <ShieldCheck className="w-4 h-4 text-[#FF4500]" />
                          <span>Joined</span>
                        </div>
                      ) : (
                        <button
                          className={`px-4.5 py-2.5 font-display font-black text-[11px] rounded-xl uppercase tracking-wider cursor-pointer transition-all ${
                            isFull || isLiveLocked
                              ? 'bg-gray-800 text-gray-500 border border-gray-750 cursor-not-allowed'
                              : 'bg-gradient-to-r from-[#FF4500] to-[#C60000] text-white hover:scale-104 hover:shadow-[0_0_12px_rgba(255,69,0,0.3)] active:scale-96'
                          }`}
                          disabled={isFull || isLiveLocked}
                        >
                          {isLiveLocked ? 'Locked' : isFull ? 'Lobby Full' : 'Join Game'}
                        </button>
                      )}
                    </div>
                  </div>
                </div>

              </div>
            );
          })
        )}
      </div>

    </div>
  );
}
