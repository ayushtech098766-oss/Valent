import React from 'react';
import { Match, Player, Team } from '../types';
import { Shield, Sparkles, Crosshair, Award } from 'lucide-react';

interface TacticalRadarProps {
  selectedMatch: Match | null;
  isDrafting: boolean;
  currentUser: any;
}

export default function TacticalRadar({ selectedMatch, isDrafting, currentUser }: TacticalRadarProps) {
  // Static placeholder players matching the design if none is actively being created
  const defaultPlayers = [
    { name: 'Mortal', role: 'Rusher', emoji: '🛡️', type: 'c' },
    { name: 'Scout', role: 'Rusher', emoji: '⚔️', type: 'none' },
    { name: 'Jonathan', role: 'Rusher', emoji: '⚔️', type: 'none' },
    { name: 'Viper', role: 'Support', emoji: '🩹', type: 'none' },
    { name: 'Zuxxy', role: 'Bomber', emoji: '💣', type: 'vc' },
    { name: 'Regaltos', role: 'Support', emoji: '🩹', type: 'none' },
    { name: 'Mavi', role: 'Sniper', emoji: '🎯', type: 'none' },
    { name: 'Daljit', role: 'Sniper', emoji: '🎯', type: 'none' },
  ];

  const title = selectedMatch ? selectedMatch.title : 'FFWS SEA GRAND LEAGUE';
  const subtitle = selectedMatch
    ? `${selectedMatch.mapName} | LOBBY ${selectedMatch.format_type}`
    : 'MOCK PREVIEW | Classic 11v11 Formation';

  return (
    <div className="bg-[#13192B] border border-[#222D4A] rounded-[32px] p-8 relative overflow-hidden flex flex-col h-full shadow-[0_15px_50px_rgba(0,0,0,0.8)]">
      {/* Visual top fire glow */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-[#FF4500]/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex justify-between items-start mb-6 z-10">
        <div>
          <div className="text-2xl font-black uppercase tracking-wide text-[#00FFCC] flex items-center gap-1.5 font-display">
            <span>Tactical Radar</span>
            <Sparkles className="w-5 h-5 text-yellow-400 fill-current animate-pulse" />
          </div>
          <div className="text-xs text-white/50 font-mono uppercase mt-1">
            {subtitle}
          </div>
        </div>
        <div className="bg-[#C60000] text-white px-3 py-1 text-[10px] rounded-lg font-mono font-bold uppercase tracking-wider animate-pulse shadow-md shadow-red-950/50">
          LIVE PREVIEW
        </div>
      </div>

      {/* Map Grid Arena */}
      <div className="flex-1 bg-[radial-gradient(circle_at_center,#1A2235_0%,#0A0E17_100%)] border border-[#1A2235] rounded-2.5xl relative grid grid-rows-3 gap-5 p-5 min-h-[440px]">
        {/* Gridded overlay styling */}
        <div className="absolute inset-0 bg-[linear-gradient(#1A2235_1px,transparent_1px),linear-gradient(90deg,#1A2235_1px,transparent_1px)] bg-[size:20px_20px] opacity-25 pointer-events-none rounded-2.5xl" />

        {/* Top Row: Rushers */}
        <div className="flex justify-around items-center z-15 relative">
          {defaultPlayers.slice(0, 3).map((p, idx) => (
            <div key={idx} className="flex flex-col items-center justify-center relative group">
              <div
                className={`w-[62px] h-[62px] bg-[#0A0E17] border-2 rounded-full flex flex-col items-center justify-center relative transition-transform duration-350 hover:scale-110 shadow-lg ${
                  p.type === 'c'
                    ? 'border-[#FFD700] shadow-[0_0_15px_rgba(255,215,0,0.45)] bg-gradient-to-b from-[#13192B] to-[#FFD700]/15'
                    : p.type === 'vc'
                    ? 'border-[#00FFCC] shadow-[0_0_15px_rgba(0,255,204,0.35)] bg-gradient-to-b from-[#13192B] to-[#00FFCC]/15'
                    : 'border-[#222D4A] hover:border-[#FF4500]'
                }`}
              >
                {/* C or VC badge */}
                {p.type === 'c' && (
                  <div className="absolute -top-1 -right-1 bg-[#FFD700] text-black font-black text-[9px] w-[18px] h-[18px] rounded-full flex items-center justify-center border-2 border-[#0A0E17]">
                    C
                  </div>
                )}
                {p.type === 'vc' && (
                  <div className="absolute -top-1 -right-1 bg-[#00FFCC] text-black font-black text-[9px] w-[18px] h-[18px] rounded-full flex items-center justify-center border-2 border-[#0A0E17]">
                    VC
                  </div>
                )}
                <span className="text-xl">{p.emoji}</span>
              </div>
              <span className="text-[10px] mt-1.5 font-bold uppercase font-display tracking-wide text-white/85">
                {p.name}
              </span>
              <span className="text-[8px] font-mono text-gray-400/70 uppercase leading-none mt-0.5">
                {p.role}
              </span>
            </div>
          ))}
        </div>

        {/* Middle Row: Support / Bomber */}
        <div className="flex justify-around items-center z-15 relative">
          {defaultPlayers.slice(3, 6).map((p, idx) => (
            <div key={idx} className="flex flex-col items-center justify-center relative group">
              <div
                className={`w-[62px] h-[62px] bg-[#0A0E17] border-2 rounded-full flex flex-col items-center justify-center relative transition-transform duration-350 hover:scale-110 shadow-lg ${
                  p.type === 'c'
                    ? 'border-[#FFD700] shadow-[0_0_15px_rgba(255,215,0,0.45)] bg-gradient-to-b from-[#13192B] to-[#FFD700]/15'
                    : p.type === 'vc'
                    ? 'border-[#00FFCC] shadow-[0_0_15px_rgba(0,255,204,0.35)] bg-gradient-to-b from-[#13192B] to-[#00FFCC]/15'
                    : 'border-[#222D4A] hover:border-[#FF4500]'
                }`}
              >
                {p.type === 'c' && (
                  <div className="absolute -top-1 -right-1 bg-[#FFD700] text-black font-black text-[9px] w-[18px] h-[18px] rounded-full flex items-center justify-center border-2 border-[#0A0E17]">
                    C
                  </div>
                )}
                {p.type === 'vc' && (
                  <div className="absolute -top-1 -right-1 bg-[#00FFCC] text-black font-black text-[9px] w-[18px] h-[18px] rounded-full flex items-center justify-center border-2 border-[#0A0E17]">
                    VC
                  </div>
                )}
                <span className="text-xl">{p.emoji}</span>
              </div>
              <span className="text-[10px] mt-1.5 font-bold uppercase font-display tracking-wide text-white/85">
                {p.name}
              </span>
              <span className="text-[8px] font-mono text-gray-400/70 uppercase leading-none mt-0.5">
                {p.role}
              </span>
            </div>
          ))}
        </div>

        {/* Bottom Row: Snipers */}
        <div className="flex justify-around items-center z-15 relative w-[70%] mx-auto">
          {defaultPlayers.slice(6, 8).map((p, idx) => (
            <div key={idx} className="flex flex-col items-center justify-center relative group">
              <div
                className={`w-[62px] h-[62px] bg-[#0A0E17] border-2 rounded-full flex flex-col items-center justify-center relative transition-transform duration-350 hover:scale-110 shadow-lg ${
                  p.type === 'c'
                    ? 'border-[#FFD700] shadow-[0_0_15px_rgba(255,215,0,0.45)] bg-gradient-to-b from-[#13192B] to-[#FFD700]/15'
                    : p.type === 'vc'
                    ? 'border-[#00FFCC] shadow-[0_0_15px_rgba(0,255,204,0.35)] bg-gradient-to-b from-[#13192B] to-[#00FFCC]/15'
                    : 'border-[#222D4A] hover:border-[#FF4500]'
                }`}
              >
                {p.type === 'c' && (
                  <div className="absolute -top-1 -right-1 bg-[#FFD700] text-black font-black text-[9px] w-[18px] h-[18px] rounded-full flex items-center justify-center border-2 border-[#0A0E17]">
                    C
                  </div>
                )}
                {p.type === 'vc' && (
                  <div className="absolute -top-1 -right-1 bg-[#00FFCC] text-black font-black text-[9px] w-[18px] h-[18px] rounded-full flex items-center justify-center border-2 border-[#0A0E17]">
                    VC
                  </div>
                )}
                <span className="text-xl">{p.emoji}</span>
              </div>
              <span className="text-[10px] mt-1.5 font-bold uppercase font-display tracking-wide text-white/85">
                {p.name}
              </span>
              <span className="text-[8px] font-mono text-gray-400/70 uppercase leading-none mt-0.5">
                {p.role}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom info footer matching the Design mockup */}
      <div className="mt-6 flex justify-between items-center z-15">
        <div>
          <div className="text-xs text-[#FFD700] font-bold font-mono tracking-wider uppercase">
            Platform Security Code
          </div>
          <div className="text-2xl font-black font-mono text-white tracking-wider">
            SQUAD // SECURE
          </div>
        </div>
        <div className="text-right">
          <div className="text-[10px] font-mono text-gray-550 uppercase">Region Lock</div>
          <div className="text-sm font-bold font-display text-[#FF4500] uppercase">
            IND SERVER
          </div>
        </div>
      </div>
    </div>
  );
}
