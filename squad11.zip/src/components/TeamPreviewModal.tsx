import React from 'react';
import { Player } from '../types';
import { getPlayerPhoto } from '../utils';
import { X, Shield, MapPin } from 'lucide-react';

interface TeamPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedPlayers: Player[];
  captainId: string | null;
  viceCaptainId: string | null;
  formatType: 'Classic' | '4v4' | 'BR_Tourney';
}

export default function TeamPreviewModal({
  isOpen,
  onClose,
  selectedPlayers,
  captainId,
  viceCaptainId,
  formatType,
}: TeamPreviewModalProps) {
  if (!isOpen) return null;

  // Render 11 or 4 players depending on the format type
  const getSurvivalSlots = (): (Player | null)[] => {
    if (formatType === '4v4') {
      const slots: (Player | null)[] = Array(4).fill(null);
      const unplaced = [...selectedPlayers];
      
      const placeInSlot = (slotIdx: number, role: string) => {
        const idx = unplaced.findIndex((p) => p.role === role);
        if (idx !== -1) {
          slots[slotIdx] = unplaced[idx];
          unplaced.splice(idx, 1);
        }
      };

      placeInSlot(0, 'Rusher');
      placeInSlot(1, 'Bomber');
      placeInSlot(2, 'Sniper');
      placeInSlot(3, 'Support');

      for (let i = 0; i < 4; i++) {
        if (slots[i] === null && unplaced.length > 0) {
          slots[i] = unplaced.shift() || null;
        }
      }
      return slots;
    }

    const slots: (Player | null)[] = Array(11).fill(null);
    const unplaced = [...selectedPlayers];

    // Priority placing by roles:
    // Slot 0, 1, 2, 3: Front-line Rushers
    // Slot 4, 5, 6, 7: Flankers / Grenadiers (Bomber / support / whatever is left)
    // Slot 8, 9, 10: Anchor Snipers and Supports

    const placeInSlot = (slotIdx: number, role: string) => {
      const idx = unplaced.findIndex((p) => p.role === role);
      if (idx !== -1) {
        slots[slotIdx] = unplaced[idx];
        unplaced.splice(idx, 1);
      }
    };

    // 1. Placements of 4 Rushers in Assault Line
    for (let i = 0; i < 4; i++) {
      placeInSlot(i, 'Rusher');
    }

    // 2. Placements of Bombers in Flank Line
    for (let i = 4; i < 8; i++) {
      placeInSlot(i, 'Bomber');
    }

    // 3. Placements of Supports & Snipers in Baseline / Center
    for (let i = 4; i < 8; i++) {
      if (slots[i] === null) {
        placeInSlot(i, 'Support');
      }
    }

    for (let i = 8; i < 11; i++) {
      placeInSlot(i, 'Sniper');
    }

    // Fill remaining null slots with whatever is left
    for (let i = 0; i < 11; i++) {
      if (slots[i] === null && unplaced.length > 0) {
        slots[i] = unplaced.shift() || null;
      }
    }

    return slots;
  };

  const survivalSlots = getSurvivalSlots();

  const renderPlayerBubble = (player: Player | null, label: string) => {
    if (!player) {
      return (
        <div className="flex flex-col items-center justify-center p-2">
          <div className="w-12 h-12 rounded-full border border-dashed border-teal-800 bg-[#0A0E17]/60 flex items-center justify-center text-teal-800 text-[10px] font-mono">
            {label}
          </div>
          <p className="text-[10px] text-gray-600 font-mono mt-1">Empty</p>
        </div>
      );
    }

    const isC = player.id === captainId;
    const isVC = player.id === viceCaptainId;

    // Fallback letter logo generator
    const initials = player.name.replace('EV ', '').replace('FA ', '').substring(0, 2).toUpperCase();

    // Determine backdrop color based on Captain (Championship Gold) or Vice-Captain (Tactical Teal) or default
    return (
      <div className="flex flex-col items-center justify-center p-2 relative animate-fade-in group">
        <div className="relative">
          {/* C / VC Badge */}
          {isC && (
            <div className="absolute -top-1.5 -right-1.5 z-20 bg-gradient-to-r from-[#FFD700] to-yellow-500 text-black text-[9px] font-bold w-5 h-5 rounded-full flex items-center justify-center border border-black shadow-md animate-bounce">
              C
            </div>
          )}
          {isVC && (
            <div className="absolute -top-1.5 -right-1.5 z-20 bg-gradient-to-r from-[#00FFCC] to-teal-400 text-black text-[9px] font-bold w-5 h-5 rounded-full flex items-center justify-center border border-black shadow-md">
              VC
            </div>
          )}

          {/* Pulse ring */}
          {isC && (
            <span className="absolute -inset-1.5 rounded-full border border-[#FFD700] opacity-75 animate-ping z-0" />
          )}
          {isVC && (
            <span className="absolute -inset-1.5 rounded-full border border-[#00FFCC] opacity-60 animate-pulse z-0" />
          )}

          {/* Outer ring */}
          <div
            className={`w-14 h-14 rounded-full flex items-center justify-center relative z-10 transition-transform group-hover:scale-110 duration-200 border-2 ${
              isC
                ? 'border-[#FFD700] bg-[#13192B]'
                : isVC
                ? 'border-[#00FFCC] bg-[#13192B]'
                : player.team === 'EV'
                ? 'border-[#CCFF00] bg-[#13192B]'
                : 'border-[#00D2FF] bg-[#13192B]'
            }`}
          >
            <img
              src={getPlayerPhoto(player)}
              alt={player.name}
              referrerPolicy="no-referrer"
              className="w-12 h-12 rounded-full object-cover"
            />
          </div>
        </div>

        {/* Player details */}
        <div className="mt-1.5 text-center max-w-[80px]">
          <p className="text-[10px] font-display font-semibold text-white whitespace-nowrap overflow-hidden text-ellipsis leading-tight">
            {player.name}
          </p>
          <div className="flex items-center justify-center gap-1">
            <span
              className={`text-[8px] font-mono px-1 rounded uppercase font-bold ${
                player.team === 'EV' ? 'bg-[#CCFF00]/10 text-[#CCFF00]' : 'bg-[#00D2FF]/10 text-[#00D2FF]'
              }`}
            >
              {player.team}
            </span>
            <span className="text-[9px] text-gray-400 font-mono">{player.credits} Cr</span>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#0B0D17] flex flex-col justify-between overflow-hidden animate-fade-in text-white">
      {/* Title Header */}
      <div className="p-4 bg-[#13192B] border-b border-[#222D4A] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-gradient-to-r from-[#FF4500] to-[#C60000] rounded-lg">
            <Shield className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-sm font-display font-bold tracking-wider text-white uppercase">
              Tactical Battleground
            </h3>
            <p className="text-[10px] text-gray-400 font-mono uppercase tracking-wider">
              {formatType === '4v4' ? '4v4 Clash Squad Formation' : '11-Survivor Battle Royale Lineup Pool'}
            </p>
          </div>
        </div>
        <button
          onClick={onClose}
          id="close-team-preview"
          className="p-2 bg-[#0A0E17] hover:bg-red-950/20 text-gray-400 hover:text-red-500 border border-[#222D4A] rounded-full transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Main Isometric Battleground Field */}
      <div className="flex-1 relative flex items-center justify-center px-4 overflow-y-auto">
        {/* Isometric Grid lines */}
        <div className="absolute inset-0 z-0 opacity-20 bg-[radial-gradient(#00FFCC_0.75px,transparent_0.75px)] [background-size:20px_20px]" />
        
        {/* Isometric Perspective Plane Container */}
        <div className="w-full max-w-lg mx-auto py-8 relative z-10 flex flex-col items-center justify-center">
          {/* Tactical Radar HUD overlay */}
          <div className="absolute inset-x-4 inset-y-0 border border-teal-500/20 rounded-3xl pointer-events-none flex items-center justify-center">
            <div className="w-64 h-64 border border-teal-500/15 rounded-full animate-pulse flex items-center justify-center">
              <div className="w-40 h-40 border border-dashed border-teal-500/10 rounded-full" />
            </div>
            {/* Top right scan lines */}
            <div className="absolute top-4 right-4 text-[9px] text-[#00FFCC] font-mono tracking-widest uppercase">
              RADAR LIVE // S11_SECURE
            </div>
          </div>

          <div className="w-full flex flex-col gap-6 relative p-4">
            {formatType === '4v4' ? (
              <div className="space-y-8 py-4">
                {/* 4v4 Left-Right/Front-Back Balanced Lineup */}
                <div>
                  <p className="text-center text-[9px] font-mono tracking-widest text-[#FF4500] uppercase mb-2 font-bold">
                    ⚔️ Vanguard (Assault Unit)
                  </p>
                  <div className="grid grid-cols-2 gap-4 justify-items-center max-w-[280px] mx-auto">
                    {renderPlayerBubble(survivalSlots[0], 'V1 (Rusher)')}
                    {renderPlayerBubble(survivalSlots[1], 'V2 (Bomber)')}
                  </div>
                </div>
                <div>
                  <p className="text-center text-[9px] font-mono tracking-widest text-[#00FFCC] uppercase mb-2 font-bold">
                    🎯 Guardian (Support Core)
                  </p>
                  <div className="grid grid-cols-2 gap-4 justify-items-center max-w-[280px] mx-auto">
                    {renderPlayerBubble(survivalSlots[2], 'G1 (Sniper)')}
                    {renderPlayerBubble(survivalSlots[3], 'G2 (Support)')}
                  </div>
                </div>
              </div>
            ) : (
              <>
                {/* TOP GRID LINE (The Assault Line): 4 high-voltage Front-line Rushers */}
                <div>
                  <p className="text-center text-[9px] font-mono tracking-widest text-[#FF4500] uppercase mb-1 font-bold">
                    ⚔️ Top Line (Assault Line - Rushers)
                  </p>
                  <div className="grid grid-cols-4 gap-2 justify-items-center">
                    {renderPlayerBubble(survivalSlots[0], 'R1')}
                    {renderPlayerBubble(survivalSlots[1], 'R2')}
                    {renderPlayerBubble(survivalSlots[2], 'R3')}
                    {renderPlayerBubble(survivalSlots[3], 'R4')}
                  </div>
                </div>

                {/* CENTER GRID LINE (The Flank Line): 4 agile Flankers and Grenadier/Bombers */}
                <div>
                  <p className="text-center text-[9px] font-mono tracking-widest text-teal-400 uppercase mb-1 font-bold">
                    🛡️ Mid Core (Flank Line - Flankers & Bombers)
                  </p>
                  <div className="grid grid-cols-4 gap-2 justify-items-center">
                    {renderPlayerBubble(survivalSlots[4], 'BM1')}
                    {renderPlayerBubble(survivalSlots[5], 'BM2')}
                    {renderPlayerBubble(survivalSlots[6], 'SP1')}
                    {renderPlayerBubble(survivalSlots[7], 'SP2')}
                  </div>
                </div>

                {/* BASELINE GRID LINE (The Anchor Line): 3 heavy-damage Snipers and tactical Support */}
                <div>
                  <p className="text-center text-[9px] font-mono tracking-widest text-blue-400 uppercase mb-1 font-bold">
                    🎯 Baseline (Anchor Line - Snipers & Support)
                  </p>
                  <div className="grid grid-cols-3 gap-2 justify-items-center max-w-[280px] mx-auto">
                    {renderPlayerBubble(survivalSlots[8], 'SN1')}
                    {renderPlayerBubble(survivalSlots[9], 'SN2')}
                    {renderPlayerBubble(survivalSlots[10], 'SP3')}
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Map Stats Footer */}
      <div className="bg-[#13192B] border-t border-[#222D4A] p-4 text-center">
        <div className="max-w-md mx-auto flex items-center justify-between text-xs font-mono">
          <div className="flex items-center gap-1.5 text-gray-400">
            <MapPin className="w-4 h-4 text-[#FF4500]" />
            <span>Map: Bermudian Drop-Zone</span>
          </div>
          <div className="text-[#00FFCC] font-bold uppercase tracking-wider text-[11px]">
            Active Force Status: Operational
          </div>
        </div>
      </div>
    </div>
  );
}
