import React, { useState, useEffect } from 'react';
import { User } from '../types';
import { getUsers, saveUsers, setCurrentUser } from '../db';
import { generateReferralCode } from '../utils';
import { User as UserIcon, Phone, ShieldCheck, Eye, EyeOff, ShieldAlert, KeyRound, ArrowRight, CheckCircle2, Lock, Sparkles, ArrowLeft } from 'lucide-react';
import SquadLogo from './SquadLogo';
import { isConfigured, db } from '../firebase';
import { collection, getDocs } from 'firebase/firestore';

interface LoginSignupProps {
  onAuthSuccess: (user: User) => void;
}

export default function LoginSignup({ onAuthSuccess }: LoginSignupProps) {
  const [isLogin, setIsLogin] = useState(true);
  const [isForgotPassword, setIsForgotPassword] = useState(false);

  // Authentication Fields (Login / Signup)
  const [phone, setPhone] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [recoveryPin, setRecoveryPin] = useState(''); // Recovery PIN setup on Sign Up
  const [showPassword, setShowPassword] = useState(false);
  const [showRecoveryPin, setShowRecoveryPin] = useState(false);
  const [referralCodeInput, setReferralCodeInput] = useState('');

  // Loaded database user directories for real-time validation checks
  const [dbUsers, setDbUsers] = useState<User[]>([]);

  useEffect(() => {
    // Initial local store mirror loads
    setDbUsers(getUsers());

    if (isConfigured && db) {
      getDocs(collection(db, 'valent_users'))
        .then((snapshot) => {
          const freshUsers: User[] = [];
          snapshot.forEach((docRef) => {
            freshUsers.push({ ...docRef.data(), id: docRef.id } as User);
          });
          setDbUsers(freshUsers);
          saveUsers(freshUsers);
        })
        .catch((err) => {
          console.warn("Real-time users directory synch failed:", err);
        });
    }
  }, [isConfigured]);

  // Password Reset Recovery Fields
  const [resetPhone, setResetPhone] = useState('');
  const [resetPin, setResetPin] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [showResetFields, setShowResetFields] = useState(false);

  // General States
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Generic digits-only change handlers
  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.replace(/\D/g, ''); // Digits only
    if (val.length <= 10) {
      setPhone(val);
    }
  };

  const handleResetPhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.replace(/\D/g, '');
    if (val.length <= 10) {
      setResetPhone(val);
    }
  };

  const handleRecoveryPinChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.replace(/\D/g, '');
    if (val.length <= 6) {
      setRecoveryPin(val);
    }
  };

  const handleResetPinChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.replace(/\D/g, '');
    if (val.length <= 6) {
      setResetPin(val);
    }
  };

  // Submit Logic for Sign In & Sign Up
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    // Common validations
    if (phone.length < 8) {
      setError('⚠️ Please enter a valid phone number (minimum 8 digits).');
      return;
    }

    if (password.length < 6) {
      setError('⚠️ Password must be at least 6 characters in length.');
      return;
    }

    if (!isLogin && !username.trim()) {
      setError('⚠️ Please specify a distinct Game Name / Alias.');
      return;
    }

    if (!isLogin && (recoveryPin.length < 4 || recoveryPin.length > 6)) {
      setError('⚠️ Recovery PIN must be between 4 and 6 numeric digits.');
      return;
    }

    setIsLoading(true);

    try {
      let users = getUsers();
      if (isConfigured && db) {
        try {
          const snapshot = await getDocs(collection(db, 'valent_users'));
          const freshUsers: User[] = [];
          snapshot.forEach((docRef) => {
            freshUsers.push({ ...docRef.data(), id: docRef.id } as User);
          });
          users = freshUsers;
          saveUsers(freshUsers); // Save directly to update local storage synchronously
        } catch (e: any) {
          console.warn("Direct Firestore load failed, fell back to offline storage:", e.message);
        }
      }

      if (isLogin) {
        // --- SIGN IN FLOW ---
        const foundUser = users.find((u) => u.phone === phone);

        if (!foundUser) {
          setError('ℹ️ Account not found. We have logically transitioned you to the Registration screen to create a new VALENT account!');
          setIsLogin(false);
          setIsLoading(false);
          return;
        }

        if (foundUser.isBanned) {
          setError('🚨 Account Suspended: Access denied by VALENT integrity team due to gameplay matching rules violation.');
          setIsLoading(false);
          return;
        }

        // Check if password matches
        // (Fallback: we also check u.pin if password isn't set, to ensure smooth transition of default users)
        const isPasswordValid = foundUser.password === password || (!foundUser.password && foundUser.pin === password);
        if (!isPasswordValid) {
          setError('❌ Access Denied: Incorrect password. Please try again or recover using your PIN.');
          setIsLoading(false);
          return;
        }

        // Successful Sign In
        setCurrentUser(foundUser);
        setSuccess('✅ Credentials verified! Instating secure gaming vault...');
        onAuthSuccess(foundUser);
        setIsLoading(false);

      } else {
        // --- SIGN UP FLOW ---
        const phoneExists = users.some((u) => u.phone === phone);
        if (phoneExists) {
          setError('⚠️ Account already signed, please login');
          setIsLoading(false);
          return;
        }

        const usernameExists = users.some((u) => u.username.toLowerCase() === username.trim().toLowerCase());
        if (usernameExists) {
          setError('⚠️ Game handle already taken! Please try another name.');
          setIsLoading(false);
          return;
        }

        let matchedInviter: User | undefined;
        if (referralCodeInput.trim()) {
          matchedInviter = users.find(
            (u) => 
              (u.referralCode && u.referralCode.toUpperCase() === referralCodeInput.trim().toUpperCase()) ||
              (u.username && u.username.toUpperCase() === referralCodeInput.trim().toUpperCase())
          );
          if (!matchedInviter) {
            setError('⚠️ Invalid Referral Code! Please double-check the spelling or leave it blank.');
            setIsLoading(false);
            return;
          }
        }

        const isOwner = phone === '9260914905';

        // Build a compliant user object. Predictable unique ID prevents overlapping database entries
        const newUser: User = {
          id: phone === '9260914905' ? 'admin-owner' : `user-${phone}`,
          email: `${phone}@valent.com`,
          username: username.trim(),
          role: isOwner ? 'admin' : 'player',
          is_admin: isOwner,
          wallet: {
            deposit: 0,
            winnings: 0,
            bonus: 0,
          },
          password: password,
          pin: recoveryPin, // using .pin as the recovery PIN!
          phone: phone,
          referralCode: generateReferralCode(),
          referredBy: matchedInviter ? matchedInviter.referralCode : undefined,
          referredByUserId: matchedInviter ? matchedInviter.id : undefined,
          isReferralRewardPaid: false,
          hasJoinedFirstGame: false,
        };

        const updatedUsers = [...users, newUser];
        saveUsers(updatedUsers);
        setCurrentUser(newUser);

        setSuccess(isOwner 
          ? '👑 Admin Account Enrolled! Deploying fresh system administrator profile...'
          : '🎉 Enrolled successfully! Setting up your lobby access...'
        );
        onAuthSuccess(newUser);
        setIsLoading(false);
      }
    } catch (err: any) {
      setError(`⚠️ System crash during authenticating: ${err.message}`);
      setIsLoading(false);
    }
  };

  // Safe Forgotten Password Recovery (Reset password via Phone and Secret recovery PIN)
  const handlePasswordRecovery = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (resetPhone.length < 8) {
      setError('⚠️ Please enter a valid registered Phone Number.');
      return;
    }

    if (resetPin.length < 4 || resetPin.length > 6) {
      setError('⚠️ Please enter your active 4-6 digit Secret Recovery PIN.');
      return;
    }

    if (newPassword.length < 6) {
      setError('⚠️ New Password must be at least 6 characters.');
      return;
    }

    if (newPassword !== confirmNewPassword) {
      setError('⚠️ Passcode discrepancy: New password confirmation does not match.');
      return;
    }

    setIsLoading(true);

    setTimeout(() => {
      try {
        const users = getUsers();
        const targetIdx = users.findIndex((u) => u.phone === resetPhone && u.pin === resetPin);

        if (targetIdx === -1) {
          setError('❌ Verification Failed: No account matches this combination of Phone Number and Recovery PIN.');
          setIsLoading(false);
          return;
        }

        const userObj = users[targetIdx];
        if (userObj.isBanned) {
          setError('🚨 Disqualified: Suspended accounts cannot execute password updates.');
          setIsLoading(false);
          return;
        }

        // Apply rewritten password
        userObj.password = newPassword;
        users[targetIdx] = userObj;
        saveUsers(users);

        setSuccess('🔐 Password securely updated! You can now log in.');
        setTimeout(() => {
          setIsForgotPassword(false);
          setPhone(resetPhone);
          setPassword(newPassword);
          setIsLoading(false);
        }, 1200);

      } catch (err: any) {
        setError(`⚠️ Error reconstructing security state: ${err.message}`);
        setIsLoading(false);
      }
    }, 800);
  };

  return (
    <div className="flex flex-col items-center justify-start w-full max-w-sm mx-auto py-2 shrink-0 h-auto">
      
      {/* Brand Header */}
      <div className="text-center mb-6 animate-fade-in flex flex-col items-center">
        <div className="bg-[#13192B]/40 p-3 rounded-3xl border border-[#222D4A]/50 backdrop-blur-sm self-center">
          <SquadLogo size="lg" showText={true} className="flex flex-col" />
        </div>
        <p className="text-[10px] text-[#FF0043] font-mono tracking-[0.25em] mt-3 uppercase font-extrabold bg-[#FF0043]/5 border border-[#FF0043]/20 px-4 py-1.5 rounded-full select-none">
          SECURE ESPORTS PORTAL
        </p>
      </div>

      {/* Main glassmorphic login board card */}
      <div className="w-full bg-gradient-to-b from-[#0F1629] to-[#0A0D18] border border-[#222D4A] rounded-3xl p-6 shadow-[0_20px_50px_rgba(0,0,0,0.85)] relative overflow-hidden transition-all duration-300">
        
        {/* Billion Dollar company glowing top accent line */}
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-[#FF4500] via-[#C60000] to-[#E63900]" />
        
        {/* Ambient light flares */}
        <div className="absolute -top-24 -left-24 w-48 h-48 bg-[#FF4500]/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-48 h-48 bg-[#FF0043]/5 rounded-full blur-3xl pointer-events-none" />

        {/* Global Error Banner */}
        {error && (
          <div className="mb-5 p-3.5 bg-red-950/40 border border-red-500/30 rounded-2xl text-[12px] text-red-100 flex items-start gap-2.5 animate-fade-in shadow-inner">
            <ShieldAlert className="w-5 h-5 shrink-0 text-red-400 mt-0.5" />
            <span className="leading-relaxed text-left">{error}</span>
          </div>
        )}

        {/* Global Success Banner */}
        {success && (
          <div className="mb-5 p-3.5 bg-emerald-950/40 border border-emerald-500/30 rounded-2xl text-[12px] text-emerald-200 flex items-start gap-2.5 animate-fade-in shadow-inner">
            <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-400 mt-0.5 animate-bounce" />
            <span className="leading-relaxed text-left font-semibold">{success}</span>
          </div>
        )}

        {/* PASSWORD RESET SCREEN */}
        {isForgotPassword ? (
          <div className="space-y-4 animate-fade-in text-left">
            <div className="flex items-center gap-3 pb-3 border-b border-[#222D4A]/50">
              <button
                type="button"
                onClick={() => {
                  setIsForgotPassword(false);
                  setError('');
                  setSuccess('');
                }}
                className="p-1.5 bg-[#070A11] border border-[#222D4A] rounded-xl text-gray-400 hover:text-white transition-colors cursor-pointer mr-0.5"
                title="Go Back"
              >
                <ArrowLeft className="w-4 h-4 text-[#FF4500]" />
              </button>
              <KeyRound className="w-4.5 h-4.5 text-[#FF4500] shrink-0" />
              <h2 className="text-[13px] md:text-sm font-display font-black text-white uppercase tracking-wider">
                Reset Password
              </h2>
            </div>
            
            <p className="text-[12px] text-gray-400 leading-relaxed font-sans mb-1">
              Verify your identity by typing your registered phone number and your 4-6 digit secret Recovery PIN, then write a new password.
            </p>

            <form onSubmit={handlePasswordRecovery} className="space-y-4">
              
              {/* Phone Input with Premium Indian Flag & +91 Prefix */}
              <div className="space-y-1.5 focus-within:text-[#FF4500] transition-colors">
                <label className="block text-[10px] font-mono text-gray-400 uppercase tracking-widest pl-1 font-bold">
                  Mobile Number (India)
                </label>
                <div className="relative flex items-center bg-[#070A11] border border-[#222D4A] rounded-xl focus-within:border-[#FF4500]/85 focus-within:ring-1 focus-within:ring-[#FF4500]/25 transition-all shadow-[inset_0_1px_3px_rgba(0,0,0,0.5)]">
                  {/* Flag and code badge */}
                  <div className="flex items-center gap-1.5 pl-3.5 pr-2.5 py-3 border-r border-[#222D4A]/50 shrink-0 select-none font-black bg-[#FF4500]/5 rounded-l-xl">
                    <span className="text-[14px] leading-none" role="img" aria-label="India Flag">🇮🇳</span>
                    <span className="text-xs font-mono font-black text-gray-400 tracking-wide">+91</span>
                  </div>
                  
                  <input
                    type="tel"
                    required
                    maxLength={10}
                    placeholder="Enter 10-digit number"
                    value={resetPhone}
                    onChange={handleResetPhoneChange}
                    className="w-full bg-transparent py-3 px-3 text-white text-sm font-mono font-bold focus:outline-none placeholder-gray-600 tracking-widest"
                  />
                  
                  <span className="pr-3.5 text-gray-500 select-none shrink-0">
                    <Phone className="w-4 h-4" />
                  </span>
                </div>
              </div>

              {/* Secret Recovery PIN Input */}
              <div className="space-y-1.5 focus-within:text-[#FF4500] transition-colors">
                <label className="block text-[10px] font-mono text-gray-400 uppercase tracking-widest pl-1 font-bold">
                  Secret Recovery PIN (4-6 digits)
                </label>
                <div className="relative flex items-center bg-[#070A11] border border-[#222D4A] rounded-xl focus-within:border-[#FF4500]/85 focus-within:ring-1 focus-within:ring-[#FF4500]/25 transition-all shadow-[inset_0_1px_3px_rgba(0,0,0,0.5)]">
                  <span className="pl-3.5 text-gray-550">
                    <ShieldCheck className="w-4.5 h-4.5" />
                  </span>
                  <input
                    type="password"
                    required
                    maxLength={6}
                    placeholder="Enter Recovery PIN"
                    value={resetPin}
                    onChange={handleResetPinChange}
                    className="w-full bg-transparent py-3 px-3 text-white text-sm font-mono font-bold focus:outline-none placeholder-gray-650 tracking-widest text-center"
                  />
                </div>
              </div>

              {/* New Password row */}
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="block text-[10px] font-mono text-gray-400 uppercase tracking-widest pl-1 font-bold">
                    New Password
                  </label>
                  <input
                    type="password"
                    required
                    maxLength={32}
                    placeholder="New Pass"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="w-full bg-[#070A11] border border-[#222D4A] rounded-xl py-3 px-3 text-white text-sm focus:outline-none focus:border-[#FF4500]/85 placeholder-gray-650 font-bold"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-[10px] font-mono text-gray-400 uppercase tracking-widest pl-1 font-bold">
                    Confirm Pass
                  </label>
                  <input
                    type="password"
                    required
                    maxLength={32}
                    placeholder="Confirm"
                    value={confirmNewPassword}
                    onChange={(e) => setConfirmNewPassword(e.target.value)}
                    className="w-full bg-[#070A11] border border-[#222D4A] rounded-xl py-3 px-3 text-white text-sm focus:outline-none focus:border-[#FF4500]/85 placeholder-gray-650 font-bold"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className={`w-full mt-4 py-3.5 text-white font-display font-black text-xs rounded-xl uppercase tracking-widest shadow-lg shadow-red-950/30 active:scale-[0.98] transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  isLoading
                    ? 'bg-gray-800 border border-gray-700 pointer-events-none opacity-60'
                    : 'bg-gradient-to-r from-[#FF4500] to-[#C60000] hover:scale-[1.01] hover:shadow-[0_0_15px_rgba(255,69,0,0.35)]'
                }`}
              >
                {isLoading && (
                  <span className="w-3.5 h-3.5 border-2 border-white/35 border-t-white rounded-full animate-spin" />
                )}
                {isLoading ? 'SAVING UPDATES...' : 'RESET PASSWORD & SIGN IN'}
              </button>

              <button
                type="button"
                onClick={() => {
                  setIsForgotPassword(false);
                  setError('');
                  setSuccess('');
                }}
                className="w-full py-2 text-center text-xs font-mono text-gray-450 hover:text-white transition-colors block cursor-pointer"
              >
                ← Return to login
              </button>
            </form>
          </div>
        ) : (
          /* STANDARD BILLION DOLLAR TABS */
          <div>
            <div className="grid grid-cols-2 bg-[#070A11]/80 rounded-2xl p-1.5 border border-[#222D4A]/80 mb-6 relative">
              <button
                type="button"
                onClick={() => {
                  setIsLogin(true);
                  setError('');
                  setSuccess('');
                }}
                className={`text-xs font-display font-extrabold py-2.5 rounded-xl uppercase tracking-widest transition-all duration-300 relative z-10 cursor-pointer ${
                  isLogin ? 'text-white bg-gradient-to-r from-[#FF4500]/95 to-[#FF4500] shadow-[0_4px_12px_rgba(255,69,0,0.25)]' : 'text-gray-400 hover:text-gray-200'
                }`}
              >
                🔒 SECURE LOGIN
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsLogin(false);
                  setError('');
                  setSuccess('');
                }}
                className={`text-xs font-display font-extrabold py-2.5 rounded-xl uppercase tracking-widest transition-all duration-300 relative z-10 cursor-pointer ${
                  !isLogin ? 'text-white bg-gradient-to-r from-[#FF4500]/95 to-[#FF4500] shadow-[0_4px_12px_rgba(255,69,0,0.25)]' : 'text-gray-400 hover:text-gray-200'
                }`}
              >
                ⚔️ REGISTRATION
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4 text-left">
              
              {/* Phone Input with Premium Indian Flag & +91 Prefix */}
              <div className="space-y-1.5 focus-within:text-[#FF4500] transition-colors">
                <label className="block text-[10px] font-mono text-gray-400 uppercase tracking-widest pl-1 font-black">
                  Mobile Number (India)
                </label>
                <div className="relative flex items-center bg-[#070A11] border border-[#222D4A] rounded-xl focus-within:border-[#FF4500]/80 focus-within:ring-1 focus-within:ring-[#FF4500]/20 transition-all shadow-[inset_0_1px_3px_rgba(0,0,0,0.5)]">
                  {/* Flag and code badge */}
                  <div className="flex items-center gap-1.5 pl-3.5 pr-2.5 py-3 border-r border-[#222D4A]/50 shrink-0 select-none">
                    <span className="text-[14px] leading-none" role="img" aria-label="India Flag">🇮🇳</span>
                    <span className="text-xs font-mono font-black text-gray-400 tracking-wide">+91</span>
                  </div>
                  
                  <input
                    type="tel"
                    required
                    maxLength={10}
                    placeholder="Enter 10-digit number"
                    value={phone}
                    onChange={handlePhoneChange}
                    className="w-full bg-transparent py-3 px-3 text-white text-sm font-mono font-bold focus:outline-none placeholder-gray-650 tracking-widest"
                  />
                  
                  <span className="pr-3.5 text-gray-500 select-none">
                    <Phone className="w-4 h-4" />
                  </span>
                </div>
              </div>

              {/* Game Handle Input (Only on Sign Up) */}
              {!isLogin && (
                <div className="space-y-1.5 focus-within:text-[#FF4500] transition-colors">
                  <label className="block text-[10px] font-mono text-gray-400 uppercase tracking-widest pl-1 font-black">
                    Game Alias Handle (IGN)
                  </label>
                  <div className="relative flex items-center bg-[#070A11] border border-[#222D4A] rounded-xl focus-within:border-[#FF4500]/80 focus-within:ring-1 focus-within:ring-[#FF4500]/20 transition-all shadow-[inset_0_1px_3px_rgba(0,0,0,0.5)]">
                    <span className="pl-3.5 text-gray-550 select-none">
                      <UserIcon className="w-4 h-4" />
                    </span>
                    <input
                      type="text"
                      required
                      placeholder="e.g. MaxWinner"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      className="w-full bg-transparent py-3 px-3 text-white text-sm focus:outline-none placeholder-gray-650 font-bold"
                    />
                  </div>
                </div>
              )}

              {/* Password Input */}
              <div className="space-y-1.5 focus-within:text-[#FF4500] transition-colors">
                <div className="flex justify-between items-center px-1">
                  <label className="block text-[10px] font-mono text-gray-400 uppercase tracking-widest font-black">
                    Account Password
                  </label>
                  {isLogin && (
                    <button
                      type="button"
                      onClick={() => {
                        setIsForgotPassword(true);
                        setError('');
                        setSuccess('');
                      }}
                      className="text-[9.5px] font-mono text-[#00FFCC] leading-none hover:underline uppercase font-extrabold tracking-wider bg-[#00FFCC]/5 border border-[#00FFCC]/15 px-2 py-0.5 rounded cursor-pointer"
                    >
                      FORGOT PASSWORD?
                    </button>
                  )}
                </div>
                
                <div className="relative flex items-center bg-[#070A11] border border-[#222D4A] rounded-xl focus-within:border-[#FF4500]/80 focus-within:ring-1 focus-within:ring-[#FF4500]/20 transition-all shadow-[inset_0_1px_3px_rgba(0,0,0,0.5)]">
                  <span className="pl-3.5 text-gray-550 select-none">
                    <Lock className="w-4.5 h-4.5" />
                  </span>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    maxLength={32}
                    placeholder={isLogin ? "Enter account password" : "Create strong password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-transparent py-3.5 px-3 text-white text-sm font-mono font-bold focus:outline-none placeholder-gray-650 tracking-wider"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-3 flex items-center pr-1 text-gray-550 hover:text-gray-300 transition-colors"
                  >
                    {showPassword ? <EyeOff className="w-4.5 h-4.5" /> : <Eye className="w-4.5 h-4.5" />}
                  </button>
                </div>
              </div>

              {/* Secret Recovery PIN (Only on Sign Up) */}
              {!isLogin && (
                <div className="space-y-1.5 focus-within:text-[#FF4500] transition-colors">
                  <label className="block text-[10px] font-mono text-gray-400 uppercase tracking-widest pl-1 font-black">
                    Setup Secret Recovery PIN (4-6 digits)
                  </label>
                  <div className="relative flex items-center bg-[#070A11] border border-[#222D4A] rounded-xl focus-within:border-[#FF4500]/80 focus-within:ring-1 focus-within:ring-[#FF4500]/20 transition-all shadow-[inset_0_1px_3px_rgba(0,0,0,0.5)]">
                    <span className="pl-3.5 text-gray-550 select-none">
                      <ShieldCheck className="w-4.5 h-4.5" />
                    </span>
                    <input
                      type={showRecoveryPin ? 'text' : 'password'}
                      required
                      placeholder="Enter a secret recovery PIN"
                      value={recoveryPin}
                      onChange={handleRecoveryPinChange}
                      className="w-full bg-transparent py-3.5 px-3 text-white text-sm font-mono font-bold focus:outline-none placeholder-gray-650 tracking-widest text-center"
                    />
                    <button
                      type="button"
                      onClick={() => setShowRecoveryPin(!showRecoveryPin)}
                      className="absolute inset-y-0 right-3 flex items-center pr-1 text-gray-550 hover:text-gray-300 transition-colors"
                    >
                      {showRecoveryPin ? <EyeOff className="w-4.5 h-4.5" /> : <Eye className="w-4.5 h-4.5" />}
                    </button>
                  </div>
                  <p className="text-[9.5px] text-gray-500 font-mono mt-1 pl-1 select-none leading-relaxed text-left animate-pulse">
                    ⚠️ Save this PIN carefully. You must supply your phone and this secret Recovery PIN to change your password if you ever forget it.
                  </p>
                </div>
              )}

                  {/* Referral Code optional input field (Only on Sign Up) */}
              {!isLogin && (
                <div className="space-y-1.5 focus-within:text-[#FF4500] transition-colors" id="referral-input-container">
                  <label className="block text-[10px] font-mono text-gray-400 uppercase tracking-widest pl-1 font-black">
                    Referral Code (Optional)
                  </label>
                  <div className="relative flex items-center bg-[#070A11] border border-[#222D4A] rounded-xl focus-within:border-[#FF4500]/80 focus-within:ring-1 focus-within:ring-[#FF4500]/20 transition-all shadow-[inset_0_1px_3px_rgba(0,0,0,0.5)]">
                    <span className="pl-3.5 text-gray-550 select-none">
                      <Sparkles className="w-4 h-4 text-amber-500 font-bold" />
                    </span>
                    <input
                      type="text"
                      placeholder="e.g. SQUADMEMBER"
                      value={referralCodeInput}
                      onChange={(e) => setReferralCodeInput(e.target.value)}
                      className="w-full bg-transparent py-3.5 px-3 text-white text-sm font-mono font-bold focus:outline-none placeholder-gray-650 tracking-wider uppercase"
                    />
                  </div>
                  {(() => {
                    if (!referralCodeInput.trim()) {
                      return (
                        <p className="text-[9.5px] text-gray-400 font-mono mt-1 pl-1 select-none text-left">
                          Enter the referral code. If that person deposits ₹60 you will get ₹25.
                        </p>
                      );
                    }
                    const code = referralCodeInput.trim().toUpperCase();
                    const matchedInviterObj = dbUsers.find(
                      (u) => 
                        (u.referralCode && u.referralCode.toUpperCase() === code) ||
                        (u.username && u.username.toUpperCase() === code)
                    );
                    if (matchedInviterObj) {
                      return (
                        <div className="flex items-center gap-1 mt-1 pl-1 text-[8.5px] text-emerald-400 font-mono select-none text-left animate-fade-in font-bold uppercase tracking-wider">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                          <span>Referral code is correct (Invited by @{matchedInviterObj.username})</span>
                        </div>
                      );
                    } else {
                      return (
                        <p className="text-[9.5px] text-rose-500 font-mono mt-1 pl-1 select-none text-left font-semibold">
                          ⚠️ Invalid referral code. Double check spelling or leave blank.
                        </p>
                      );
                    }
                  })()}
                </div>
              )}

              <button
                type="submit"
                id="auth-submit-btn"
                disabled={isLoading}
                className={`w-full mt-6 py-4 hover:scale-[1.01] active:scale-[0.98] transition-all text-white font-display font-black rounded-xl text-xs uppercase tracking-widest shadow-lg shadow-orange-950/20 flex items-center justify-center gap-1.5 cursor-pointer ${
                  isLoading
                    ? 'bg-gray-800 border border-gray-700 pointer-events-none opacity-60'
                    : 'bg-gradient-to-r from-[#FF4500] to-[#C60000] hover:shadow-[0_0_15px_rgba(255,69,0,0.35)]'
                }`}
              >
                {isLoading && (
                  <span className="w-3.5 h-3.5 border-2 border-white/35 border-t-white rounded-full animate-spin" />
                )}
                {isLoading 
                  ? (isLogin ? 'VERIFYING SECURITY KEY...' : 'CREATING DIGITAL VAULT...') 
                  : (isLogin ? 'AUTHENTICATE & LOG IN' : 'CONFIRM REGISTRATION')
                }
                {!isLoading && <ArrowRight className="w-4.5 h-4.5" />}
              </button>
            </form>

            <p className="mt-6 text-center text-xs text-gray-500 font-mono">
              {isLogin ? "NEED A PROFESSIONAL ACCOUNT?" : "ALREADY ENLISTED IN SQUAD?"}
              <button
                type="button"
                className="text-[#FF4500] font-black ml-1.5 underline hover:text-[#C60000] cursor-pointer"
                onClick={() => {
                  setIsLogin(!isLogin);
                  setError('');
                  setSuccess('');
                }}
              >
                {isLogin ? 'SIGN UP HERE' : 'LOG IN HERE'}
              </button>
            </p>
          </div>
        )}
      </div>

      {/* Brand Secure telemetry display */}
      <div className="mt-6 flex items-center gap-2 text-gray-500 text-[10.5px] font-mono tracking-wider uppercase select-none">
        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
        Secured Esports Portal (SSL 256-Bit Encrypted)
      </div>


    </div>
  );
}
