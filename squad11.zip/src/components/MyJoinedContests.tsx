import React, { useState, useEffect } from 'react';
import { Match, User } from '../types';
import { getMatches, getCurrentUser } from '../db';
import { Trophy, Clock, ShieldCheck, ArrowRight, Flame, Users, Sparkles, LogIn } from 'lucide-react';

interface MyJoinedContestsProps {
  userId: string;
  onExploreMatches: () => void;
}

export default function MyJoinedContests({ userId, onExploreMatches }: MyJoinedContestsProps) {
  const [joinedMatches, setJoinedMatches] = useState<Match[]>([]);
  const [allMatches, setAllMatches] = useState<Match[]>([]);
  const [tick, setTick] = useState(0);

  useEffect(() => {
    // Tick second-by-second to enable smooth live countdown updates
    const timerInterval = setInterval(() => {
      setTick(t => t + 1);
    }, 1000);
    return () => clearInterval(timerInterval);
  }, []);

  useEffect(() => {
    const reload = () => {
      const matches = getMatches();
      setAllMatches(matches);
      // Filter matches we are registered in
      const filtered = matches.filter(m => m.players.some(p => p.userId === userId));
      setJoinedMatches(filtered);
    };
    reload();
    window.addEventListener('valent_db_update', reload);
    return () => {
      window.removeEventListener('valent_db_update', reload);
    };
  }, [userId]);

  return (
    <div className="max-w-md mx-auto p-4 space-y-6 animate-fade-in text-white pb-28">
      {/* Page Header */}
      <div className="text-left">
        <span className="text-[11px] font-mono text-[#00FFCC] uppercase tracking-widest block font-bold">
          Survival History log
        </span>
        <h2 className="text-xl font-display font-black text-white tracking-wide uppercase mt-1">
          My Registered Matches
        </h2>
        <p className="text-[13px] text-gray-300 mt-1 leading-relaxed">
          Review credentials, upload match proof screenshots, and track payouts of joined custom lobbies.
        </p>
      </div>

      <div className="space-y-4">
        {joinedMatches.map((record) => {
          const userPlayerObj = record.players.find(p => p.userId === userId);
          const percent = Math.min(100, (record.spotsFilled / record.spotsTotal) * 100);

          let statusTheme = 'bg-orange-95/20 text-orange-400 border-orange-500/30';
          if (record.status === 'ROOM_READY') statusTheme = 'bg-[#00FFCC]/15 text-[#00FFCC] border-[#00FFCC]/35';
          if (record.status === 'COMPLETED') statusTheme = 'bg-emerald-95/20 text-emerald-400 border-emerald-500/30';
          if (record.status === 'DISPUTED') statusTheme = 'bg-red-95/20 text-red-500 border-red-500/30';

          return (
            <div
              key={record.id}
              className="bg-[#0D1426] border border-[#222D4A] rounded-2xl p-5 shadow-xl relative overflow-hidden transition-all hover:border-[#FF4500]/50"
            >
              <div className="flex justify-between items-start border-b border-[#222D4A]/50 pb-3 mb-3.5 text-xs font-mono">
                <div>
                  <h4 className="font-display font-black text-white uppercase text-sm tracking-wide">
                    {record.title}
                  </h4>
                  <span className="text-[10px] text-[#00FFCC] font-black uppercase mt-1.5 block tracking-wider">
                    🌐 Arena Map: {record.mapName}
                  </span>
                </div>

                <div className="text-right shrink-0 pl-2">
                  <span className={`text-[10px] font-mono border px-2.5 py-0.5 rounded-md uppercase font-black tracking-widest ${statusTheme}`}>
                    {record.status}
                  </span>
                </div>
              </div>

              {/* Dynamic Live Timers inside Registered Contests Page */}
              {(() => {
                const now = new Date();
                const revealTime = record.credentialsRevealTime ? new Date(record.credentialsRevealTime) : null;
                const startTime = record.matchStartTime ? new Date(record.matchStartTime) : null;

                const isBeforeReveal = revealTime && now < revealTime;
                const isBeforeStart = startTime && now < startTime;

                if (isBeforeStart || isBeforeReveal) {
                  let revealMins = 0, revealSecs = "00";
                  let startMins = 0, startSecs = "00";

                  if (isBeforeReveal) {
                    const revealDiff = revealTime.getTime() - now.getTime();
                    revealMins = Math.floor(revealDiff / 60000);
                    revealSecs = Math.floor((revealDiff % 60000) / 1000).toString().padStart(2, '0');
                  }

                  if (isBeforeStart) {
                    const startDiff = startTime.getTime() - now.getTime();
                    startMins = Math.floor(startDiff / 60000);
                    startSecs = Math.floor((startDiff % 60000) / 1000).toString().padStart(2, '0');
                  }

                  return (
                    <div className="grid grid-cols-2 gap-2.5 text-center mb-3.5">
                      {isBeforeStart && (
                        <div className="bg-[#FF4500]/10 border border-[#FF4500]/25 p-2 rounded-xl">
                          <span className="text-[7.5px] font-mono font-black text-gray-400 uppercase tracking-wider block">Game Starting In</span>
                          <span className="text-xs font-mono font-black text-[#FF4500] animate-pulse block mt-0.5">
                            {startMins}:{startSecs}
                          </span>
                        </div>
                      )}
                      {isBeforeReveal ? (
                        <div className="bg-amber-500/5 border border-amber-500/25 p-2 rounded-xl">
                          <span className="text-[7.5px] font-mono font-black text-gray-400 uppercase tracking-wider block">ID/PW Reveal In</span>
                          <span className="text-xs font-mono font-black text-amber-500 animate-pulse block mt-0.5">
                            {revealMins}:{revealSecs}
                          </span>
                        </div>
                      ) : (
                        <div className="bg-[#00FFCC]/5 border border-[#00FFCC]/25 p-2 rounded-xl flex flex-col justify-center">
                          <span className="text-[7.5px] font-mono font-black text-gray-400 uppercase tracking-wider block">Credentials</span>
                          <span className="text-xs font-mono font-black text-[#00FFCC] block mt-0.5 animate-pulse">
                            REVEALED 🔑
                          </span>
                        </div>
                      )}
                    </div>
                  );
                }
                return null;
              })()}

              {/* Lobby overview parameters */}
              <div className="grid grid-cols-2 gap-3 text-xs font-mono mb-4 text-left">
                <div className="bg-[#0A0E17]/80 p-2.5 border border-[#222D4A]/50 rounded-xl shadow-inner">
                  <span className="text-[9px] text-gray-400 uppercase tracking-wider block font-bold">My IGN</span>
                  <span className="text-sm text-gray-100 uppercase font-extrabold truncate block mt-0.5">{userPlayerObj?.ign || 'UNKNOWN'}</span>
                </div>

                <div className="bg-[#0A0E17]/80 p-2.5 border border-[#222D4A]/50 rounded-xl shadow-inner">
                  <span className="text-[9px] text-gray-400 uppercase tracking-wider block font-bold">Allocated Team</span>
                  <span className={`text-sm uppercase font-black block mt-0.5 ${userPlayerObj?.team === 'A' ? 'text-orange-500' : 'text-blue-400'}`}>
                    Team {userPlayerObj?.team === 'A' ? 'Alpha' : 'Beta'}
                  </span>
                </div>
              </div>

              {/* Prize Pool & Player Payout summary row */}
              {record.prizePerPlayer && record.prizePerPlayer > 0 ? (
                <div className="bg-[#111625] border border-[#223354] rounded-xl px-3.5 py-3 flex items-center justify-between text-left shadow-inner mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/25 flex items-center justify-center text-lg shadow-[0_0_8px_rgba(245,158,11,0.1)] shrink-0">
                      🏆
                    </div>
                    <div className="space-y-0.5">
                      <span className="text-[10px] font-mono font-bold text-amber-400 uppercase tracking-widest block">INDIVIDUAL WINNER PAYOUT</span>
                      <span className="text-[9px] text-gray-400 font-medium block">Each member of the winning slot receives:</span>
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="text-sm font-mono font-black text-[#00FFCC] bg-black/40 px-3 py-1.5 rounded-lg border border-[#222D4A] shadow-inner block">
                      ₹{record.prizePerPlayer}
                    </span>
                  </div>
                </div>
              ) : null}

              {/* Spots bar */}
              <div className="space-y-2 pb-2">
                <div className="flex justify-between items-center text-xs font-mono text-gray-300">
                  <span className="flex items-center gap-1.5 font-bold">
                    <Users className="w-4 h-4 text-gray-400" />
                    <span>Lobby Seats: {record.spotsFilled}/{record.spotsTotal} filled</span>
                  </span>
                </div>
                <div className="w-full h-2 bg-[#060911] rounded-full overflow-hidden border border-[#222D4A]/30">
                  <div
                    className="h-full bg-gradient-to-r from-[#FF4500] to-[#FF8C00] transition-all rounded-full"
                    style={{ width: `${percent}%` }}
                  />
                </div>
              </div>

              {/* Footer row displaying action to redirect user to current room details instantly */}
              <div className="flex justify-between items-center pt-3 border-t border-[#222D4A]/55 font-mono text-[11px] mt-2.5">
                <span className="text-gray-400 font-extrabold uppercase">
                  Payout Winner: <span className="text-emerald-400">{record.winningTeam ? `Team ${record.winningTeam}` : 'TBD'}</span>
                </span>

                <button
                  onClick={() => onExploreMatches()}
                  className="text-[#00FFCC] font-black uppercase tracking-wider hover:underline inline-flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <span>Open workspace</span>
                  <ArrowRight className="w-4 h-4 text-[#00FFCC]" />
                </button>
              </div>
            </div>
          );
        })}

        {joinedMatches.length === 0 && (
          <div className="p-16 text-center bg-[#13192B]/50 border border-[#222D4A]/50 rounded-2.5xl">
            <Trophy className="w-12 h-12 text-gray-600 mx-auto mb-4" />
            <h4 className="font-mono text-gray-300 font-bold uppercase text-sm">No Matches Joined Yet</h4>
            <p className="text-xs text-gray-500 mt-2 max-w-xs mx-auto leading-relaxed">
              Register for one of our active 4v4, 6v6, or Battle Royale custom rooms to start earning real UPI money.
            </p>
            <button
              onClick={onExploreMatches}
              className="mt-6 px-5 py-3 text-[11px] font-display font-black uppercase tracking-widest bg-gradient-to-r from-[#FF4500] to-[#C60000] text-white rounded-xl shadow-lg cursor-pointer hover:scale-103 active:scale-97 transition-all"
            >
              Explore lobbies now
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
