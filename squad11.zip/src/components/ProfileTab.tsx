import React, { useState, useEffect, useRef } from 'react';
import { User, SupportMessage } from '../types';
import { compressImage } from '../utils';
import {
  getCurrentUser,
  setCurrentUser,
  getUsers,
  saveUsers,
  getMatches,
  getSupportMessages,
  saveSupportMessages,
  getAdminPaymentSettings
} from '../db';
import {
  User as UserIcon,
  Flame,
  Award,
  Upload,
  Trophy,
  Activity,
  Shield,
  CheckCircle,
  Coins,
  ChevronRight,
  LogOut,
  Headphones,
  MessageSquare,
  Send,
  X,
  ShieldAlert,
  Sparkles,
  AlertCircle,
  Copy,
  MessageCircle,
  Image as ImageIcon,
  Loader2
} from 'lucide-react';

export default function ProfileTab({ onLogout }: { onLogout?: () => void }) {
  const [user, setUserState] = useState<User | null>(() => getCurrentUser());
  const [username, setUsername] = useState('');
  const [photoUrl, setPhotoUrl] = useState('');
  const [registeredCount, setRegisteredCount] = useState(0);
  const [completedCount, setCompletedCount] = useState(0);
  const [isSaved, setIsSaved] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false);
  const [copiedRef, setCopiedRef] = useState(false);
  const [whatsappGroupUrl, setWhatsappGroupUrl] = useState('');

  // Live support states
  const [showSupport, setShowSupport] = useState(false);
  const [chatText, setChatText] = useState('');
  const [chatImage, setChatImage] = useState<string>('');
  const [isCompressing, setIsCompressing] = useState(false);
  const [zoomImage, setZoomImage] = useState<string | null>(null);
  const chatFileInputRef = useRef<HTMLInputElement>(null);
  const [messages, setMessages] = useState<SupportMessage[]>([]);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Dynamic user and stats loading hook (including database update listener)
  useEffect(() => {
    const loadProfileData = () => {
      const liveUser = getCurrentUser();
      if (liveUser) {
        setUserState(liveUser);
        setUsername(liveUser.username);
        setPhotoUrl(liveUser.photoUrl || '');

        // Load stats real-time
        const matches = getMatches();
        const joined = matches.filter(m => m.players.some(p => p.userId === liveUser.id));
        setRegisteredCount(joined.length);

        const completed = joined.filter(m => m.status === 'COMPLETED');
        setCompletedCount(completed.length);

        // Filter messages for current user
        setMessages(getSupportMessages().filter(m => m.userId === liveUser.id));

        // Load WhatsApp Group Url setting from admin configurations
        const paymentSettings = getAdminPaymentSettings();
        setWhatsappGroupUrl(paymentSettings.whatsappGroupUrl || '');
      }
    };

    loadProfileData();
    window.addEventListener('valent_db_update', loadProfileData);
    return () => {
      window.removeEventListener('valent_db_update', loadProfileData);
    };
  }, []);

  // Sync messages list for active support chats
  useEffect(() => {
    if (user?.id) {
      setMessages(getSupportMessages().filter(m => m.userId === user.id));
    }
  }, [showSupport]);

  // Mark admin messages as read when opening support chat
  useEffect(() => {
    if (showSupport && user) {
      const allMsgs = getSupportMessages();
      let updated = false;
      const mapped = allMsgs.map(m => {
        if (m.userId === user.id && m.senderId === 'admin' && !m.readByUser) {
          updated = true;
          return { ...m, readByUser: true };
        }
        return m;
      });
      if (updated) {
        saveSupportMessages(mapped);
      }
    }
  }, [showSupport, messages.length, user]);

  // Auto scroll to latest support text in chat window
  useEffect(() => {
    if (showSupport) {
      setTimeout(() => {
        chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    }
  }, [messages.length, showSupport]);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64String = reader.result as string;
        try {
          const compressed = await compressImage(base64String, 300, 300, 0.6);
          setPhotoUrl(compressed);
          triggerDirectUpdate(username, compressed);
        } catch (err) {
          setPhotoUrl(base64String);
          triggerDirectUpdate(username, base64String);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const triggerDirectUpdate = (newUsername: string, newPhoto: string) => {
    const liveUser = getCurrentUser();
    if (!liveUser) return;

    if (!newUsername.trim()) {
      alert('Championship Warning: Username cannot be blank!');
      return;
    }

    const allUsers = getUsers();
    const userIndex = allUsers.findIndex((u) => u.id === liveUser.id);
    if (userIndex !== -1) {
      allUsers[userIndex].username = newUsername.trim();
      allUsers[userIndex].photoUrl = newPhoto || undefined;

      saveUsers(allUsers);

      // Save current user logged in status
      const updatedUser = {
        ...liveUser,
        username: newUsername.trim(),
        photoUrl: newPhoto || undefined,
      };
      setCurrentUser(updatedUser);
      setUserState(updatedUser);

      // Visual flash
      setIsSaved(true);
      setTimeout(() => setIsSaved(false), 2500);
    }
  };

  const handleUpdateProfile = (e: React.FormEvent) => {
    e.preventDefault();
    setIsUpdating(true);
    setTimeout(() => {
      triggerDirectUpdate(username, photoUrl);
      setIsUpdating(false);
    }, 850);
  };

  const handleChatImageSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsCompressing(true);
    const reader = new FileReader();
    reader.onloadend = async () => {
      const rawBase64 = reader.result as string;
      try {
        const compressed = await compressImage(rawBase64, 450, 450, 0.65);
        setChatImage(compressed);
      } catch (err) {
        setChatImage(rawBase64);
      } finally {
        setIsCompressing(false);
      }
    };
    reader.readAsDataURL(file);
  };

  // Submit user support query
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    const hasText = !!chatText.trim();
    const hasImage = !!chatImage;
    if ((!hasText && !hasImage) || !user) return;

    const newMsg: SupportMessage = {
      id: `msg-${Date.now()}-${Math.random()}`,
      userId: user.id,
      username: username || user.username,
      senderId: user.id,
      senderName: username || user.username,
      text: chatText.trim() || "Shared a photo from gallery",
      imageUrl: chatImage || undefined,
      timestamp: new Date().toISOString(),
      readByAdmin: false,
      readByUser: true,
    };

    const allMsgs = getSupportMessages();
    allMsgs.push(newMsg);
    saveSupportMessages(allMsgs);
    setChatText('');
    setChatImage('');
  };

  if (!user) {
    return (
      <div className="p-8 text-center text-gray-400 font-mono text-xs">
        Connecting to VALENT systems...
      </div>
    );
  }

  // Count player's unread messages from admin
  const unreadMsgCount = messages.filter(m => m.senderId === 'admin' && !m.readByUser).length;

  return (
    <div className="max-w-md mx-auto p-4 space-y-4 animate-fade-in text-white pb-28">
      {/* Gamer Header profile badge */}
      <div className="bg-[#13192B] border border-[#222D4A] rounded-3xl p-5 shadow-2xl relative overflow-hidden flex flex-col items-center text-center">
        {/* Decorative elements */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-red-600/5 rounded-full blur-3xl" />
        <div className="absolute -bottom-8 -left-8 w-24 h-24 bg-[#00FFCC]/5 rounded-full blur-xl" />

        <div className="relative group cursor-pointer mb-3">
          <div className="w-24 h-24 rounded-full border-2 border-[#FF4500] p-1 bg-[#0A0E17] flex items-center justify-center overflow-hidden shadow-[0_0_20px_rgba(255,69,0,0.2)]">
            {photoUrl ? (
              <img
                src={photoUrl}
                alt={user.username}
                referrerPolicy="no-referrer"
                className="w-full h-full rounded-full object-cover"
              />
            ) : (
              <div className="w-full h-full rounded-full bg-gradient-to-br from-gray-800 to-gray-950 flex items-center justify-center">
                <UserIcon className="w-10 h-10 text-gray-500" />
              </div>
            )}
          </div>
          
          <label className="absolute bottom-0 right-0 p-1.5 bg-[#FF4500] hover:bg-[#C60000] rounded-full border border-[#222D4A] text-white cursor-pointer transition-colors shadow" id="profile-photo-label">
            <Upload className="w-3.5 h-3.5" />
            <input
              type="file"
              accept="image/*"
              onChange={handlePhotoUpload}
              className="hidden"
            />
          </label>
        </div>

        <div className="space-y-0.5">
          <div className="flex items-center justify-center gap-1.5">
            <h2 className="text-lg font-display font-black tracking-wide text-white uppercase">
              {user.username}
            </h2>
            {user.is_admin && (
              <span className="text-[9px] font-mono bg-[#00FFCC]/10 text-[#00FFCC] border border-[#00FFCC]/20 px-1.5 py-0.5 rounded uppercase tracking-widest font-bold">
                VERIFIED OWNER
              </span>
            )}
            {whatsappGroupUrl && (
              <a
                href={whatsappGroupUrl}
                target="_blank"
                rel="noopener noreferrer"
                title="Join WhatsApp Group"
                className="p-1 text-[#25D366] hover:text-[#1ebd5d] transition-colors cursor-pointer flex items-center justify-center rounded-full bg-[#25D366]/10 hover:bg-[#25D366]/20 py-1.5 px-2 -mt-0.5"
              >
                <MessageCircle className="w-4.5 h-4.5" />
              </a>
            )}
          </div>
          <p className="text-[10px] font-mono text-gray-500 uppercase tracking-widest">
            ID: {user.id.substring(0, 12).toUpperCase()}
          </p>
        </div>

        {/* Level Banner badge row */}
        <div className="w-full mt-4 bg-[#0A0E17]/65 border border-[#222D4A]/50 rounded-xl px-4 py-2 flex items-center justify-between text-xs font-mono">
          <span className="text-gray-400 flex items-center gap-1.5">
            <Award className="w-4 h-4 text-[#FFD700]" />
            Elite Survivor Badge
          </span>
          <span className="text-[#FFD700] font-extrabold text-[11px] tracking-wider uppercase">
            TIER I
          </span>
        </div>

        {/* WhatsApp Group Link Action Card */}
        {whatsappGroupUrl && (
          <a
            href={whatsappGroupUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full mt-2 bg-[#25D366]/10 hover:bg-[#25D366]/20 border border-[#25D366]/30 hover:border-[#25D366] rounded-xl px-4 py-2.5 flex items-center justify-between text-[11.5px] font-mono transition-all duration-200 cursor-pointer text-white text-left shadow-lg group"
          >
            <span className="flex items-center gap-1.5 text-[#25D366] font-extrabold">
              <MessageCircle className="w-4 h-4 text-[#25D366] animate-pulse" />
              <span>OFFICIAL WHATSAPP GROUP</span>
            </span>
            <span className="text-[10px] text-gray-400 flex items-center gap-1 font-bold">
              Join Group
              <ChevronRight className="w-3.5 h-3.5 text-gray-500 group-hover:translate-x-0.5 transition-transform" />
            </span>
          </a>
        )}
      </div>

      {/* Real-time Live support Desk Button - High Priority! */}
      <button
        onClick={() => setShowSupport(true)}
        id="btn-profile-help-support"
        className="w-full bg-gradient-to-r from-[#172036] to-[#0A0E17] border border-[#222D4A] hover:border-[#00FFCC]/45 rounded-2xl p-4 flex items-center justify-between text-xs font-mono font-bold group transition-all text-white active:scale-[0.99] cursor-pointer shadow-lg relative overflow-hidden"
      >
        <div className="absolute top-0 right-0 w-16 h-16 bg-[#00FFCC]/5 rounded-full blur-xl pointer-events-none" />
        <div className="flex items-center gap-3.5">
          <div className="p-2.5 bg-[#00FFCC]/10 hover:bg-[#00FFCC]/15 border border-[#00FFCC]/20 text-[#00FFCC] rounded-xl group-hover:scale-105 transition-all shrink-0">
            <Headphones className="w-5.5 h-5.5 animate-pulse" />
          </div>
          <div className="text-left">
            <span className="block text-gray-100 font-display font-black uppercase text-xs tracking-wider">Priority Client Support</span>
            <span className="text-[10px] text-gray-400 font-sans font-medium mt-0.5 block">Direct live chat with tournament managers 24/7</span>
          </div>
        </div>
        <div className="flex items-center gap-1.5 bg-[#13192B]/90 border border-[#222D4A] rounded-xl px-3 py-2 text-[#00FFCC] text-[10px] font-mono font-extrabold tracking-widest uppercase shrink-0 shadow relative">
          {unreadMsgCount > 0 && (
            <span className="absolute -top-1.5 -right-1.5 flex h-4 w-4">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#00FFCC] opacity-60"></span>
              <span className="relative inline-flex rounded-full h-4 w-4 bg-[#00FFCC] text-black text-[8.5px] font-black items-center justify-center">{unreadMsgCount}</span>
            </span>
          )}
          <span>LIVE CHAT</span>
          <ChevronRight className="w-3.5 h-3.5 text-[#00FFCC] group-hover:translate-x-1 transition-transform" />
        </div>
      </button>

      {/* Billion Dollar Financial HUD Cards */}
      <div className="bg-[#13192B] border border-[#222D4A] rounded-2xl p-4 space-y-3.5 shadow-xl">
        <h3 className="text-[11px] font-mono text-gray-400 uppercase tracking-widest border-b border-[#222D4A]/50 pb-2">
          💰 Wallet Balance Ledger
        </h3>

        <div className="grid grid-cols-2 gap-3 text-center font-mono">
          <div className="bg-[#0A0E17] border border-[#222D4A]/40 rounded-xl p-3 flex flex-col justify-center items-center">
            <span className="text-[9px] text-gray-500 uppercase tracking-wider block mb-0.5">Deposit</span>
            <span className="text-sm font-extrabold text-white">₹{Math.max(0, user.wallet.deposit).toFixed(2)}</span>
          </div>
          
          <div className="bg-[#0A0E17]/85 border border-emerald-500/20 rounded-xl p-3 flex flex-col justify-center items-center shadow-[0_0_12px_rgba(16,185,129,0.06)] relative overflow-hidden">
            <span className="text-[9px] text-emerald-400 uppercase tracking-wider font-extrabold block mb-0.5 flex items-center gap-0.5">
              Won ★
            </span>
            <span className="text-sm font-extrabold text-[#00FFCC]">₹{Math.max(0, user.wallet.winnings).toFixed(2)}</span>
            <div className="absolute top-0 right-0 w-4 h-4 bg-emerald-500/10 rounded-full blur-xs" />
          </div>
        </div>

        <div className="pt-1.5 flex justify-between items-center text-[10px] text-gray-500 font-mono">
          <span>Net Combined Value:</span>
          <span className="text-white font-bold">
            ₹{(Math.max(0, user.wallet.deposit) + Math.max(0, user.wallet.winnings)).toFixed(2)}
          </span>
        </div>
      </div>

      {/* 📢 SQUAD REFERRAL LOBBY CARD */}
      <div className="bg-[#13192B] border-2 border-dashed border-[#FF4500]/40 rounded-2xl p-5 space-y-4 shadow-xl text-left relative overflow-hidden">
        <div className="absolute top-0 right-0 w-24 h-24 bg-orange-500/5 rounded-full blur-2xl pointer-events-none" />
        
        <div className="flex items-center gap-2">
          <div className="p-2 bg-orange-500/15 border border-orange-500/20 rounded-xl text-[#FF4500]">
            <Sparkles className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <h3 className="font-display font-black text-xs uppercase text-white tracking-wider">
              Tactical Referral Lounge
            </h3>
            <p className="text-[9px] text-gray-400">Share your custom invite code with recruits to earn payout bonuses!</p>
          </div>
        </div>

        {/* Copyable referral code badge */}
        <div className="bg-[#060910] border border-[#222D4A] rounded-xl p-3.5 flex items-center justify-between shadow-inner">
          <div className="space-y-0.5">
            <span className="text-[8.5px] font-mono text-gray-500 uppercase tracking-widest block">YOUR REFERRAL CODE</span>
            <span className="text-md font-mono font-black text-[#00FFCC] select-all tracking-wider">
              {user.referralCode || user.username.trim().toUpperCase()}
            </span>
          </div>
          <button
            type="button"
            onClick={() => {
              const code = user.referralCode || user.username.trim().toUpperCase();
              navigator.clipboard.writeText(code);
              setCopiedRef(true);
              setTimeout(() => setCopiedRef(false), 2000);
            }}
            className="flex items-center gap-1 px-3 py-1.5 bg-[#FF4500]/10 hover:bg-[#FF4500]/20 border border-[#FF4500]/30 rounded-lg text-[#FF4500] text-[10px] font-mono font-bold uppercase transition-all duration-150 cursor-pointer"
          >
            <Copy className="w-3.5 h-3.5" />
            <span>{copiedRef ? 'COPIED ✓' : 'COPY'}</span>
          </button>
        </div>

        {/* Reward Explanation text */}
        <div className="p-3 bg-[#0A0D18] rounded-xl border border-[#222D4A]/55 text-[10.5px] font-mono text-gray-300 leading-relaxed text-left space-y-1.5">
          <p className="flex items-start gap-1">
            <span className="text-amber-500 shrink-0 font-extrabold">🎁 REWARD RULE:</span>
            <span>
              If that person deposits ₹60 or more under your referral code, you will get ₹25 credited directly to your deposit balance instantly!
            </span>
          </p>
          <p className="text-gray-500 text-[9px]">※ Rewards are paid out once per unique recruit upon first successful ₹60+ deposit.</p>
        </div>

        {/* Referral System Stats & List */}
        {(() => {
          const allSystemUsers = getUsers();
          const targetCode = user.referralCode || user.username.trim().toUpperCase();
          const recruits = allSystemUsers.filter(u => u.referredByUserId === user.id || (u.referredBy && u.referredBy.toUpperCase() === targetCode));
          
          const totalPaidCount = recruits.filter(r => r.isReferralRewardPaid).length;
          const totalRewardsEarned = totalPaidCount * 25;

          return (
            <div className="space-y-3 pt-1 border-t border-[#222D4A]/50">
              <div className="grid grid-cols-2 gap-2 text-center">
                <div className="bg-[#0A0E17]/60 border border-[#222D4A]/40 p-2 rounded-xl">
                  <span className="text-[8px] font-mono text-gray-500 uppercase block">Total Recruits</span>
                  <span className="text-xs font-bold text-white font-mono mt-0.5 block">{recruits.length}</span>
                </div>
                <div className="bg-[#0D1815] border border-emerald-500/20 p-2 rounded-xl">
                  <span className="text-[8px] font-mono text-emerald-500 uppercase block">Earned Cash</span>
                  <span className="text-xs font-bold text-emerald-400 font-mono mt-0.5 block">₹{totalRewardsEarned}</span>
                </div>
              </div>

              {recruits.length > 0 && (
                <div className="space-y-1.5 text-left">
                  <span className="text-[9px] font-mono text-gray-500 uppercase tracking-wider block pl-0.5">RECRUITED LIST</span>
                  <div className="max-h-24 overflow-y-auto space-y-1 border border-[#222D4A]/40 rounded-xl p-1.5 bg-[#070A11]/55 scrollbar-thin">
                    {recruits.map(r => (
                      <div key={r.id} className="flex justify-between items-center text-[10px] font-mono p-1 px-2.5 bg-[#0C0F19] rounded-lg">
                        <span className="text-gray-300 font-bold">@{r.username}</span>
                        <span className={r.isReferralRewardPaid ? "text-emerald-400 text-[9px] font-bold" : "text-gray-500 text-[9px]"}>
                          {r.isReferralRewardPaid ? "✅ COMPLETED (₹25 PAID)" : "⏳ PENDING ₹60 DEPOSIT"}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          );
        })()}
      </div>

      {/* Gamer Account Settings editor form */}
      <div className="bg-[#13192B] border border-[#222D4A] rounded-2xl p-4.5 space-y-4">
        <h3 className="text-[11px] font-mono text-gray-400 uppercase tracking-widest">
          🛡️ Profile Configuration
        </h3>

        <form onSubmit={handleUpdateProfile} className="space-y-4">
          <div className="space-y-1.5">
            <label className="block text-[10px] font-mono text-gray-400 uppercase tracking-wider pl-1 font-bold">
              Esports Handle Name
            </label>
            <input
              type="text"
              required
              placeholder="e.g. S11_Viper"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full bg-[#0A0E17] border border-[#222D4A] rounded-xl py-2.5 px-3.5 text-xs text-white uppercase font-mono tracking-widest focus:border-[#FF4500] focus:outline-none focus:ring-1 focus:ring-[#FF4500]"
            />
          </div>

          <div className="space-y-1.5">
            <label className="block text-[10px] font-mono text-gray-450 uppercase tracking-wider pl-1 font-bold">
              Verified Esports Phone (Lock)
            </label>
            <div className="bg-[#0A0E17]/80 border border-[#222D4A]/50 rounded-xl py-2.5 px-3.5 text-xs text-gray-300 font-mono flex items-center gap-1.5 select-none text-left">
              <span>🇮🇳</span>
              <span>+91 {user?.phone || '9999999999'}</span>
              <span className="ml-auto text-[8px] bg-emerald-950/40 text-emerald-400 font-extrabold border border-emerald-900 px-1.5 py-0.5 rounded uppercase font-mono tracking-wider">
                SECURED
              </span>
            </div>
          </div>

          <button
            type="submit"
            disabled={isUpdating}
            className={`w-full py-2.5 rounded-xl font-display font-black text-xs uppercase tracking-widest shadow-xl transition-all duration-300 active:scale-[0.98] flex items-center justify-center gap-1.5 text-white ${
              isUpdating
                ? 'bg-gray-700 pointer-events-none opacity-60'
                : 'bg-gradient-to-r from-[#FF4500] to-[#C60000] hover:from-[#C60000] hover:to-[#FF4500]'
            }`}
          >
            {isUpdating && (
              <span className="w-3.5 h-3.5 border-2 border-white/35 border-t-white rounded-full animate-spin" />
            )}
            {isUpdating ? 'SAVING PROFILE...' : 'UPDATE ACCOUNT PROFILE'}
          </button>
        </form>

        {isSaved && (
          <div className="text-center p-2 bg-[#00FFCC]/10 border border-[#00FFCC]/20 rounded-xl text-[11px] text-[#00FFCC] font-mono uppercase tracking-wider">
            ✓ Survivor identity details updated in real-time!
          </div>
        )}
      </div>

      {/* Esports Roster stats info tracker metrics */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-[#13192B] border border-[#222D4A] rounded-xl p-3.5 flex items-center gap-3">
          <div className="p-2 bg-red-950/20 text-[#FF4500] rounded-lg">
            <Activity className="w-5 h-5" />
          </div>
          <div className="text-left">
            <span className="text-[9px] font-mono text-gray-500 block uppercase">Joined Lobbies</span>
            <span className="text-sm font-mono font-bold text-white">{registeredCount}</span>
          </div>
        </div>

        <div className="bg-[#13192B] border border-[#222D4A] rounded-xl p-3.5 flex items-center gap-3">
          <div className="p-2 bg-teal-950/20 text-[#00FFCC] rounded-lg">
            <Trophy className="w-5 h-5" />
          </div>
          <div className="text-left">
            <span className="text-[9px] font-mono text-gray-550 block uppercase">Lobbies Won</span>
            <span className="text-sm font-mono font-bold text-white">{completedCount}</span>
          </div>
        </div>
      </div>

      {/* Shifted Sign Out Button - Clean and Professional! */}
      {onLogout && (
        <button
          onClick={onLogout}
          id="btn-profile-logout"
          className="w-full bg-[#1A1221] hover:bg-red-950/25 border border-red-500/20 hover:border-red-500 rounded-2xl py-4 text-xs font-display font-black text-red-400 hover:text-red-500 uppercase tracking-widest transition-all cursor-pointer flex items-center justify-center gap-2 shadow-lg mt-2 group"
        >
          <LogOut className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" />
          <span>Exit Account & Sign Out</span>
        </button>
      )}

      {/* =========================================================================
          🔥 USER PRIORITY LIVE CHAT SYSTEM DRAWER OVERLAY (BILLION DOLLAR LAYOUT) 
          ========================================================================= */}
      {showSupport && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/92 backdrop-blur-xl animate-fade-in select-none">
          <div className="bg-gradient-to-br from-[#121829] via-[#0D1222] to-[#080B14] border border-[#222D4A] rounded-3xl p-5 md:p-6 max-w-md w-full h-[620px] shadow-[0_0_80px_rgba(0,255,204,0.12)] relative overflow-hidden flex flex-col justify-between">
            {/* Ambient Background Glows */}
            <div className="absolute top-0 right-0 w-48 h-48 bg-[#00FFCC]/5 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute top-0 left-0 w-full h-[3px] bg-gradient-to-r from-[#00FFCC] via-blue-550 to-emerald-500" />

            {/* Support Header */}
            <div className="flex items-start justify-between pb-4 border-b border-[#222D4A]/55">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-[#00FFCC]/10 border border-[#00FFCC]/20 rounded-xl text-[#00FFCC] animate-pulse">
                  <Headphones className="w-5.5 h-5.5" />
                </div>
                <div className="text-left">
                  <span className="text-[10px] font-mono text-[#00FFCC] uppercase tracking-widest block font-black">
                    ★ PRIORITY ASSISTANCE
                  </span>
                  <h2 className="text-sm font-display font-black uppercase text-white tracking-wide">
                    Live Tactical Support
                  </h2>
                </div>
              </div>

              <button
                onClick={() => setShowSupport(false)}
                className="p-1.5 bg-[#13192B] border border-[#222D4A] hover:bg-red-500/15 hover:border-red-500 hover:text-red-500 rounded-xl text-gray-400 transition-all cursor-pointer shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Chat Messages Log Panel */}
            <div className="flex-1 overflow-y-auto my-4 space-y-3 pr-1 text-left scrollbar-thin">
              {messages.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-3.5 opacity-80">
                  <div className="w-12 h-12 rounded-full bg-[#13192B] border border-[#222D4A] flex items-center justify-center text-[#00FFCC]">
                    <MessageSquare className="w-6 h-6 animate-bounce" />
                  </div>
                  <div className="space-y-1">
                    <h4 className="font-display font-bold text-xs uppercase tracking-wide text-white">No active dispute logs</h4>
                    <p className="text-[11px] text-gray-400 font-sans leading-normal max-w-[240px] mx-auto">
                      Initiate a dialogue regarding deposits, refunds, rule queries or game disputes.
                    </p>
                  </div>
                </div>
              ) : (
                messages.map((m) => {
                  const isMe = m.senderId === user.id;
                  return (
                    <div
                      key={m.id}
                      className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} max-w-[85%] ${
                        isMe ? 'ml-auto' : 'mr-auto'
                      }`}
                    >
                      <span className="text-[8.5px] font-mono text-gray-500 mb-0.5 px-1 uppercase tracking-wide">
                        {m.senderName} • {new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                      <div
                        className={`rounded-2xl px-3.5 py-2.5 text-xs font-sans leading-relaxed break-words font-medium ${
                          isMe
                            ? 'bg-gradient-to-r from-teal-700 to-emerald-600 text-white rounded-tr-none'
                            : 'bg-[#13192B] border border-[#222D4A] text-gray-200 rounded-tl-none'
                        }`}
                      >
                        {m.imageUrl && (
                          <div 
                            onClick={() => setZoomImage(m.imageUrl || null)} 
                            className="mb-1.5 rounded-xl overflow-hidden border border-[#222D4A]/60 max-w-[190px] cursor-pointer hover:opacity-95 active:scale-95 transition-all mx-auto"
                          >
                            <img 
                              src={m.imageUrl} 
                              alt="Chat attachment" 
                              className="w-full h-auto object-cover max-h-36" 
                              referrerPolicy="no-referrer"
                            />
                          </div>
                        )}
                        {m.text}
                      </div>
                    </div>
                  );
                })
              )}
              <div ref={chatEndRef} />
            </div>

            {/* Send Message Form */}
            <form onSubmit={handleSendMessage} className="pt-3 border-t border-[#222D4A]/55 flex flex-col gap-2 shrink-0">
              {chatImage && (
                <div className="relative bg-[#0A0E17]/95 border border-[#222D4A] p-2 rounded-xl flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <img src={chatImage} className="w-10 h-10 object-cover rounded-lg border border-[#222D4A]" referrerPolicy="no-referrer" />
                    <span className="text-[10px] text-gray-400 font-mono">Gallery photo attached</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setChatImage('')}
                    className="p-1.5 bg-[#13192B] border border-[#222D4A] rounded-lg text-gray-400 hover:text-red-400 transition-colors"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              <div className="flex items-center gap-2">
                <input
                  type="file"
                  ref={chatFileInputRef}
                  onChange={handleChatImageSelect}
                  accept="image/*"
                  className="hidden"
                />
                <button
                  type="button"
                  disabled={isCompressing}
                  onClick={() => chatFileInputRef.current?.click()}
                  className="p-3 bg-[#13192B] border border-[#222D4A] text-gray-400 hover:text-white rounded-xl transition-all cursor-pointer shrink-0 hover:scale-[1.03] active:scale-[0.97] flex items-center justify-center"
                >
                  {isCompressing ? (
                    <Loader2 className="w-4 h-4 animate-spin text-[#00FFCC]" />
                  ) : (
                    <ImageIcon className="w-4 h-4" />
                  )}
                </button>

                <input
                  type="text"
                  placeholder="Type message or select a photo..."
                  value={chatText}
                  onChange={(e) => setChatText(e.target.value)}
                  maxLength={450}
                  className="flex-1 bg-[#0A0E17] border border-[#222D4A] rounded-xl px-4 py-3 text-xs text-white placeholder-gray-550 focus:outline-none focus:border-[#00FFCC] font-sans"
                />
                <button
                  type="submit"
                  disabled={!chatText.trim() && !chatImage}
                  className="p-3 bg-gradient-to-r from-teal-600 to-emerald-500 disabled:from-gray-800 disabled:to-gray-900 text-white disabled:text-gray-500 rounded-xl transition-all cursor-pointer shadow-md shrink-0 flex items-center justify-center hover:scale-[1.03] active:scale-[0.97]"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </form>

            {/* Agent Live Status footer indicator */}
            <div className="flex items-center justify-between text-[10px] font-mono border-t border-[#222D4A]/40 pt-3 text-gray-500 mt-1 whitespace-nowrap shrink-0">
              <span className="flex items-center gap-1">
                <span className="w-1.5 h-1.5 bg-[#00FFCC] rounded-full animate-ping" />
                Specialist Status: <span className="text-[#00FFCC] font-bold">Online</span>
              </span>
              <span>EST. REPLY: INSTANT</span>
            </div>
          </div>
        </div>
      )}

      {/* Zoom Lightbox Modal */}
      {zoomImage && (
        <div 
          className="fixed inset-0 bg-black/95 flex items-center justify-center p-4 z-50 animate-fade-in"
          onClick={() => setZoomImage(null)}
        >
          <div className="absolute top-4 right-4 z-50">
            <button 
              onClick={() => setZoomImage(null)}
              className="p-2.5 bg-gray-950/90 hover:bg-gray-900 border border-[#222D4A] rounded-full text-white cursor-pointer transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          <img 
            src={zoomImage} 
            alt="Magnified Attachment" 
            className="max-w-full max-h-[85vh] object-contain rounded-xl shadow-2xl border border-[#222D4A]"
            referrerPolicy="no-referrer"
            onClick={(e) => e.stopPropagation()} 
          />
        </div>
      )}
    </div>
  );
}
