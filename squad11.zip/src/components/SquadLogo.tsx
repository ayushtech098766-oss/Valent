import React from 'react';

interface SquadLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
}

export default function SquadLogo({ className = '', size = 'md', showText = true }: SquadLogoProps) {
  const sizeMap = {
    sm: { shield: 'w-7 h-7', mainText: 'text-sm md:text-base', subText: 'text-[6px] tracking-[0.2em] font-bold' },
    md: { shield: 'w-10 h-10', mainText: 'text-base md:text-lg', subText: 'text-[7px] tracking-[0.25em] font-semibold' },
    lg: { shield: 'w-14 h-14', mainText: 'text-lg md:text-xl lg:text-2xl', subText: 'text-[8px] tracking-[0.28em]' },
    xl: { shield: 'w-20 h-20', mainText: 'text-2xl md:text-3xl lg:text-4xl', subText: 'text-[10px] tracking-[0.32em]' },
  };

  const activeSize = sizeMap[size];
  const isRow = className.includes('flex-row');

  return (
    <div className={`flex items-center justify-center select-none ${isRow ? 'flex-row text-left gap-2' : 'flex-col text-center'} ${className}`}>
      {/* Premium Iconic Esports standalone Victory Logo (Red / Black / White & Metallic) */}
      <svg
        viewBox="0 0 500 500"
        className={`${activeSize.shield} drop-shadow-[0_0_20px_rgba(255,0,67,0.35)] shrink-0`}
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          {/* Metallic Bright Silver Gradient */}
          <linearGradient id="silverMetallic" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FFFFFF" />
            <stop offset="30%" stopColor="#E2E8F0" />
            <stop offset="70%" stopColor="#94A3B8" />
            <stop offset="100%" stopColor="#475569" />
          </linearGradient>

          {/* Sophisticated Metallic Blood Red & Crimson Gradient */}
          <linearGradient id="metallicRed" x1="10%" y1="0%" x2="90%" y2="100%">
            <stop offset="0%" stopColor="#FF1E56" />
            <stop offset="50%" stopColor="#FF0043" />
            <stop offset="100%" stopColor="#8A001C" />
          </linearGradient>

          {/* Matte Titanium / Dark Carbon Background */}
          <linearGradient id="carbonMatte" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#1E202B" />
            <stop offset="50%" stopColor="#12131A" />
            <stop offset="100%" stopColor="#07080C" />
          </linearGradient>

          {/* Platinum / Metallic White Highlights */}
          <linearGradient id="platinumGlow" x1="0%" y1="100%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#64748B" />
            <stop offset="50%" stopColor="#CBD5E1" />
            <stop offset="100%" stopColor="#F8FAFC" />
          </linearGradient>

          {/* Sharp Cyber Red Neon Stroke Gradient */}
          <linearGradient id="cyberRedStroke" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FF0043" />
            <stop offset="100%" stopColor="#FF6B8B" />
          </linearGradient>
        </defs>

        {/* --- Backplate Premium Geometric Shield --- */}
        <path
          d="M 250 15 L 440 100 L 410 320 C 410 405, 250 485, 250 485 C 250 485, 90 405, 90 320 L 60 100 Z"
          fill="url(#carbonMatte)"
          stroke="url(#cyberRedStroke)"
          strokeWidth="11"
          strokeLinejoin="round"
        />

        {/* --- Secondary Inner Shield Border (Faceted Design) --- */}
        <path
          d="M 250 35 L 415 110 L 388 310 C 388 385, 250 455, 250 455 C 250 455, 112 385, 112 310 L 85 110 Z"
          stroke="#334155"
          strokeWidth="3.5"
          fill="none"
        />

        {/* --- Outer Symmetric Wing Blades (Victory & Precision Chevrons) in Chrome Silver --- */}
        {/* Left Wing Blade */}
        <path
          d="M 120 160 L 210 280 L 190 295 L 105 180 Z"
          fill="url(#silverMetallic)"
          stroke="#FFFFFF"
          strokeWidth="1.5"
          strokeLinejoin="round"
        />
        {/* Right Wing Blade */}
        <path
          d="M 380 160 L 290 280 L 310 295 L 395 180 Z"
          fill="url(#silverMetallic)"
          stroke="#FFFFFF"
          strokeWidth="1.5"
          strokeLinejoin="round"
        />

        {/* Lower Left Cheek Wing */}
        <path
          d="M 140 270 L 230 360 L 215 375 L 125 285 Z"
          fill="url(#platinumGlow)"
          stroke="#94A3B8"
          strokeWidth="1"
          strokeLinejoin="round"
        />
        {/* Lower Right Cheek Wing */}
        <path
          d="M 360 270 L 270 360 L 285 375 L 375 285 Z"
          fill="url(#platinumGlow)"
          stroke="#94A3B8"
          strokeWidth="1"
          strokeLinejoin="round"
        />

        {/* --- Standalone Central Energy Core / Crest (Sharp Symmetric Diamond Razor) in Crimson/Blood Red --- */}
        {/* Outer aggressive gem shield */}
        <path
          d="M 250 70 L 350 200 L 250 390 L 150 200 Z"
          fill="url(#metallicRed)"
          stroke="#FF1E56"
          strokeWidth="2.5"
          strokeLinejoin="round"
        />

        {/* Central Core Inner Facet (Dark metallic division representing Precision) */}
        <path
          d="M 250 70 L 250 390 L 150 200 Z"
          fill="#330009"
          opacity="0.38"
        />

        {/* Centerpiece Inner Floating Diamond (Extreme Power Highlight) */}
        <path
          d="M 250 120 L 305 200 L 250 310 L 195 200 Z"
          fill="#FFFFFF"
          opacity="0.85"
        />
        {/* Right facet of center jewel */}
        <path
          d="M 250 120 L 305 200 L 250 310 Z"
          fill="url(#silverMetallic)"
        />
        
        {/* Sharp Victory Spears shooting outward upward */}
        <path
          d="M 250 20 L 265 45 H 235 Z"
          fill="url(#cyberRedStroke)"
        />
      </svg>

      {/* Modern High-End Typography */}
      {showText && (
        <div className={`flex flex-col ${isRow ? 'items-start mt-0' : 'items-center mt-1.5'}`}>
          <div className="flex items-center gap-0.5 font-display tracking-wider font-extrabold select-none leading-none">
            <span className={`text-[#FF0043] uppercase font-black ${activeSize.mainText} drop-shadow-[0_0_10px_rgba(255,0,67,0.4)]`}>V</span>
            <span className={`text-[#E2E8F0] uppercase font-black ${activeSize.mainText}`}>ALENT</span>
          </div>
          <span className={`font-mono text-gray-400 font-bold uppercase leading-normal mt-0.5 ${activeSize.subText}`}>
            Lobbies
          </span>
        </div>
      )}
    </div>
  );
}
