import React, { useState, useEffect, useRef } from 'react';
import { User, Transaction } from '../types';
import { compressImage } from '../utils';
import {
  getCurrentUser,
  setCurrentUser,
  getUsers,
  saveUsers,
  getTransactions,
  saveTransactions,
  getAdminPaymentSettings,
} from '../db';
import {
  Coins,
  ArrowDownCircle,
  ArrowUpCircle,
  Copy,
  Check,
  AlertCircle,
  Upload,
  QrCode,
  Building2,
  ListFilter,
  CheckCircle,
  XCircle,
  Trash2,
  Edit2,
  Gift,
  Trophy,
  ShieldCheck,
} from 'lucide-react';

interface StableInputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'value' | 'onChange'> {
  value: string;
  onValueChange: (val: string) => void;
}

const StableInput = ({ value, onValueChange, type, ...props }: StableInputProps) => {
  const inputRef = useRef<HTMLInputElement>(null);
  const selectionStartRef = useRef<number | null>(null);
  const selectionEndRef = useRef<number | null>(null);

  React.useLayoutEffect(() => {
    const input = inputRef.current;
    if (input && selectionStartRef.current !== null && document.activeElement === input) {
      try {
        input.setSelectionRange(selectionStartRef.current, selectionEndRef.current);
      } catch (e) {}
    }
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const input = e.target;
    let val = input.value;

    if (type === 'number') {
      const cleaned = val.replace(/[^0-9.]/g, '');
      const parts = cleaned.split('.');
      if (parts.length > 2) {
        val = parts[0] + '.' + parts.slice(1).join('');
      } else {
        val = cleaned;
      }
    }

    selectionStartRef.current = input.selectionStart;
    selectionEndRef.current = input.selectionEnd;
    onValueChange(val);
  };

  const resolvedType = type === 'number' ? 'text' : type || 'text';
  const resolvedInputMode = type === 'number' ? 'decimal' : props.inputMode;

  return (
    <input
      autoComplete="off"
      autoCorrect="off"
      autoCapitalize="none"
      spellCheck={false}
      {...props}
      ref={inputRef}
      type={resolvedType}
      inputMode={resolvedInputMode}
      value={value}
      onChange={handleChange}
    />
  );
};

interface WithdrawalFormProps {
  currentUser: User | null;
  setLocalCurrentUser: (user: User | null) => void;
  onSuccess: () => void;
  onCancel: () => void;
  processImageFile: (e: React.ChangeEvent<HTMLInputElement>, setter: (s: string) => void) => void;
}

const WithdrawalForm = ({
  currentUser,
  setLocalCurrentUser,
  onSuccess,
  onCancel,
  processImageFile,
}: WithdrawalFormProps) => {
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [withdrawSuccess, setWithdrawSuccess] = useState(false);
  const [withdrawSource, setWithdrawSource] = useState<'winnings' | 'deposit'>('winnings');
  const [payoutMethod, setPayoutMethod] = useState<'upi' | 'bank' | 'googleplay'>('upi');

  // 1. STANDARD HOOKS FOR REAL-TIME TYPING WITHOUT CURSOR RESETTING OR JUMPING
  const [withdrawalAmount, setWithdrawalAmount] = useState('');
  const [upiId, setUpiId] = useState('');
  const [bankAccount, setBankAccount] = useState('');
  const [bankIfsc, setBankIfsc] = useState('');
  const [bankHolder, setBankHolder] = useState('');
  const [qrCodeImage, setQrCodeImage] = useState('');

  // SAVED PAYOUT METHODS REGISTRY (THE POPULAR USER ACTION)
  interface SavedPayout {
    id: string;
    type: 'upi' | 'bank';
    label: string;
    upiId?: string;
    bankAccount?: string;
    bankIfsc?: string;
    bankHolder?: string;
  }

  const [savedPayouts, setSavedPayouts] = useState<SavedPayout[]>([]);
  const [saveForFuture, setSaveForFuture] = useState(true);
  const [payoutLabel, setPayoutLabel] = useState('');
  const [editingPayoutId, setEditingPayoutId] = useState<string | null>(null);

  useEffect(() => {
    if (currentUser?.id) {
      const key = `valent_saved_payouts_${currentUser.id}`;
      const saved = localStorage.getItem(key);
      if (saved) {
        try {
          setSavedPayouts(JSON.parse(saved));
        } catch (e) {
          setSavedPayouts([]);
        }
      }
    }
  }, [currentUser]);

  const savePayoutsList = (list: SavedPayout[]) => {
    if (currentUser?.id) {
      const key = `valent_saved_payouts_${currentUser.id}`;
      localStorage.setItem(key, JSON.stringify(list));
      setSavedPayouts(list);
    }
  };

  const handleDeleteSaved = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = savedPayouts.filter(p => p.id !== id);
    savePayoutsList(updated);
    if (editingPayoutId === id) {
      setEditingPayoutId(null);
      setPayoutLabel('');
    }
  };

  const handleEditSaved = (payout: SavedPayout, e: React.MouseEvent) => {
    e.stopPropagation();
    setPayoutMethod(payout.type);
    setEditingPayoutId(payout.id);
    setPayoutLabel(payout.label);
    if (payout.type === 'upi') {
      setUpiId(payout.upiId || '');
    } else {
      setBankAccount(payout.bankAccount || '');
      setBankIfsc(payout.bankIfsc || '');
      setBankHolder(payout.bankHolder || '');
    }
  };

  const handleSelectSaved = (payout: SavedPayout) => {
    setPayoutMethod(payout.type);
    setEditingPayoutId(payout.id);
    setPayoutLabel(payout.label);
    if (payout.type === 'upi') {
      setUpiId(payout.upiId || '');
    } else {
      setBankAccount(payout.bankAccount || '');
      setBankIfsc(payout.bankIfsc || '');
      setBankHolder(payout.bankHolder || '');
    }
  };

  const handleClearFormFields = () => {
    setUpiId('');
    setBankAccount('');
    setBankIfsc('');
    setBankHolder('');
    setEditingPayoutId(null);
    setPayoutLabel('');
  };

  const handleWithdrawalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      setErrorMessage('Error: Session expired. Please log in.');
      return;
    }

    if (!withdrawalAmount) {
      setErrorMessage('Please enter the cash out amount.');
      return;
    }

    const requestedAmt = parseFloat(withdrawalAmount);

    if (isNaN(requestedAmt) || requestedAmt <= 0) {
      setErrorMessage('Insert positive withdrawal cash amount.');
      return;
    }

    if (requestedAmt < 100) {
      setErrorMessage('Minimum withdrawal amount is ₹100.');
      return;
    }

    const availableBalance = withdrawSource === 'winnings' 
      ? currentUser.wallet.winnings 
      : currentUser.wallet.deposit;

    if (requestedAmt > availableBalance) {
      setErrorMessage(`${withdrawSource === 'winnings' ? 'Winnings' : 'Deposit'} Balance Deficit! You can only withdraw up to your selected balance of ₹${availableBalance.toFixed(2)}.`);
      return;
    }

    let calculatedUpiId = '';
    const cleanedAcct = bankAccount.trim().replace(/[^0-9a-zA-Z]/g, '');
    const cleanedIfsc = bankIfsc.trim().toUpperCase().replace(/[^0-9A-Z]/g, '');
    const cleanedHolder = bankHolder.trim();

    if (payoutMethod === 'upi') {
      const trimmedUpiName = upiId.trim();
      if (!trimmedUpiName) {
        setErrorMessage('UPI target ID address is required.');
        return;
      }
      if (!trimmedUpiName.includes('@')) {
        setErrorMessage('Invalid UPI: Please specify your full UPI ID retaining the "@" suffix (e.g. name@paytm).');
        return;
      }
      calculatedUpiId = trimmedUpiName.toLowerCase();
    } else if (payoutMethod === 'bank') {
      if (!cleanedAcct) {
        setErrorMessage('All banking routing fields are mandatory: Account Number is missing.');
        return;
      }
      if (!cleanedIfsc) {
        setErrorMessage('All banking routing fields are mandatory: Bank IFSC Code is missing.');
        return;
      }
      if (!cleanedHolder) {
        setErrorMessage('All banking routing fields are mandatory: Account Holder Name is missing.');
        return;
      }
    }

    setErrorMessage(null);
    setIsSubmitting(true);

    setTimeout(() => {
      try {
        const allUsers = getUsers();
        const userIdx = allUsers.findIndex((u) => u.id === currentUser.id);
        if (userIdx === -1) {
          setErrorMessage('Error: Local user account synchronization failed.');
          setIsSubmitting(false);
          return;
        }

        if (withdrawSource === 'winnings') {
          allUsers[userIdx].wallet.winnings = Number((allUsers[userIdx].wallet.winnings - requestedAmt).toFixed(2));
        } else {
          allUsers[userIdx].wallet.deposit = Number((allUsers[userIdx].wallet.deposit - requestedAmt).toFixed(2));
        }
        
        const tx: Transaction = {
          id: `tx-${Date.now()}`,
          userId: currentUser.id,
          type: 'withdrawal',
          amount: requestedAmt,
          status: 'pending',
          created_at: new Date().toISOString(),
          upiId: payoutMethod === 'upi' ? calculatedUpiId : undefined,
          proofImageUrl: payoutMethod === 'upi' && qrCodeImage ? qrCodeImage : undefined,
          withdrawSource: withdrawSource,
          withdrawMethod: payoutMethod,
          bankDetails:
            payoutMethod === 'bank'
              ? {
                  accountNumber: cleanedAcct,
                  ifscCode: cleanedIfsc,
                  holderName: cleanedHolder,
                }
              : undefined,
        };

        const allTxs = getTransactions();

        // Upsert Saved Payout Method if checked
        if (saveForFuture && payoutMethod !== 'googleplay') {
          let labelToSave = payoutLabel.trim();
          if (!labelToSave) {
            labelToSave = payoutMethod === 'upi'
              ? `UPI ID (${calculatedUpiId.length > 15 ? calculatedUpiId.slice(0, 15) + '...' : calculatedUpiId})`
              : `Bank (${cleanedAcct.slice(-4)})`;
          }

          if (editingPayoutId) {
            // Update existing item
            const updated = savedPayouts.map(p => {
              if (p.id === editingPayoutId) {
                return {
                  ...p,
                  type: payoutMethod,
                  label: labelToSave,
                  upiId: payoutMethod === 'upi' ? calculatedUpiId : undefined,
                  bankAccount: payoutMethod === 'bank' ? cleanedAcct : undefined,
                  bankIfsc: payoutMethod === 'bank' ? cleanedIfsc : undefined,
                  bankHolder: payoutMethod === 'bank' ? cleanedHolder : undefined,
                };
              }
              return p;
            });
            savePayoutsList(updated);
          } else {
            // Check if already matches exactly to prevent duplication, otherwise add new
            const exists = savedPayouts.find(p => 
              payoutMethod === 'upi'
                ? p.upiId?.toLowerCase() === calculatedUpiId.toLowerCase()
                : p.bankAccount === cleanedAcct
            );
            if (exists) {
              // Update its label if different
              const updated = savedPayouts.map(p => {
                if (p.id === exists.id) {
                  return {
                    ...p,
                    label: labelToSave,
                    bankIfsc: payoutMethod === 'bank' ? cleanedIfsc : p.bankIfsc,
                    bankHolder: payoutMethod === 'bank' ? cleanedHolder : p.bankHolder,
                  };
                }
                return p;
              });
              savePayoutsList(updated);
            } else {
              const newPayout: SavedPayout = {
                id: `payout-${Date.now()}`,
                type: payoutMethod as 'upi' | 'bank',
                label: labelToSave,
                upiId: payoutMethod === 'upi' ? calculatedUpiId : undefined,
                bankAccount: payoutMethod === 'bank' ? cleanedAcct : undefined,
                bankIfsc: payoutMethod === 'bank' ? cleanedIfsc : undefined,
                bankHolder: payoutMethod === 'bank' ? cleanedHolder : undefined,
              };
              savePayoutsList([...savedPayouts, newPayout]);
            }
          }
        }

        saveUsers(allUsers);
        setCurrentUser(allUsers[userIdx]);
        saveTransactions([...allTxs, tx]);

        setLocalCurrentUser(allUsers[userIdx]);
        setWithdrawSuccess(true);
        setIsSubmitting(false);

        // Reset local fields cleanly to empty strings
        setWithdrawalAmount('');
        setUpiId('');
        setBankAccount('');
        setBankIfsc('');
        setBankHolder('');
        setQrCodeImage('');
        setEditingPayoutId(null);
        setPayoutLabel('');
        
        setTimeout(() => {
          onSuccess();
        }, 1500);
      } catch (err: any) {
        setIsSubmitting(false);
        console.error('Submit withdrawal error:', err);
        setErrorMessage('An unexpected error occurred during withdrawal: ' + err.message);
      }
    }, 850);
  };

  const selectedWalletBalance = withdrawSource === 'winnings'
    ? (currentUser?.wallet.winnings || 0)
    : (currentUser?.wallet.deposit || 0);

  return (
    <div className="bg-[#121829] border border-[#2A3556] rounded-3xl p-6 shadow-2xl animate-fade-in relative overflow-hidden">
      {/* Decorative linear glow */}
      <div className="absolute top-0 inset-x-0 h-[1px] bg-gradient-to-r from-transparent via-[#FF4500] to-transparent opacity-60" />

      {errorMessage && (
        <div className="mb-5 bg-red-950/50 border border-red-500/40 text-red-200 rounded-2xl p-4 text-xs flex items-start gap-2.5 font-mono shadow-lg">
          <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
          <span>{errorMessage}</span>
        </div>
      )}

      {withdrawSuccess ? (
        <div className="text-center py-8 space-y-4">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 animate-pulse">
            <CheckCircle className="w-9 h-9" />
          </div>
          <div className="space-y-1">
            <h3 className="text-base font-display font-bold text-[#00FFCC] uppercase tracking-wider">
              Withdrawal Submitted
            </h3>
            <p className="text-xs text-gray-400 font-mono max-w-xs mx-auto leading-relaxed">
              Deduction approved. Placed in review queue. Funds credit in 12-24 hours.
            </p>
          </div>
        </div>
      ) : (
        <form onSubmit={handleWithdrawalSubmit} className="space-y-5">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-[#222D4A] pb-3">
            <div>
              <h3 className="text-sm font-display font-bold uppercase text-white tracking-widest flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#FF4500] animate-pulse" />
                Withdrawal Portal
              </h3>
              <p className="text-[10px] text-gray-400 font-mono mt-0.5">Secure dynamic bank routing</p>
            </div>
            <span className="text-[9px] font-mono text-[#00FFCC] bg-[#00FFCC]/10 border border-[#00FFCC]/20 px-2 py-0.5 rounded-full">
              ⚡ Safe Gate
            </span>
          </div>

          {/* Wallet Choice Tabs */}
          <div className="space-y-2">
            <label className="block text-[10px] font-mono text-gray-400 uppercase tracking-widest pl-1">
              Select Source Wallet
            </label>
            <div className="grid grid-cols-2 gap-3 bg-[#090D16] p-1.5 border border-[#222D4A] rounded-2xl">
              <button
                type="button"
                onClick={() => {
                  setWithdrawSource('winnings');
                  setErrorMessage(null);
                }}
                className={`py-2.5 px-2 rounded-xl font-mono text-[10px] uppercase flex flex-col items-center justify-center transition-all duration-300 relative overflow-hidden ${
                  withdrawSource === 'winnings'
                    ? 'bg-gradient-to-b from-[#22C55E]/20 to-[#15803D]/10 text-emerald-300 border border-emerald-500/40 shadow-[0_0_15px_rgba(34,197,94,0.15)] font-bold'
                    : 'text-gray-400 hover:text-gray-200 border border-transparent'
                }`}
              >
                <span>Winnings Wallet</span>
                <span className="text-xs font-bold mt-1 text-white">₹{(currentUser?.wallet.winnings || 0).toFixed(2)}</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setWithdrawSource('deposit');
                  setErrorMessage(null);
                }}
                className={`py-2.5 px-2 rounded-xl font-mono text-[10px] uppercase flex flex-col items-center justify-center transition-all duration-300 ${
                  withdrawSource === 'deposit'
                    ? 'bg-gradient-to-b from-[#3B82F6]/20 to-[#1D4ED8]/10 text-blue-300 border border-blue-500/40 shadow-[0_0_15px_rgba(59,130,246,0.15)] font-bold'
                    : 'text-gray-400 hover:text-gray-200 border border-transparent'
                }`}
              >
                <span>Deposit Wallet</span>
                <span className="text-xs font-bold mt-1 text-white">₹{(currentUser?.wallet.deposit || 0).toFixed(2)}</span>
              </button>
            </div>
          </div>

          {/* Amount input */}
          <div className="space-y-1.5">
            <div className="flex justify-between items-center px-1">
              <label className="text-[10px] font-mono text-gray-400 uppercase tracking-widest">
                Amount to Cash Out
              </label>
              <span className="text-[10px] font-mono text-[#FF4500]">
                Max: ₹{selectedWalletBalance.toFixed(2)}
              </span>
            </div>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 font-display font-medium text-lg">
                ₹
              </span>
              <input
                type="number"
                placeholder="Minimum 100"
                value={withdrawalAmount}
                onChange={(e) => setWithdrawalAmount(e.target.value)}
                className="w-full bg-[#090D16] border border-[#222D4A] rounded-2xl py-3.5 pl-9 pr-4 text-white font-mono text-base focus:outline-none focus:border-[#FF4500] focus:ring-1 focus:ring-[#FF4500] placeholder-gray-700 transition-all shadow-inner"
              />
            </div>
          </div>

          {/* Payout method selector */}
          <div className="space-y-2">
            <label className="block text-[10px] font-mono text-gray-400 uppercase tracking-widest pl-1">
              Transfer Destination
            </label>
            <div className="grid grid-cols-2 gap-1.5 bg-[#090D16] p-1.5 border border-[#222D4A] rounded-2xl">
              <button
                type="button"
                onClick={() => setPayoutMethod('upi')}
                className={`py-2.5 rounded-xl font-mono text-[10px] uppercase flex flex-col items-center justify-center gap-1 border transition-all duration-300 ${
                  payoutMethod === 'upi'
                    ? 'bg-[#182138] border-[#FF4500]/60 text-white font-bold shadow-md shadow-black/45'
                    : 'border-transparent text-gray-400 hover:text-gray-200'
                }`}
              >
                <QrCode className={`w-3.5 h-3.5 ${payoutMethod === 'upi' ? 'text-[#FF4500]' : 'text-gray-400'}`} />
                <span>UPI ID</span>
              </button>

              <button
                type="button"
                onClick={() => setPayoutMethod('googleplay')}
                className={`py-2.5 rounded-xl font-mono text-[10px] uppercase flex flex-col items-center justify-center gap-1 border transition-all duration-300 ${
                  payoutMethod === 'googleplay'
                    ? 'bg-[#182138] border-[#FF4500]/60 text-white font-bold shadow-md shadow-black/45'
                    : 'border-transparent text-gray-400 hover:text-gray-200'
                }`}
              >
                <Gift className={`w-3.5 h-3.5 ${payoutMethod === 'googleplay' ? 'text-[#FF4500]' : 'text-gray-400'}`} />
                <span>Play Code</span>
              </button>
            </div>
          </div>

          {/* Subforms based on method selected */}
          {payoutMethod !== 'googleplay' && (
            <div className="bg-[#090D16] border border-[#1E273F] rounded-2xl p-4 space-y-4">
              {/* 1. SAVED METHODS LIST OF SELECTED TYPE */}
              {(() => {
                const filteredSaved = savedPayouts.filter(p => p.type === 'upi');
                if (filteredSaved.length > 0) {
                  return (
                    <div className="space-y-2 mb-3">
                      <div className="flex justify-between items-center px-1">
                        <span className="text-[10px] font-mono text-gray-400 uppercase tracking-wider">
                          Select Saved UPI Account
                        </span>
                        <span className="text-[9px] font-mono text-[#00FFCC] animate-pulse">Tap to autofill</span>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-40 overflow-y-auto pr-0.5">
                        {filteredSaved.map((p) => {
                          const isSelected = editingPayoutId === p.id;
                          return (
                            <div
                              key={p.id}
                              onClick={() => handleSelectSaved(p)}
                              className={`relative p-3 rounded-xl border transition-all cursor-pointer text-left ${
                                isSelected
                                  ? 'bg-[#182138] border-[#FF4500] shadow-[0_0_12px_rgba(255,69,0,0.15)] text-white'
                                  : 'bg-[#0E1321] border-[#222D4A]/60 hover:border-gray-500 hover:bg-[#121829] text-gray-300'
                              }`}
                            >
                              <div className="flex items-start justify-between gap-1">
                                <div className="min-w-0 flex-1">
                                  <p className="font-sans text-xs font-semibold truncate text-[#00FFCC]">{p.label}</p>
                                  <p className="font-mono text-[10px] text-gray-400 mt-1 truncate">
                                    {p.upiId}
                                  </p>
                                </div>
                                <div className="flex items-center gap-1.5 shrink-0 self-center pl-1">
                                  <button
                                    type="button"
                                    onClick={(e) => handleEditSaved(p, e)}
                                    className="p-1 rounded bg-gray-800 hover:bg-[#FF4500]/20 text-gray-400 hover:text-white transition-colors"
                                    title="Edit"
                                  >
                                    <Edit2 className="w-3 h-3" />
                                  </button>
                                  <button
                                    type="button"
                                    onClick={(e) => handleDeleteSaved(p.id, e)}
                                    className="p-1 rounded bg-gray-800 hover:bg-red-950/60 text-gray-400 hover:text-red-400 transition-colors"
                                    title="Remove"
                                  >
                                    <Trash2 className="w-3 h-3" />
                                  </button>
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                }
                return null;
              })()}

              {/* 2. ACTIVE EDIT CONTROLS BANNER */}
              {editingPayoutId && (
                <div className="flex items-center justify-between bg-amber-950/40 border border-amber-500/30 rounded-xl p-2.5 px-3 text-[11px] font-mono text-amber-300">
                  <div className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
                    <span>Editing saved method: <strong>{payoutLabel}</strong></span>
                  </div>
                  <button
                    type="button"
                    onClick={handleClearFormFields}
                    className="text-[9px] font-bold text-amber-400 hover:text-white uppercase tracking-widest bg-amber-500/10 hover:bg-amber-500/30 px-2 py-1 rounded transition-all"
                  >
                    Clear Fields
                  </button>
                </div>
              )}

              {/* Subform fields */}
              {payoutMethod === 'upi' && (
                <div className="space-y-4 animate-fade-in">
                  <div className="space-y-1.5">
                    <label className="block text-[10px] font-mono text-gray-450 uppercase mb-1 tracking-wider">
                      Paste Your UPI ID Address
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. keyplayer@ybl or 9876543210@paytm (Paste here)"
                      value={upiId}
                      onChange={(e) => setUpiId(e.target.value)}
                      className="w-full bg-[#121829] border border-[#222D4A] rounded-xl py-3.5 px-3 text-white font-mono text-xs focus:outline-none focus:border-[#FF4500] placeholder-gray-750 select-all"
                    />
                    <p className="text-[9px] text-gray-500 font-mono pl-0.5 leading-relaxed">
                      Simply copy your UPI ID from your payments app (GPay/PhonePe/Paytm), paste it here, then request payout.
                    </p>
                  </div>

                  {/* Popular Suffix Selector - click to append if they didn't write it */}
                  <div className="space-y-1.5">
                    <label className="block text-[8px] font-mono text-gray-500 uppercase tracking-widest pl-0.5">
                      Quick Suffix Tool (Tap to Append)
                    </label>
                    <div className="flex flex-wrap gap-1.5">
                      {['@ybl', '@paytm', '@apl', '@okaxis', '@oksbi', '@okhdfcbank'].map((suffix) => (
                        <button
                          key={suffix}
                          type="button"
                          onClick={() => {
                            const base = upiId.split('@')[0].trim();
                            if (base) {
                              setUpiId(base + suffix);
                            } else {
                              setUpiId(suffix);
                            }
                          }}
                          className="px-2 py-1 rounded bg-[#121829] border border-[#222D4A] hover:border-gray-500 hover:text-white transition-colors text-[10px] font-mono text-gray-400"
                        >
                          {suffix}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2 animate-fade-in">
                    <label className="block text-[10px] font-mono text-gray-450 uppercase">
                      Upload UPI Scanner QR (Optional)
                    </label>
                    <div className="relative border border-dashed border-[#222D4A] rounded-xl p-4 bg-[#121829] flex flex-col items-center justify-center text-center hover:border-gray-500 transition-colors cursor-pointer">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => processImageFile(e, setQrCodeImage)}
                        className="absolute inset-0 opacity-0 cursor-pointer"
                      />
                      {qrCodeImage ? (
                        <div className="space-y-2">
                          <img
                            src={qrCodeImage}
                            alt="QR code"
                            className="max-h-24 rounded border border-[#222D4A] shadow"
                          />
                          <p className="text-[9px] text-[#00FFCC] font-mono">Tap here to choose another QR image</p>
                        </div>
                      ) : (
                        <div className="py-2">
                          <QrCode className="w-5 h-5 text-gray-500 mx-auto mb-1.5" />
                          <p className="text-[10px] text-gray-400 font-mono">Upload QR scan image</p>
                          <p className="text-[8px] text-gray-650 font-mono mt-0.5">Optional: Helper for fast reference</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* 3. SAVE FOR FUTURE CHECKS AND CUSTOM NICKNAME LABELS */}
              <div className="border-t border-[#1E273F] pt-3.5 space-y-3">
                <div className="flex items-center gap-2.5">
                  <input
                    id="save-future-checkbox"
                    type="checkbox"
                    checked={saveForFuture}
                    onChange={(e) => setSaveForFuture(e.target.checked)}
                    className="w-4 h-4 rounded border-[#222D4A] bg-[#121829] text-[#FF4500] focus:ring-0 focus:ring-offset-0 focus:outline-none cursor-pointer"
                  />
                  <label htmlFor="save-future-checkbox" className="text-[11px] font-mono text-gray-300 cursor-pointer select-none">
                    {editingPayoutId ? 'Update details of this saved account' : 'Save this layout for future payouts'}
                  </label>
                </div>

                {saveForFuture && (
                  <div className="space-y-1.5 animate-slide-down">
                    <label className="block text-[9px] font-mono text-gray-450 uppercase pl-0.5">
                      Account Nickname / Label
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. My PhonePe, GPay Main Account"
                      value={payoutLabel}
                      onChange={(e) => setPayoutLabel(e.target.value)}
                      className="w-full bg-[#121829] border border-[#222D4A] rounded-xl py-2 px-3 text-white font-mono text-xs focus:outline-none focus:border-[#FF4500] placeholder-gray-750"
                    />
                  </div>
                )}
              </div>
            </div>
          )}

          <div className="grid grid-cols-2 gap-3 pt-2">
            <button
              type="button"
              onClick={onCancel}
              className="bg-transparent border border-[#222D4A] py-3 rounded-2xl text-gray-400 hover:text-white hover:bg-[#182138]/40 font-mono text-xs uppercase tracking-wider transition-all"
            >
              Cancel
            </button>
            <button
              type="submit"
              id="submit-withdrawal-form"
              disabled={isSubmitting}
              className={`py-3 text-white font-display font-bold text-xs uppercase tracking-widest rounded-2xl transition-all shadow-lg flex items-center justify-center gap-1.5 ${
                isSubmitting
                  ? 'bg-gray-700 pointer-events-none opacity-60'
                  : 'bg-gradient-to-r from-[#FF4500] to-[#C60000] hover:shadow-[#FF4500]/10 hover:scale-[1.01]'
              }`}
            >
              {isSubmitting && (
                <span className="w-3.5 h-3.5 border-2 border-white/35 border-t-white rounded-full animate-spin" />
              )}
              {isSubmitting ? 'Processing Payout...' : 'Request Payout'}
            </button>
          </div>
        </form>
      )}
    </div>
  );
};

export default function WalletTab() {
  const [currentUser, setLocalCurrentUser] = useState<User | null>(() => getCurrentUser());
  const [transactions, setTransactions] = useState<Transaction[]>([]);

  // Action states: 'idle' | 'deposit' | 'withdraw'
  const [mode, setMode] = useState<'idle' | 'deposit' | 'withdraw'>('idle');

  // Input Error and Success UI banner states
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const [isDepositing, setIsDepositing] = useState(false);

  // Deposit states
  const [depositStep, setDepositStep] = useState<1 | 2>(1);
  const [depositAmount, setDepositAmount] = useState('');
  const [copied, setCopied] = useState(false);
  const [copiedTxId, setCopiedTxId] = useState<string | null>(null);
  const [proofImage, setProofImage] = useState('');

  const handleCopyRedeemCode = (txId: string, code: string) => {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(code).then(() => {
          setCopiedTxId(txId);
          setTimeout(() => setCopiedTxId(null), 2000);
        }).catch(() => {
          fallbackQueryCopy(code, txId);
        });
      } else {
        fallbackQueryCopy(code, txId);
      }
    } catch (e) {
      fallbackQueryCopy(code, txId);
    }
  };

  const fallbackQueryCopy = (text: string, txId: string) => {
    try {
      const textArea = document.createElement("textarea");
      textArea.value = text;
      textArea.style.position = "fixed";
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();
      document.execCommand("copy");
      document.body.removeChild(textArea);
      setCopiedTxId(txId);
      setTimeout(() => setCopiedTxId(null), 2000);
    } catch (err) {}
  };
  const [utrCode, setUtrCode] = useState('');
  const [depositSubmitted, setDepositSubmitted] = useState(false);

  // Dynamic Admin UPI settings load
  const [paymentSettings, setPaymentSettings] = useState(getAdminPaymentSettings());

  useEffect(() => {
    const reload = () => {
      setLocalCurrentUser(getCurrentUser());
      setPaymentSettings(getAdminPaymentSettings());
      const allTxs = getTransactions().filter((tx) => tx.userId === getCurrentUser()?.id);
      setTransactions(allTxs.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()));
    };
    reload();
    window.addEventListener('valent_db_update', reload);
    return () => {
      window.removeEventListener('valent_db_update', reload);
    };
  }, [depositSubmitted, mode]);

  useEffect(() => {
    setErrorMessage(null);
    setSuccessMessage(null);
  }, [mode, depositStep]);

  const handleCopyUPI = () => {
    try {
      const upiToCopy = paymentSettings.upiId || 'valent.pay@okaxis';
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(upiToCopy).then(() => {
          setCopied(true);
          setTimeout(() => setCopied(false), 2000);
        }).catch(() => {
          fallbackCopyText(upiToCopy);
        });
      } else {
        fallbackCopyText(upiToCopy);
      }
    } catch (e) {
      fallbackCopyText(paymentSettings.upiId || 'valent.pay@okaxis');
    }
  };

  const fallbackCopyText = (text: string) => {
    try {
      const textArea = document.createElement("textarea");
      textArea.value = text;
      // Avoid scrolling to bottom
      textArea.style.top = "0";
      textArea.style.left = "0";
      textArea.style.position = "fixed";
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();
      const successful = document.execCommand('copy');
      document.body.removeChild(textArea);
      if (successful) {
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      } else {
        alert("Copy failed. Please manually type the UPI: " + text);
      }
    } catch (err) {
      alert("Copy failed. Please manually type the UPI: " + text);
    }
  };

  // Convert uploaded image files directly to Base64 String and compress them
  const processImageFile = (e: React.ChangeEvent<HTMLInputElement>, setter: (s: string) => void) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const rawBase64 = reader.result as string;
        try {
          const compressed = await compressImage(rawBase64, 400, 400, 0.6);
          setter(compressed);
        } catch (err) {
          setter(rawBase64);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Submit dynamic manual deposit request
  const handleSubmitDeposit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      setErrorMessage('Error: You must be logged in to deposit.');
      return;
    }
    
    if (!depositAmount) {
      setErrorMessage('Please enter a deposit amount.');
      return;
    }

    const amt = parseFloat(depositAmount);
    if (isNaN(amt) || amt <= 0) {
      setErrorMessage('Deposit budget must be an active positive numeric amount.');
      return;
    }

    if (amt < 60) {
      setErrorMessage('Minimum deposit amount is ₹60.');
      return;
    }

    const cleanedUtr = utrCode.replace(/\s+/g, '');
    const isValidLength = /^[a-zA-Z0-9]{12,22}$/.test(cleanedUtr);

    if (!cleanedUtr) {
      setErrorMessage("Please enter the UTR/Ref No. or Transaction ID from your payment.");
      return;
    }

    if (!isValidLength) {
      setErrorMessage("Invalid Code! The UTR / UPI Ref No. or Transaction ID must be between 12 and 22 characters/digits. Please check and enter it carefully.");
      return;
    }

    if (!proofImage) {
      setErrorMessage("Please upload your payment screenshot as receipt proof.");
      return;
    }

    setErrorMessage(null);
    setIsDepositing(true);

    setTimeout(() => {
      const tx: Transaction = {
        id: `tx-${Date.now()}`,
        userId: currentUser.id,
        type: 'deposit',
        amount: amt,
        status: 'pending',
        created_at: new Date().toISOString(),
        proofImageUrl: proofImage || undefined,
        utr: cleanedUtr,
      };

      const allTxs = getTransactions();
      saveTransactions([...allTxs, tx]);

      setIsDepositing(false);
      setDepositSubmitted(true);
      setTimeout(() => {
        setDepositSubmitted(false);
        setDepositAmount('');
        setUtrCode('');
        setProofImage('');
        setDepositStep(1);
        setMode('idle');
      }, 4000); // Pulse review state
    }, 850);
  };



  const totalCombinedBalance = currentUser
    ? Math.max(0, currentUser.wallet.deposit) + Math.max(0, currentUser.wallet.winnings)
    : 0;

  return (
    <div className="max-w-md mx-auto p-4 space-y-4 animate-fade-in text-white pb-28">
      {/* HUD display panel */}
      <div className="bg-[#13192B] border border-[#222D4A] rounded-3xl p-5 shadow-2xl relative overflow-hidden">
        {/* Background fire spark */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-red-600/10 rounded-full blur-3xl" />

        <p className="text-[11px] font-mono text-gray-400 uppercase tracking-widest block">
          VALENT Verified Net Balance
        </p>
        <h2 className="text-3xl font-display font-bold text-white mt-1">
          ₹{totalCombinedBalance.toFixed(2)}
        </h2>

        {/* Breakdown parameters */}
        <div className="grid grid-cols-2 gap-3 mt-5 border-t border-[#222D4A] pt-4 text-xs font-mono">
          <div>
            <span className="text-gray-500 block uppercase text-[9px]">Deposit</span>
            <span className="font-semibold text-white">₹{Math.max(0, currentUser?.wallet.deposit || 0).toFixed(2)}</span>
          </div>
          <div>
            <span className="text-emerald-500 block uppercase text-[10px] font-bold">Winnings ★</span>
            <span className="font-semibold text-emerald-400">₹{Math.max(0, currentUser?.wallet.winnings || 0).toFixed(2)}</span>
          </div>
        </div>

        {/* Action launchers */}
        <div className="flex gap-3 mt-6">
          <button
            onClick={() => {
              setMode('deposit');
              setDepositStep(1);
            }}
            className={`flex-1 flex items-center justify-center gap-1.5 py-3 rounded-xl font-display font-bold text-xs uppercase tracking-wider transition-all ${
              mode === 'deposit'
                ? 'bg-[#FF4500] text-white shadow-lg'
                : 'bg-[#0A0E17] text-gray-300 border border-[#222D4A] hover:border-gray-500'
            }`}
          >
            <ArrowDownCircle className="w-4 h-4 text-[#00FFCC]" />
            <span>Deposit</span>
          </button>

          <button
            onClick={() => setMode('withdraw')}
            className={`flex-1 flex items-center justify-center gap-1.5 py-3 rounded-xl font-display font-bold text-xs uppercase tracking-wider transition-all ${
              mode === 'withdraw'
                ? 'bg-[#FF4500] text-white shadow-lg'
                : 'bg-[#0A0E17] text-gray-300 border border-[#222D4A] hover:border-gray-500'
            }`}
          >
            <ArrowUpCircle className="w-4 h-4 text-[#FF4500]" />
            <span>Withdraw</span>
          </button>
        </div>
      </div>

      {/* ================= 1. DEPOSIT INTERFACE ================= */}
      {mode === 'deposit' && (
        <div className="bg-[#13192B] border border-[#222D4A] rounded-2xl p-5 shadow-xl animate-fade-in">
          {errorMessage && (
            <div className="mb-4 bg-red-950/40 border border-red-500/30 text-red-300 rounded-xl p-3.5 text-xs flex items-center gap-2 font-mono">
              <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}
          {successMessage && (
            <div className="mb-4 bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 rounded-xl p-3.5 text-xs flex items-center gap-2 font-mono">
              <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{successMessage}</span>
            </div>
          )}
          {depositSubmitted ? (
            <div className="text-center py-6 space-y-3">
              <div className="inline-flex p-3 bg-amber-500/10 border border-amber-500/30 rounded-2xl animate-pulse">
                <AlertCircle className="w-8 h-8 text-amber-500" />
              </div>
              <h3 className="text-sm font-display font-bold text-amber-400 uppercase tracking-widest">
                UTR Review Activated
              </h3>
              <p className="text-xs text-gray-400 max-w-xs mx-auto leading-relaxed font-mono">
                Your deposit is currently under review. Verifying UTR and crediting funds within 1-2 minutes.
              </p>
            </div>
          ) : depositStep === 1 ? (
            /* Step 1: Input Amount Only */
            <div className="space-y-4">
              <h3 className="text-sm font-display font-bold uppercase text-white tracking-wider">
                Step 1: Enter Deposit Amount
              </h3>
              <div>
                <label className="block text-[10px] font-mono text-gray-450 uppercase mb-2">
                  Deposit Cash (INR - ₹)
                </label>
                <StableInput
                  type="number"
                  placeholder="e.g. 500"
                  value={depositAmount}
                  onValueChange={setDepositAmount}
                  className="w-full bg-[#0A0E17] border border-[#222D4A] rounded-xl py-3.5 px-4 text-white font-mono text-base focus:outline-none focus:border-[#FF4500] placeholder-gray-700"
                />
              </div>
              {depositAmount.trim().length > 0 && (
                <button
                  type="button"
                  onClick={() => {
                    const amt = parseFloat(depositAmount);
                    if (isNaN(amt) || amt < 60) {
                      setErrorMessage('Minimum deposit amount is ₹60.');
                      return;
                    }
                    setErrorMessage(null);
                    setDepositStep(2);
                  }}
                  className="w-full bg-gradient-to-r from-[#FF4500] to-[#C60000] py-3 text-white font-display font-bold text-xs uppercase tracking-widest rounded-xl transition-all hover:scale-[1.01]"
                >
                  NEXT STEP →
                </button>
              )}
            </div>
          ) : (
            /* Step 2: Pay Admin UPI & submit UTR with Proof */
            <form onSubmit={handleSubmitDeposit} className="space-y-4">
              <h3 className="text-sm font-display font-bold uppercase text-white tracking-wider">
                Step 2: Transfer with UPI QR
              </h3>

              {/* UPI and Copy */}
              {paymentSettings.upiId && (
                <div className="bg-[#0A0E17] border border-[#222D4A] rounded-xl p-3 flex items-center justify-between">
                  <div>
                    <span className="text-[9px] font-mono text-gray-500 block uppercase">
                      Receiver UPI ID
                    </span>
                    <span className="text-xs font-mono text-white font-bold">{paymentSettings.upiId}</span>
                  </div>
                  <button
                    type="button"
                    onClick={handleCopyUPI}
                    className="p-2 bg-[#13192B] border border-[#222D4A] text-gray-400 hover:text-white rounded-lg flex items-center gap-1 transition-colors"
                  >
                    {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    <span className="text-[10px] font-mono">{copied ? 'COPIED' : 'COPY'}</span>
                  </button>
                </div>
              )}

              {/* Admin Shared QR code globally */}
              {paymentSettings.qrCodeUrl && (
                <div className="bg-[#0A0E17] border border-[#222D4A] rounded-xl p-4 flex flex-col items-center justify-center text-center space-y-2">
                  <span className="text-[10px] font-mono text-gray-500 block uppercase tracking-wider">
                    SCAN TO INSTANTLY DEPOSIT
                  </span>
                  <img
                    src={paymentSettings.qrCodeUrl}
                    alt="Deposit QR"
                    className="w-44 h-44 object-contain rounded-xl border-2 border-[#1E253B] bg-white p-1.5 shadow-xl shadow-black/80"
                    referrerPolicy="no-referrer"
                  />
                  <p className="text-[9px] text-gray-400 font-mono leading-relaxed">
                    Scan via Google Pay, PhonePe, Paytm, or BHIM. Then enter the UTR / Ref No. below.
                  </p>
                </div>
              )}

              {/* Screenshot proofs */}
              <div>
                <label className="block text-[10px] font-mono text-gray-500 uppercase mb-1">
                  Upload screenshot attachment
                </label>
                <div className="relative border-2 border-dashed border-[#222D4A] rounded-xl p-4 bg-[#0A0E17] flex flex-col items-center justify-center text-center hover:border-gray-600 transition-colors cursor-pointer">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => processImageFile(e, setProofImage)}
                    className="absolute inset-0 opacity-0 cursor-pointer w-full"
                  />
                  {proofImage ? (
                    <div className="space-y-1.5">
                      <img
                        src={proofImage}
                        alt="attachment proof"
                        referrerPolicy="no-referrer"
                        className="max-h-24 rounded object-contain border border-[#222D4A] mx-auto"
                      />
                      <span className="text-[10px] text-emerald-400 font-mono flex items-center gap-0.5 justify-center">
                        <CheckCircle className="w-3 h-3" /> Screenshot Saved
                      </span>
                    </div>
                  ) : (
                    <div className="space-y-1">
                      <Upload className="w-6 h-6 text-gray-500 mx-auto" />
                      <p className="text-[11px] text-gray-400 font-mono">Tap to upload payment screenshot</p>
                      <p className="text-[9px] text-gray-600 font-mono">PNG / JPEG / WebP</p>
                    </div>
                  )}
                </div>
              </div>

              {/* UTR Input */}
              <div>
                <label className="block text-[10px] font-mono text-gray-500 uppercase mb-1">
                  UTR / UPI Ref No. / Transaction ID
                </label>
                <StableInput
                  type="text"
                  placeholder="Enter UPI UTR or Transaction ID (12 to 22 characters)"
                  value={utrCode}
                  onValueChange={setUtrCode}
                  className="w-full bg-[#0A0E17] border border-[#222D4A] rounded-xl py-2.5 px-3.5 text-white font-mono text-xs focus:ring-1 focus:ring-[#FF4500] focus:outline-none placeholder-gray-700"
                />
              </div>

              <div className="grid grid-cols-2 gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setDepositStep(1)}
                  className="bg-transparent border border-[#222D4A] py-2.5 rounded-xl text-gray-400 hover:text-white font-mono text-xs uppercase"
                >
                  ← Back
                </button>
                <button
                  type="submit"
                  id="submit-deposit-form"
                  disabled={isDepositing}
                  className={`py-2.5 text-white font-display font-bold text-xs uppercase tracking-wider rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                    isDepositing
                      ? 'bg-gray-700 pointer-events-none opacity-60'
                      : 'bg-gradient-to-r from-[#FF4500] to-[#C60000] hover:scale-[1.01]'
                  }`}
                >
                  {isDepositing && (
                    <span className="w-3.5 h-3.5 border-2 border-white/35 border-t-white rounded-full animate-spin" />
                  )}
                  {isDepositing ? 'Submitting...' : 'SUBMIT DEPOSIT'}
                </button>
              </div>
            </form>
          )}
        </div>
      )}

      {/* ================= 2. WITHDRAWAL PIPELINE ================= */}
      {mode === 'withdraw' && (
        <WithdrawalForm
          currentUser={currentUser}
          setLocalCurrentUser={setLocalCurrentUser}
          onSuccess={() => {
            setMode('idle');
          }}
          onCancel={() => setMode('idle')}
          processImageFile={processImageFile}
        />
      )}

      {/* ================= 3. CASH BOOK LEDGER LOGS ================= */}
      <div className="space-y-3">
        <div className="flex items-center justify-between text-xs font-mono text-gray-400 uppercase tracking-widest pl-1">
          <span className="flex items-center gap-1">
            <ListFilter className="w-4 h-4 text-[#FF4500]" />
            <span>TRANSACTION HISTORY</span>
          </span>
          <span>{transactions.length} entries</span>
        </div>

        <div className="space-y-2">
          {transactions.map((tx) => {
            const isPrize = tx.type === 'prize' || 
              (!!tx.utr && (tx.utr.startsWith('VALENT-WIN') || tx.utr.startsWith('CHAMP-WIN'))) || 
              (!!tx.upiId && tx.upiId.toUpperCase().includes('CONTEST:'));
            const isDeposit = tx.type === 'deposit' && !isPrize;
            const isApproved = tx.status === 'approved';
            const isRejected = tx.status === 'rejected';

            let statusColor = 'text-amber-400 bg-amber-500/10 border-amber-500/20';
            let StatusIcon = AlertCircle;

            if (isApproved) {
              statusColor = 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20';
              StatusIcon = CheckCircle;
            } else if (isRejected) {
              statusColor = 'text-red-400 bg-red-500/10 border-red-500/20';
              StatusIcon = XCircle;
            }

            return (
              <div
                key={tx.id}
                className="bg-[#13192B] border border-[#222D4A] rounded-xl p-3.5 space-y-3"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-2.5 min-w-0 flex-1">
                    <div
                      className={`p-2 rounded-lg flex-shrink-0 ${
                        isPrize
                          ? 'bg-amber-400/10 text-amber-400'
                          : isDeposit
                          ? 'bg-emerald-500/10 text-emerald-400'
                          : tx.withdrawMethod === 'googleplay'
                          ? 'bg-amber-500/10 text-amber-400'
                          : 'bg-red-500/10 text-[#FF4500]'
                      }`}
                    >
                      {isPrize ? (
                        <Trophy className="w-5 h-5 text-amber-450" />
                      ) : isDeposit ? (
                        <ArrowDownCircle className="w-5 h-5" />
                      ) : tx.withdrawMethod === 'googleplay' ? (
                        <Gift className="w-5 h-5" />
                      ) : (
                        <ArrowUpCircle className="w-5 h-5" />
                      )}
                    </div>

                    <div className="min-w-0 flex-1">
                      <h4 className="text-xs font-display font-bold text-white uppercase tracking-wider leading-tight break-words">
                        {tx.id.includes('referral') || tx.matchTitle?.toLowerCase().includes('referral') || (tx.note && tx.note.toLowerCase().includes('referral'))
                          ? 'REFERRAL REWARD 👥'
                          : isPrize
                          ? 'WON PRIZE 🏆'
                          : isDeposit
                          ? 'CASH DEPOSIT'
                          : tx.withdrawMethod === 'googleplay'
                          ? `GOOGLE PLAY REDEEM CODE (${tx.withdrawSource === 'deposit' ? 'DEPOSIT' : 'WINNINGS'})`
                          : `CASH OUT WITHDRAWAL (${tx.withdrawSource === 'deposit' ? 'DEPOSIT' : 'WINNINGS'})`}
                      </h4>
                      <span className="text-[10px] text-gray-400 font-mono mt-0.5 block leading-normal break-words">
                        {new Date(tx.created_at).toLocaleString([], {
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                        {(tx.matchTitle || (isPrize && tx.upiId && tx.upiId.toUpperCase().includes('CONTEST:'))) && (
                          <span className="block text-amber-500 font-bold text-[9.5px] mt-1.5 uppercase tracking-wider break-words">
                            🏆 {isPrize ? 'WIN' : 'CONTEST'}: {tx.matchTitle?.replace(/^(Win:|CONTEST:|Debit:|Deposit:)/i, '').trim() || tx.upiId?.replace(/CONTEST:/i, '').trim()}
                          </span>
                        )}
                        {tx.utr && !tx.utr.includes('ADMIN_') && <span className="block text-gray-500 text-[9px] mt-0.5 break-all">Ref/UTR: {tx.utr}</span>}
                        {tx.upiId && !isPrize && <span className="block text-gray-500 text-[9px] break-all">UPI: {tx.upiId}</span>}
                      </span>
                    </div>
                  </div>

                  <div className="text-right flex-shrink-0 min-w-[80px]">
                    <span
                      className={`text-sm font-mono font-bold block break-all ${
                        isPrize
                          ? 'text-amber-400'
                          : isDeposit
                          ? 'text-emerald-400'
                          : tx.withdrawMethod === 'googleplay'
                          ? 'text-amber-400'
                          : 'text-[#FF4500]'
                      }`}
                    >
                      {isPrize || isDeposit ? `+₹${tx.amount.toFixed(1)}` : `-₹${tx.amount.toFixed(1)}`}
                    </span>
                    <span
                      className={`inline-flex items-center gap-0.5 text-[9px] font-mono uppercase px-1.5 py-0.5 rounded border mt-1 leading-none ${statusColor}`}
                    >
                      <StatusIcon className="w-2.5 h-2.5" />
                      <span>{tx.status}</span>
                    </span>
                  </div>
                </div>

                {/* If Google Play Redeem Code option is selected */}
                {!isDeposit && !isPrize && tx.withdrawMethod === 'googleplay' && (
                  <div className="bg-[#0A0D18] border border-[#222D4A] rounded-xl p-3 mt-1 space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-[9px] font-mono text-gray-450 uppercase tracking-widest">
                        YOUR VOUCHER CODE
                      </span>
                      {isApproved && tx.redeemCode && (
                        <span className="text-[9px] font-mono text-[#00FFCC] font-bold animate-pulse">
                          Ready to Redeem
                        </span>
                      )}
                    </div>

                    {isApproved ? (
                      tx.redeemCode ? (
                        <div className="space-y-2">
                          <div className="flex items-center justify-between bg-[#151D33] border border-[#2E3C64] p-2 rounded-lg gap-2">
                            <code className="text-xs text-[#00FFCC] font-mono font-bold break-all select-all">
                              {tx.redeemCode}
                            </code>
                            <button
                              type="button"
                              onClick={() => handleCopyRedeemCode(tx.id, tx.redeemCode || '')}
                              className={`p-2 rounded bg-gray-900 border border-gray-850 transition-all font-mono text-[9px] flex items-center gap-1 shrink-0 ${
                                copiedTxId === tx.id
                                  ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20'
                                  : 'text-gray-300 hover:text-white hover:bg-gray-800'
                              }`}
                            >
                              {copiedTxId === tx.id ? (
                                <>
                                  <Check className="w-3.5 h-3.5" />
                                  <span>COPIED!</span>
                                </>
                              ) : (
                                <>
                                  <Copy className="w-3.5 h-3.5" />
                                  <span>COPY</span>
                                </>
                              )}
                            </button>
                          </div>

                          <div className="bg-[#12192A]/60 border border-[#222D4A]/50 rounded-lg p-2.5 space-y-2 text-left">
                            <span className="text-[9px] font-mono font-bold text-gray-400 uppercase tracking-wider block">
                              Claim on Google Play Store:
                            </span>
                            <ol className="text-[9px] text-gray-300 space-y-1 list-decimal list-inside font-sans leading-relaxed">
                              <li>Copy the 16-digit voucher code shown above.</li>
                              <li>Open the <span className="text-amber-400 font-bold">Google Play Store</span> app on your phone.</li>
                              <li>Tap your <span className="font-bold text-white">Profile Icon</span> in the top-right corner.</li>
                              <li>Select <span className="font-bold text-white">Payments & Subscriptions</span> &gt; <span className="font-bold text-emerald-400">Redeem code</span>.</li>
                              <li>Paste the copied voucher code and submit to add <span className="text-[#00FFCC] font-bold">₹{tx.amount}</span> directly to your Google Play balance!</li>
                            </ol>
                            <a
                              href="https://play.google.com/redeem"
                              target="_blank"
                              rel="noreferrer"
                              className="inline-flex items-center gap-1.5 text-[9px] font-mono font-black text-[#00FFCC] hover:text-[#00FFCC]/80 transition-all uppercase pt-1"
                            >
                              🚀 Direct Play Store Web Link ↗
                            </a>
                          </div>
                        </div>
                      ) : (
                        <div className="text-[10px] text-amber-400/90 bg-amber-500/5 border border-amber-500/10 rounded-lg p-2.5 text-center font-mono">
                          ⏳ Code generation pending. Admin will upload the code shortly.
                        </div>
                      )
                    ) : isRejected ? (
                      <div className="text-[10px] text-red-500/80 bg-red-500/5 border border-red-500/10 rounded-lg p-2 text-center font-mono">
                        🚫 Transaction Rejected. Your balance has been restored.
                      </div>
                    ) : (
                      <div className="text-[10px] bg-amber-500/5 border border-amber-500/10 rounded-lg p-3 text-center font-mono space-y-1">
                        {tx.withdrawMethod === 'googleplay' ? (
                          <>
                            <div className="flex items-center justify-center gap-1.5 text-amber-400 font-extrabold text-[10.5px] uppercase tracking-wider animate-pulse mb-0.5">
                              ⚡ QUEUE PROCESSING...
                            </div>
                            <span className="block text-gray-400 leading-relaxed text-[9.5px]">
                              Our secure voucher queue is currently generating your Google Play Redeem Code. Auto-generation usually takes 2-5 minutes.
                            </span>
                          </>
                        ) : (
                          <span className="text-gray-400">⏳ Awaiting Admin Approval. Payout queue locked.</span>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}

          {transactions.length === 0 && (
            <div className="text-center py-10 bg-[#13192B]/35 border border-dashed border-[#222D4A] rounded-xl">
              <Coins className="w-7 h-7 text-gray-650 mx-auto mb-2" />
              <p className="text-gray-500 text-xs font-mono">No finances records logged in profile.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
