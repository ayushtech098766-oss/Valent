import React, { useState, useEffect, useRef } from 'react';
import { Match, MatchFormat, Transaction, User, MatchPlayer, MatchSubmission, PromoBanner, SupportMessage } from '../types';
import { compressImage } from '../utils';
import {
  getMatches,
  saveMatches,
  getTransactions,
  saveTransactions,
  getUsers,
  saveUsers,
  getAdminPaymentSettings,
  saveAdminPaymentSettings,
  getPromoBanners,
  savePromoBanners,
  getGlobalRules,
  saveGlobalRules,
  getSupportMessages,
  saveSupportMessages,
  getCurrentUser
} from '../db';
import {
  ArrowLeft,
  Check,
  X,
  Plus,
  Trash,
  Upload,
  Coins,
  ShieldCheck,
  ShieldAlert,
  Send,
  MessageSquare,
  MessageCircle,
  Sparkles,
  Award,
  Users,
  Layers,
  MapPin,
  ListFilter,
  Eye,
  Settings,
  Copy,
  QrCode,
  Trophy,
  Image as ImageIcon,
  Loader2
} from 'lucide-react';

interface AdminPanelProps {
  onBackToDashboard: () => void;
}

export default function AdminPanel({ onBackToDashboard }: AdminPanelProps) {
  const currentUser = getCurrentUser();
  const userRole = currentUser?.role || 'player';

  // Helper check for tabs
  const canAccessTab = (tab: 'matches' | 'rooms' | 'disputes' | 'financials' | 'banners' | 'rules' | 'support' | 'requests') => {
    if (userRole === 'admin') return true;
    if (userRole === 'wallet_manager') {
      return tab === 'financials' || tab === 'support' || tab === 'requests';
    }
    if (userRole === 'chat_manager') {
      return tab === 'disputes' || tab === 'support';
    }
    return false;
  };

  // Navigation tabs of administrator desk
  const [activeTab, setActiveTab] = useState<'matches' | 'rooms' | 'disputes' | 'financials' | 'banners' | 'rules' | 'support' | 'requests'>(() => {
    const u = getCurrentUser();
    if (u?.role === 'wallet_manager') return 'requests';
    if (u?.role === 'chat_manager') return 'support';
    return 'matches';
  });

  // Database list states
  const [matches, setMatches] = useState<Match[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [banners, setBanners] = useState<PromoBanner[]>([]);

  // Custom Deletion overlays (replaces unsafe window.confirm)
  const [deleteMatchConfirmation, setDeleteMatchConfirmation] = useState<{ show: boolean; matchId: string; matchTitle: string } | null>(null);
  const [deleteBannerConfirmation, setDeleteBannerConfirmation] = useState<{ show: boolean; bannerId: string; bannerTitle: string } | null>(null);

  // Global rules rulebook paragraph draft state
  const [globalRulesText, setGlobalRulesText] = useState(getGlobalRules());

  // Create Match form state
  const [newTitle, setNewTitle] = useState('');
  const [newMap, setNewMap] = useState('Bermuda (Hangar)');
  const [newFormat, setNewFormat] = useState<MatchFormat>('4v4');
  const [newEntryFee, setNewEntryFee] = useState<number>(50);
  const [newPrizePool, setNewPrizePool] = useState<number>(90);
  const [newPrizePerPlayer, setNewPrizePerPlayer] = useState<number>(0);
  const [perKillEnabled, setPerKillEnabled] = useState<boolean>(false);
  const [perKillAmount, setPerKillAmount] = useState<number>(10);

  // Promo Banners form state
  const [newBannerTitle, setNewBannerTitle] = useState('');
  const [newBannerImageUrl, setNewBannerImageUrl] = useState('');
  const [newBannerLinkUrl, setNewBannerLinkUrl] = useState('');
  const [isCompressingBanner, setIsCompressingBanner] = useState(false);

  // Broadcaster states for room distribution
  const [broadcastingMatchId, setBroadcastingMatchId] = useState<string | null>(null);
  const [broadcastRoomId, setBroadcastRoomId] = useState('');
  const [broadcastPassword, setBroadcastPassword] = useState('');
  const [broadcastReleaseMode, setBroadcastReleaseMode] = useState<'now' | 'scheduled'>('now');

  // Grid Lineup editor states
  const [editingMatchLineupId, setEditingMatchLineupId] = useState<string | null>(null);
  const [editingLineupPlayers, setEditingLineupPlayers] = useState<MatchPlayer[]>([]);

  // Custom Match Timing configuration states
  const [editingMatchTimingId, setEditingMatchTimingId] = useState<string | null>(null);
  const [revealInMins, setRevealInMins] = useState<number>(2);
  const [startInMins, setStartInMins] = useState<number>(5);

  // Conflict screen inspect state
  const [disputeMatchId, setDisputeMatchId] = useState<string | null>(null);

  // Financial payout message
  const [statusMsg, setStatusMsg] = useState<string | null>(null);

  // Google Play Redeem Codes admin dictionary
  const [adminRedeemCodes, setAdminRedeemCodes] = useState<Record<string, string>>({});

  // Copied transaction ID helper state
  const [copiedTxId, setCopiedTxId] = useState<string | null>(null);

  // Admin Payment settings form state
  const [adminUpiId, setAdminUpiId] = useState('');
  const [adminQrCodeUrl, setAdminQrCodeUrl] = useState('');
  const [isCompressingPaymentQr, setIsCompressingPaymentQr] = useState(false);
  const [paymentSettingsSavedMsg, setPaymentSettingsSavedMsg] = useState(false);
  const [whatsappGroupUrl, setWhatsappGroupUrl] = useState('');
  const [whatsappGroupUrlSaved, setWhatsappGroupUrlSaved] = useState(false);

  // Manual User Wallet Balances Adjuster states
  const [selectedAdjUserId, setSelectedAdjUserId] = useState<string>('');
  const [adjAmount, setAdjAmount] = useState<string>('');
  const [adjType, setAdjType] = useState<'credit' | 'debit'>('credit');
  const [adjWalletPool, setAdjWalletPool] = useState<'deposit' | 'winnings'>('deposit');
  const [adjNote, setAdjNote] = useState<string>('');
  const [userSearchQuery, setUserSearchQuery] = useState<string>('');

  // Rapid Match-based Payout states
  const [selectedPayoutMatchId, setSelectedPayoutMatchId] = useState<string>('');
  const [matchPayoutAmounts, setMatchPayoutAmounts] = useState<Record<string, string>>({}); 
  const [matchPayoutNotes, setMatchPayoutNotes] = useState<Record<string, string>>({}); 
  const [payoutLogsFeed, setPayoutLogsFeed] = useState<string | null>(null);
  const [activeZoomImage, setActiveZoomImage] = useState<string | null>(null);
  const [requestsFilter, setRequestsFilter] = useState<'all' | 'deposit' | 'withdrawal'>('all');
  const [requestsSearch, setRequestsSearch] = useState<string>('');

  // Custom confirmation modal states for manual wallet adjustment
  const [showAdjConfirmModal, setShowAdjConfirmModal] = useState(false);
  const [adjConfirmData, setAdjConfirmData] = useState<{
    targetUserId: string;
    username: string;
    ign?: string;
    phone: string;
    amount: number;
    type: 'credit' | 'debit';
    pool: 'deposit' | 'winnings';
    note: string;
    isWarning: boolean;
    currentBalance: number;
  } | null>(null);

  const [adjSuccessFeedback, setAdjSuccessFeedback] = useState<string | null>(null);
  const [adjErrorFeedback, setAdjErrorFeedback] = useState<string | null>(null);

  // Custom states for beautiful, reliable transaction audit confirmations (eliminating un-trusted iframe-blocking window.confirm & alert dialogs)
  const [txAuditConfirm, setTxAuditConfirm] = useState<{
    txId: string;
    action: 'approved' | 'rejected';
    type: 'deposit' | 'withdrawal';
    amount: number;
    withdrawMethod?: string;
    username: string;
  } | null>(null);
  const [txAlertMessage, setTxAlertMessage] = useState<string | null>(null);

  // Live support chat state
  const [supportMessages, setSupportMessages] = useState<SupportMessage[]>([]);
  const [selectedChatUserId, setSelectedChatUserId] = useState<string | null>(null);
  const [adminReplyText, setAdminReplyText] = useState('');
  const [adminReplyImage, setAdminReplyImage] = useState<string>('');
  const [isAdminCompressing, setIsAdminCompressing] = useState(false);
  const [adminZoomImage, setAdminZoomImage] = useState<string | null>(null);
  const adminChatFileInputRef = useRef<HTMLInputElement>(null);
  const adminChatEndRef = useRef<HTMLDivElement>(null);

  // Load everything
  const loadAdminData = () => {
    setMatches(getMatches());
    setUsers(getUsers());
    setTransactions(getTransactions());
    setBanners(getPromoBanners());
    setSupportMessages(getSupportMessages());
    const payment = getAdminPaymentSettings();
    setAdminUpiId(payment.upiId);
    setAdminQrCodeUrl(payment.qrCodeUrl);
    setWhatsappGroupUrl(payment.whatsappGroupUrl || '');
  };

  useEffect(() => {
    loadAdminData();
    window.addEventListener('valent_db_update', loadAdminData);
    return () => {
      window.removeEventListener('valent_db_update', loadAdminData);
    };
  }, []);

  // Mark messages from player as read when admin opens chat context
  useEffect(() => {
    if (selectedChatUserId && activeTab === 'support') {
      const allMsgs = getSupportMessages();
      let updated = false;
      const mapped = allMsgs.map(m => {
        if (m.userId === selectedChatUserId && m.senderId !== 'admin' && !m.readByAdmin) {
          updated = true;
          return { ...m, readByAdmin: true };
        }
        return m;
      });
      if (updated) {
        saveSupportMessages(mapped);
      }
    }
  }, [selectedChatUserId, activeTab, supportMessages.length]);

  // Keep admin conversational chat scrolled to end on message updates
  useEffect(() => {
    if (selectedChatUserId) {
      setTimeout(() => {
        adminChatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    }
  }, [selectedChatUserId, supportMessages.length]);

  const handleAdminSupportImageSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsAdminCompressing(true);
    const reader = new FileReader();
    reader.onloadend = async () => {
      const rawBase64 = reader.result as string;
      try {
        const compressed = await compressImage(rawBase64, 450, 450, 0.65);
        setAdminReplyImage(compressed);
      } catch (err) {
        setAdminReplyImage(rawBase64);
      } finally {
        setIsAdminCompressing(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleAdminSendReply = (e: React.FormEvent) => {
    e.preventDefault();
    const hasText = !!adminReplyText.trim();
    const hasImage = !!adminReplyImage;
    if ((!hasText && !hasImage) || !selectedChatUserId) return;

    const targetUser = users.find(u => u.id === selectedChatUserId);
    const targetUsername = targetUser ? targetUser.username : 'Esports Player';

    const newMsg: SupportMessage = {
      id: `msg-${Date.now()}-${Math.random()}`,
      userId: selectedChatUserId,
      username: targetUsername,
      senderId: 'admin',
      senderName: 'Matchmaster Support Manager',
      text: adminReplyText.trim() || "Shared an attachment from gallery",
      imageUrl: adminReplyImage || undefined,
      timestamp: new Date().toISOString(),
      readByAdmin: true,
      readByUser: false,
    };

    const allMsgs = getSupportMessages();
    allMsgs.push(newMsg);
    saveSupportMessages(allMsgs);
    setAdminReplyText('');
    setAdminReplyImage('');
  };

  // 🧮 Capacity & Collection Calculations
  const calculatedStats = React.useMemo(() => {
    let slots = 2;
    if (newFormat === '1v1') slots = 2;
    else if (newFormat === '2v2') slots = 4;
    else if (newFormat === '4v4') slots = 8;
    else if (newFormat === '6v6') slots = 12;
    else if (newFormat === 'teamvsteam4v4') slots = 8;
    else if (newFormat === 'teamvsteam6v6') slots = 12;
    else if (newFormat === 'BR') slots = 48;

    const totalCollection = slots * newEntryFee;

    return {
      slots,
      totalCollection
    };
  }, [newFormat, newEntryFee]);

  // Create lobby action
  const handleCreateMatch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) {
      alert('⚠️ Please specify a Title.');
      return;
    }

    const { slots } = calculatedStats;

    const newMatch: Match = {
      id: `match-${Date.now()}`,
      title: newTitle.trim(),
      mapName: newMap,
      format_type: newFormat,
      entryFee: newEntryFee,
      prizePool: newPrizePool,
      perKillEnabled: perKillEnabled,
      perKillAmount: perKillEnabled ? perKillAmount : undefined,
      spotsTotal: slots,
      spotsFilled: 0,
      status: 'PENDING_START',
      players: [],
      submissions: [],
      disputeChat: [],
      prizePerPlayer: newPrizePerPlayer > 0 ? newPrizePerPlayer : undefined
    };

    const updated = [newMatch, ...matches];
    saveMatches(updated);
    setMatches(updated);

    setNewTitle('');
    setNewPrizePerPlayer(0);
    alert('🎉 New Esports Match lobby published and live for players!');
  };

  const handleDeleteMatch = (mid: string) => {
    const target = matches.find(m => m.id === mid);
    if (!target) return;
    setDeleteMatchConfirmation({
      show: true,
      matchId: mid,
      matchTitle: target.title
    });
  };

  const handleConfirmDeleteMatch = () => {
    if (!deleteMatchConfirmation) return;
    const mid = deleteMatchConfirmation.matchId;
    const updated = matches.filter(m => m.id !== mid);
    saveMatches(updated);
    setMatches(updated);
    setDeleteMatchConfirmation(null);
  };

  const handleCancelDeleteMatch = () => {
    setDeleteMatchConfirmation(null);
  };

  // 📢 Broadcast Custom Room Credentials tool
  const handleBroadcastRoom = (mid: string) => {
    if (!broadcastRoomId.trim() || !broadcastPassword.trim()) {
      alert('Please fill Room ID and Password prior to dispatching.');
      return;
    }

    const targetMatch = matches.find(m => m.id === mid);
    if (!targetMatch) return;

    let hasTimerSet = !!targetMatch.credentialsRevealTime;
    let revealTimeISO = targetMatch.credentialsRevealTime || '';
    let startTimeISO = targetMatch.matchStartTime || '';

    if (broadcastReleaseMode === 'scheduled' && !hasTimerSet) {
      if (confirm('⏱️ No reveal timer has been set for this match yet!\n\nWould you like to automatically schedule the ID/Password reveal in 2 minutes (and official start in 7 minutes) from now?')) {
        const nowMs = Date.now();
        revealTimeISO = new Date(nowMs + 2 * 60 * 1000).toISOString();
        startTimeISO = new Date(nowMs + (2 + 5) * 60 * 1000).toISOString();
        hasTimerSet = true;
      } else {
        return;
      }
    }

    let confirmText = '';
    if (broadcastReleaseMode === 'now') {
      confirmText = `🚀 Are you sure you want to broadcast and reveal these parameters IMMEDIATELY?\n\nThis will make the credentials visible to players right away (bypassing any scheduled reveal timer).`;
    } else {
      const revealDate = new Date(revealTimeISO);
      confirmText = `⏱️ Keep Scheduled Timer Reveal?\n\nThis will securely save the ID & Password inside the system. Players will only be able to view these parameters when the countdown timer ends (scheduled for ${revealDate.toLocaleTimeString()}).`;
    }

    if (!confirm(confirmText)) {
      return;
    }

    const updated = matches.map(m => {
      if (m.id === mid) {
        return {
          ...m,
          roomId: broadcastRoomId.trim(),
          roomPassword: broadcastPassword.trim(),
          credentialsRevealTime: revealTimeISO || m.credentialsRevealTime,
          matchStartTime: startTimeISO || m.matchStartTime,
          status: broadcastReleaseMode === 'now' ? ('ROOM_READY' as const) : ('PENDING_START' as const)
        };
      }
      return m;
    });

    saveMatches(updated);
    setMatches(updated);
    setBroadcastingMatchId(null);
    setBroadcastRoomId('');
    setBroadcastPassword('');
    
    if (broadcastReleaseMode === 'now') {
      alert('🚀 Custom credentials broadcasted instantly! Room parameters are now visible on joined players\' dashboards.');
    } else {
      const revealDate = new Date(revealTimeISO);
      alert(`⏱️ Room credentials saved securely! They will be released/revealed automatically when the countdown timer ends at ${revealDate.toLocaleTimeString()}.`);
    }
  };

  // 👥 Save Lineup Modifications to Database & Sync Firestore
  const handleSaveGridLineup = (mid: string) => {
    const updated = matches.map(m => {
      if (m.id === mid) {
        return {
          ...m,
          players: editingLineupPlayers
        };
      }
      return m;
    });

    saveMatches(updated);
    setMatches(updated);
    setEditingMatchLineupId(null);
    alert('👥 Match roster lineup positions saved and synced successfully! Players will get an alert popup on their active dashboards.');
  };

  // ⏱️ Save Timings configuration relative to now & Sync
  const handleSaveMatchTimings = (mid: string) => {
    const nowMs = Date.now();
    const revealTimeISO = new Date(nowMs + revealInMins * 60 * 1000).toISOString();
    const startTimeISO = new Date(nowMs + (revealInMins + startInMins) * 60 * 1000).toISOString();

    const updated = matches.map(m => {
      if (m.id === mid) {
        return {
          ...m,
          credentialsRevealTime: revealTimeISO,
          matchStartTime: startTimeISO
        };
      }
      return m;
    });

    saveMatches(updated);
    setMatches(updated);
    setEditingMatchTimingId(null);
    alert(`⏱️ Custom timing constraints updated: Room credentials reveal set in ${revealInMins} mins, and starting countdown set in ${revealInMins + startInMins} mins from now.`);
  };

  // 🔒 Force Make Live (Locked) Status Overrides
  const handleForceLockAndLive = (mid: string) => {
    const targetMatch = matches.find(m => m.id === mid);
    const title = targetMatch ? `"${targetMatch.title}"` : 'this match';
    
    if (!confirm(`🔒 Are you absolutely sure you want to manually set ${title} to LIVE state?\n\nThis will lock the lobby, prevent any new completions/registrations, and reveal the room credentials immediately.`)) {
      return;
    }

    const updated = matches.map(m => {
      if (m.id === mid) {
        return {
          ...m,
          status: 'LIVE' as const,
          matchStartTime: new Date().toISOString() // Set immediately past to trigger locks on client UI
        };
      }
      return m;
    });

    saveMatches(updated);
    setMatches(updated);
    alert('🔒 Match has been set to LIVE. The lobby is now locked; no addition joins are accepted.');
  };

  // ⚔️ Conflict Resolving Engine
  const handleResolveMatchOutcome = (mid: string, winningTeam: 'A' | 'B') => {
    const target = matches.find(m => m.id === mid);
    if (!target) return;

    if (!confirm(`⚔️ Are you sure you want to approve Team ${winningTeam} as the winner of "${target.title}"?\n\nThis will distribute the prize pool of ₹${target.prizePool} instantly to all registered members of Team ${winningTeam}. This action is irreversible.`)) {
      return;
    }

    // Credit Winnings to all players on that winning team
    const winningPlayers = target.players.filter(p => p.team === winningTeam);
    const rewardPerWinner = Math.round(target.prizePool / Math.max(1, winningPlayers.length));

    // Update users catalog
    const allUsers = getUsers();
    const updatedUsers = allUsers.map(u => {
      const isWinner = winningPlayers.some(wp => wp.userId === u.id);
      if (isWinner) {
        return {
          ...u,
          wallet: {
            ...u.wallet,
            winnings: u.wallet.winnings + rewardPerWinner
          }
        };
      }
      return u;
    });
    saveUsers(updatedUsers);

    // Save Transactions for each winner
    const txs = getTransactions();
    winningPlayers.forEach(wp => {
      txs.unshift({
        id: `tx-prize-${Date.now()}-${wp.userId}`,
        userId: wp.userId,
        type: 'prize',
        amount: rewardPerWinner,
        status: 'approved',
        created_at: new Date().toISOString(),
        matchId: target.id,
        matchTitle: target.title
      });
    });
    saveTransactions(txs);

    // Transition state
    const updatedMatches = matches.map(m => {
      if (m.id === mid) {
        return {
          ...m,
          status: 'COMPLETED' as const,
          winningTeam,
          winnerNote: `Team ${winningTeam} approved by custom admin audit.`
        };
      }
      return m;
    });
    saveMatches(updatedMatches);
    setMatches(updatedMatches);
    setDisputeMatchId(null);
    alert(`🏆 Match audit completed successfully! Transferred ₹${rewardPerWinner} each to ${winningPlayers.length} winners from Team ${winningTeam}.`);
  };

  // 💸 Total Refund Match option
  const handleRefundMatch = (mid: string) => {
    const target = matches.find(m => m.id === mid);
    if (!target) return;

    if (!confirm('Are you sure you want to refund entry fees to all registered players?')) return;

    const allUsers = getUsers();
    const txs = getTransactions();

    const updatedUsers = allUsers.map(u => {
      const playerReg = target.players.find(p => p.userId === u.id);
      if (playerReg) {
        // Refund back to deposit
        txs.unshift({
          id: `tx-refund-${Date.now()}-${u.id}`,
          userId: u.id,
          type: 'entry_refund',
          amount: target.entryFee,
          status: 'approved',
          created_at: new Date().toISOString(),
          matchId: target.id,
          matchTitle: target.title
        });

        return {
          ...u,
          wallet: {
            ...u.wallet,
            deposit: u.wallet.deposit + target.entryFee
          }
        };
      }
      return u;
    });

    saveUsers(updatedUsers);
    saveTransactions(txs);

    const updatedMatches = matches.map(m => {
      if (m.id === mid) {
        return {
          ...m,
          status: 'COMPLETED' as const,
          winnerNote: 'Refunded by system admin override.'
        };
      }
      return m;
    });
    saveMatches(updatedMatches);
    setMatches(updatedMatches);
    setDisputeMatchId(null);
    alert('💸 All registered player entry fees have been fully refunded and credited back instantly.');
  };

  const handleCopyText = (txId: string, text: string) => {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(() => {
          setCopiedTxId(txId);
          setTimeout(() => setCopiedTxId(null), 2000);
        }).catch(() => {
          fallbackQueryCopy(text, txId);
        });
      } else {
        fallbackQueryCopy(text, txId);
      }
    } catch (e) {
      fallbackQueryCopy(text, txId);
    }
  };

  const fallbackQueryCopy = (text: string, txId: string) => {
    try {
      const textArea = document.createElement("textarea");
      textArea.value = text;
      textArea.style.position = "fixed";
      textArea.style.opacity = "0";
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();
      document.execCommand("copy");
      document.body.removeChild(textArea);
      setCopiedTxId(txId);
      setTimeout(() => setCopiedTxId(null), 2000);
    } catch (err) {}
  };

  // 💰 Deposit / Withdrawal audit initiation (triggers custom UX confirmation modal)
  const initiateApproveTransaction = (txId: string, status: 'approved' | 'rejected') => {
    const txs = getTransactions();
    const target = txs.find(t => t.id === txId);
    if (!target) return;

    // Google Play Check before allowing initiation
    if (status === 'approved' && target.type === 'withdrawal' && target.withdrawMethod === 'googleplay') {
      const gplayCode = adminRedeemCodes[txId]?.trim();
      if (!gplayCode || gplayCode.length < 5) {
        setTxAlertMessage('⚠️ Google Play Gift Payout requires filling the 16-digit Redeem Voucher PIN first!');
        return;
      }
    }

    const u = users.find(usr => usr.id === target.userId);
    const username = u?.username || 'Player';

    // Set interactive confirmation state to summon the custom modal
    setTxAuditConfirm({
      txId,
      action: status,
      type: target.type,
      amount: target.amount,
      withdrawMethod: target.withdrawMethod,
      username,
    });
  };

  // 💰 Decisive commit operation after admin verifies via the overlay portal modal
  const commitApproveTransaction = () => {
    if (!txAuditConfirm) return;
    const { txId, action, type, amount, withdrawMethod } = txAuditConfirm;

    const txs = getTransactions();
    const target = txs.find(t => t.id === txId);
    if (!target) {
      setTxAuditConfirm(null);
      return;
    }

    if (action === 'approved' && type === 'withdrawal' && withdrawMethod === 'googleplay') {
      const gplayCode = adminRedeemCodes[txId]?.trim();
      if (!gplayCode) {
        setTxAlertMessage('⚠️ Error: Google Play Redeem Voucher Code is empty.');
        setTxAuditConfirm(null);
        return;
      }
      target.redeemCode = gplayCode.toUpperCase();
    }

    target.status = action;

    // If approved deposit, add to user wallet
    // If rejected withdrawal, refund back to user winnings/deposit source
    if (action === 'approved' && type === 'deposit') {
      const allUsers = getUsers();
      const uidx = allUsers.findIndex(u => u.id === target.userId);
      if (uidx !== -1) {
        allUsers[uidx].wallet.deposit += target.amount;

        // --- AUTOMATED REFERRAL SYSTEM TRIGGER ---
        const targetUser = allUsers[uidx];
        const referredBy = targetUser.referredBy;
        const referredByUserId = targetUser.referredByUserId;
        const rewardAlreadyPaid = targetUser.isReferralRewardPaid;

        if (targetUser.wallet.deposit >= 60 && referredBy && !rewardAlreadyPaid) {
          const inviteridx = allUsers.findIndex(usr => 
            (referredByUserId && usr.id === referredByUserId) || 
            (usr.referralCode && usr.referralCode.toUpperCase() === referredBy.toUpperCase()) ||
            (usr.username && usr.username.toUpperCase() === referredBy.toUpperCase())
          );

          if (inviteridx !== -1) {
            allUsers[inviteridx].wallet.deposit = Number((allUsers[inviteridx].wallet.deposit + 25).toFixed(2));
            allUsers[uidx].isReferralRewardPaid = true;

            const rTx: Transaction = {
              id: `tx-referral-reward-${Date.now()}`,
              userId: allUsers[inviteridx].id,
              type: 'deposit',
              amount: 25,
              status: 'approved',
              created_at: new Date().toISOString(),
              matchTitle: 'Referral Reward 👥',
              note: `Referral bonus reward for inviting @${targetUser.username}!`
            };
            txs.unshift(rTx);
            console.log(`Referral reward ₹25 paid to @${allUsers[inviteridx].username} for @${targetUser.username}'s deposit.`);
          }
        }

        saveUsers(allUsers);
        setUsers(allUsers); // Sync state instantly
      }
    } else if (action === 'rejected' && type === 'withdrawal') {
      const allUsers = getUsers();
      const uidx = allUsers.findIndex(u => u.id === target.userId);
      if (uidx !== -1) {
        const source = target.withdrawSource || 'winnings';
        if (source === 'winnings') {
          allUsers[uidx].wallet.winnings = Number((allUsers[uidx].wallet.winnings + target.amount).toFixed(2));
        } else {
          allUsers[uidx].wallet.deposit = Number((allUsers[uidx].wallet.deposit + target.amount).toFixed(2));
        }
        saveUsers(allUsers);
        setUsers(allUsers); // Sync state instantly
      }
    }

    saveTransactions(txs);
    setTransactions([...txs]);
    setTxAuditConfirm(null);

    setStatusMsg(`💼 Transaction audit committed: ${action.toUpperCase()}`);
    setTimeout(() => setStatusMsg(null), 4000);
  };

  const handleApproveTransaction = (txId: string, status: 'approved' | 'rejected') => {
    initiateApproveTransaction(txId, status);
  };

  // 💰 Manual Wallet Creditor & Deducter for Real Users
  const handleManualWalletAdjustment = (e: React.FormEvent) => {
    e.preventDefault();
    setAdjSuccessFeedback(null);
    setAdjErrorFeedback(null);

    if (!selectedAdjUserId) {
      setAdjErrorFeedback('⚠️ Please select a user from the directory first!');
      return;
    }
    const amountVal = parseFloat(adjAmount);
    if (isNaN(amountVal) || amountVal <= 0) {
      setAdjErrorFeedback('⚠️ Please enter a valid positive numeric amount (e.g. 500).');
      return;
    }

    const allUsers = getUsers();
    const targetUser = allUsers.find(u => u.id === selectedAdjUserId);
    if (!targetUser) {
      setAdjErrorFeedback('⚠️ Selected user was not found inside the database.');
      return;
    }

    // Determine current pool balance & check negative balance warning
    const currentBal = adjWalletPool === 'deposit' ? targetUser.wallet.deposit : targetUser.wallet.winnings;
    const isWarning = adjType === 'debit' && currentBal < amountVal;

    setAdjConfirmData({
      targetUserId: targetUser.id,
      username: targetUser.username,
      ign: targetUser.ign,
      phone: targetUser.phone,
      amount: amountVal,
      type: adjType,
      pool: adjWalletPool,
      note: adjNote,
      isWarning,
      currentBalance: currentBal
    });
    setShowAdjConfirmModal(true);
  };

  const commitManualWalletAdjustment = () => {
    if (!adjConfirmData) return;
    
    const { targetUserId, amount, type, pool, note } = adjConfirmData;
    const allUsers = getUsers();
    const uidx = allUsers.findIndex(u => u.id === targetUserId);
    
    if (uidx === -1) {
      setAdjErrorFeedback('⚠️ Error: Selected player was not found in the live directory.');
      setShowAdjConfirmModal(false);
      return;
    }

    const targetUser = allUsers[uidx];
    let referralTxToAdd: Transaction | null = null;

    // Perform the adjustment
    if (type === 'credit') {
      if (pool === 'deposit') {
        allUsers[uidx].wallet.deposit += amount;

        // --- AUTOMATED REFERRAL SYSTEM TRIGGER ---
        const referredBy = targetUser.referredBy;
        const referredByUserId = targetUser.referredByUserId;
        const rewardAlreadyPaid = targetUser.isReferralRewardPaid;

        if (allUsers[uidx].wallet.deposit >= 60 && referredBy && !rewardAlreadyPaid) {
          const inviteridx = allUsers.findIndex(usr => 
            (referredByUserId && usr.id === referredByUserId) || 
            (usr.referralCode && usr.referralCode.toUpperCase() === referredBy.toUpperCase()) ||
            (usr.username && usr.username.toUpperCase() === referredBy.toUpperCase())
          );

          if (inviteridx !== -1) {
            allUsers[inviteridx].wallet.deposit = Number((allUsers[inviteridx].wallet.deposit + 25).toFixed(2));
            allUsers[uidx].isReferralRewardPaid = true;

            referralTxToAdd = {
              id: `tx-referral-reward-${Date.now()}`,
              userId: allUsers[inviteridx].id,
              type: 'deposit',
              amount: 25,
              status: 'approved',
              created_at: new Date().toISOString(),
              matchTitle: 'Referral Reward 👥',
              note: `Referral bonus reward for inviting @${targetUser.username}!`
            };
            console.log(`Referral reward ₹25 paid to @${allUsers[inviteridx].username} for @${targetUser.username}'s manual deposit.`);
          }
        }
      } else {
        allUsers[uidx].wallet.winnings += amount;
      }
    } else {
      // Debit
      if (pool === 'deposit') {
        allUsers[uidx].wallet.deposit -= amount;
      } else {
        allUsers[uidx].wallet.winnings -= amount;
      }
    }

    // Save changes to database
    saveUsers(allUsers);
    setUsers(allUsers);

    // Create companion transaction record
    const txs = getTransactions();
    if (referralTxToAdd) {
      txs.unshift(referralTxToAdd);
    }
    const adjustmentTypeKeyStr = type === 'credit' ? (pool === 'winnings' ? 'prize' : 'deposit') : 'withdrawal';
    
    const newTx: Transaction = {
      id: `manual-adj-${Date.now()}`,
      userId: targetUserId,
      type: adjustmentTypeKeyStr as any,
      amount: amount,
      status: 'approved',
      created_at: new Date().toISOString(),
      utr: pool === 'winnings' ? `WIN-${Date.now().toString().slice(-6)}` : `TXN-${Date.now().toString().slice(-6)}`,
      withdrawMethod: 'upi',
      withdrawSource: pool,
      matchTitle: type === 'credit' ? (pool === 'winnings' ? `Win: ${note || 'Contest Reward'}` : `Deposit: ${note || 'Account Correction'}`) : `Debit: ${note || 'Account Correction'}`
    };

    txs.unshift(newTx);
    saveTransactions(txs);
    setTransactions(txs);

    // Clean inputs and reset states on success
    setAdjAmount('');
    setAdjNote('');
    setAdjConfirmData(null);
    setShowAdjConfirmModal(false);
    
    setAdjSuccessFeedback(`🎉 Successfully manually ${type === 'credit' ? 'credited' : 'deducted'} ₹${amount.toFixed(2)} to @${targetUser.username}'s ${pool} wallet pool.`);
    
    setTimeout(() => {
      setAdjSuccessFeedback(null);
    }, 6000);
  };

  // 🛡️ Promote User role and privileges
  const handlePromoteUser = (targetUserId: string, targetRole: 'admin' | 'wallet_manager' | 'chat_manager' | 'player') => {
    const curUser = getCurrentUser();
    if (!curUser || curUser.role !== 'admin') {
      alert("⚠️ Only the System Owner (Admin) can promote other users.");
      return;
    }
    
    const allUsers = getUsers();
    const updatedUsers = allUsers.map(u => {
      if (u.id === targetUserId) {
        const isAdmin = targetRole !== 'player';
        return { ...u, role: targetRole, is_admin: isAdmin };
      }
      return u;
    });
    
    setUsers(updatedUsers);
    saveUsers(updatedUsers);
    setStatusMsg(`🎉 Role of @${allUsers.find(u => u.id === targetUserId)?.username} updated to ${targetRole.replace('_', ' ').toUpperCase()} successfully!`);
    setTimeout(() => setStatusMsg(null), 3000);
  };

  // 📸 Promo Banner functions
  const handleCreateBanner = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBannerImageUrl.trim()) {
      alert('⚠️ Please specify an image URL or upload one first.');
      return;
    }

    const newBanner: PromoBanner = {
      id: `banner-${Date.now()}`,
      imageUrl: newBannerImageUrl.trim(),
      title: newBannerTitle.trim() || undefined,
      linkUrl: newBannerLinkUrl.trim() || undefined,
      active: true,
      created_at: new Date().toISOString()
    };

    const updated = [newBanner, ...banners];
    savePromoBanners(updated);
    setBanners(updated);

    setNewBannerTitle('');
    setNewBannerImageUrl('');
    setNewBannerLinkUrl('');
    alert('🎉 Promo Banner successfully published and live!');
  };

  const handleToggleBanner = (id: string) => {
    const updated = banners.map(b => b.id === id ? { ...b, active: !b.active } : b);
    savePromoBanners(updated);
    setBanners(updated);
  };

  const handleDeleteBanner = (id: string) => {
    const target = banners.find(b => b.id === id);
    if (!target) return;
    setDeleteBannerConfirmation({
      show: true,
      bannerId: id,
      bannerTitle: target.title || 'Promo Banner'
    });
  };

  const handleConfirmDeleteBanner = () => {
    if (!deleteBannerConfirmation) return;
    const id = deleteBannerConfirmation.bannerId;
    const updated = banners.filter(b => b.id !== id);
    savePromoBanners(updated);
    setBanners(updated);
    setDeleteBannerConfirmation(null);
  };

  const handleCancelDeleteBanner = () => {
    setDeleteBannerConfirmation(null);
  };

  const handleBannerImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsCompressingBanner(true);
    const reader = new FileReader();
    reader.onload = async (event) => {
      const base64 = event.target?.result as string;
      try {
        const compressed = await compressImage(base64, 800, 400, 0.7);
        setNewBannerImageUrl(compressed);
      } catch (err) {
        console.error('Failed compressing banner:', err);
        setNewBannerImageUrl(base64);
      } finally {
        setIsCompressingBanner(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const handlePaymentQrUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsCompressingPaymentQr(true);
    const reader = new FileReader();
    reader.onload = async (event) => {
      const base64 = event.target?.result as string;
      try {
        const compressed = await compressImage(base64, 400, 400, 0.85);
        setAdminQrCodeUrl(compressed);
      } catch (err) {
        console.error('Failed compressing payment QR:', err);
        setAdminQrCodeUrl(base64);
      } finally {
        setIsCompressingPaymentQr(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSavePaymentSettings = (e: React.FormEvent) => {
    e.preventDefault();
    const currentSettings = getAdminPaymentSettings();
    saveAdminPaymentSettings({
      upiId: adminUpiId,
      qrCodeUrl: adminQrCodeUrl,
      whatsappGroupUrl: currentSettings.whatsappGroupUrl || ''
    });
    setPaymentSettingsSavedMsg(true);
    setTimeout(() => {
      setPaymentSettingsSavedMsg(false);
    }, 3000);
  };

  const handleSaveWhatsAppLink = (e: React.FormEvent) => {
    e.preventDefault();
    const currentSettings = getAdminPaymentSettings();
    saveAdminPaymentSettings({
      upiId: currentSettings.upiId,
      qrCodeUrl: currentSettings.qrCodeUrl,
      whatsappGroupUrl: whatsappGroupUrl.trim()
    });
    setWhatsappGroupUrlSaved(true);
    setTimeout(() => {
      setWhatsappGroupUrlSaved(false);
    }, 3000);
  };

  return (
    <div className="max-w-md mx-auto p-4 space-y-5 animate-fade-in text-white pb-28">
      {/* Back button */}
      <button
        onClick={onBackToDashboard}
        className="flex items-center gap-2 text-xs font-mono text-gray-400 hover:text-white transition-colors cursor-pointer mr-auto"
      >
        <ArrowLeft className="w-4 h-4 text-[#00FFCC]" />
        <span>Exit Master Console Desk</span>
      </button>

      {/* Primary title branding */}
      <div>
        <span className="text-[10px] font-mono text-[#00FFCC] font-bold tracking-widest block uppercase">
          ⚔️ VALENT CORE SYSTEM OVERRIDE
        </span>
        <h1 className="text-xl font-display font-black text-white tracking-tight uppercase flex items-center gap-2">
          <span>VALENT Management Engine</span>
          <Settings className="w-5 h-5 text-[#00FFCC] animate-spin-slow" />
        </h1>
      </div>

      {/* Player Participation Statistics Dashboard */}
      <div className="grid grid-cols-2 gap-3.5 bg-[#111625] border border-[#222D4A]/80 p-4 rounded-2xl shadow-xl relative overflow-hidden text-left">
        <div className="absolute -top-10 -right-10 w-24 h-24 bg-[#00FFCC]/5 rounded-full blur-xl pointer-events-none" />
        <div>
          <span className="text-[9px] font-mono text-gray-400 block uppercase tracking-wider font-extrabold">Total Players Joined</span>
          <span className="text-lg font-display font-black text-orange-500 tracking-tight block mt-1">
            {matches.reduce((acc, m) => acc + (m.players?.length || 0), 0)} Players
          </span>
          <span className="text-[8.5px] font-mono text-gray-500 block mt-0.5">Across all tournament lobbies</span>
        </div>
        <div className="border-l border-[#222D4A]/60 pl-3.5">
          <span className="text-[9px] font-mono text-gray-400 block uppercase tracking-wider font-extrabold">Total Registries</span>
          <span className="text-lg font-display font-black text-[#00FFCC] tracking-tight block mt-1">
            {users.length} Users
          </span>
          <span className="text-[8.5px] font-mono text-gray-500 block mt-0.5">Accounts in database ledger</span>
        </div>
      </div>

      {/* Tab Selectors */}
      <div className={`grid gap-1 bg-[#13192B] p-1 rounded-xl border border-[#222D4A]/60 ${
        userRole === 'admin' 
          ? 'grid-cols-4 xs:grid-cols-4 sm:grid-cols-7' 
          : 'grid-cols-2'
      }`}>
        {canAccessTab('matches') && (
          <button
            onClick={() => { setActiveTab('matches'); setDisputeMatchId(null); setBroadcastingMatchId(null); }}
            className={`py-2 rounded-lg text-[8.5px] font-mono font-bold uppercase transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'matches' ? 'bg-[#FF4500] text-white shadow' : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            Lobbies
          </button>
        )}
        {canAccessTab('rooms') && (
          <button
            onClick={() => { setActiveTab('rooms'); setDisputeMatchId(null); setBroadcastingMatchId(null); }}
            className={`py-2 rounded-lg text-[8.5px] font-mono font-bold uppercase transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'rooms' ? 'bg-[#FF4500] text-white shadow' : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            Rooms
          </button>
        )}
        {canAccessTab('financials') && (
          <button
            onClick={() => { setActiveTab('financials'); setDisputeMatchId(null); setBroadcastingMatchId(null); }}
            className={`py-2 rounded-lg text-[8.5px] font-mono font-bold uppercase transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'financials' ? 'bg-[#FF4500] text-white shadow' : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            Payouts
          </button>
        )}
        {canAccessTab('requests') && (
          <button
            onClick={() => { setActiveTab('requests'); setDisputeMatchId(null); setBroadcastingMatchId(null); }}
            className={`py-2 rounded-lg text-[8.5px] font-mono font-bold uppercase transition-all whitespace-nowrap cursor-pointer relative ${
              activeTab === 'requests' ? 'bg-[#FF4500] text-white shadow' : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            Requests
            {transactions.some(t => t.status === 'pending') && (
              <span className="absolute top-1 right-1 w-1.5 h-1.5 bg-[#00FFCC] rounded-full animate-pulse" />
            )}
          </button>
        )}
        {canAccessTab('banners') && (
          <button
            onClick={() => { setActiveTab('banners'); setDisputeMatchId(null); setBroadcastingMatchId(null); }}
            className={`py-2 rounded-lg text-[8.5px] font-mono font-bold uppercase transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'banners' ? 'bg-[#FF4500] text-white shadow' : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            Banners
          </button>
        )}
        {canAccessTab('rules') && (
          <button
            onClick={() => { setActiveTab('rules'); setDisputeMatchId(null); setBroadcastingMatchId(null); }}
            className={`py-2 rounded-lg text-[8.5px] font-mono font-bold uppercase transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'rules' ? 'bg-[#FF4500] text-white shadow' : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            Rules
          </button>
        )}
        {canAccessTab('support') && (
          <button
            onClick={() => { setActiveTab('support'); setDisputeMatchId(null); setBroadcastingMatchId(null); }}
            className={`py-2 rounded-lg text-[8.5px] font-mono font-bold uppercase transition-all whitespace-nowrap cursor-pointer relative ${
              activeTab === 'support' ? 'bg-[#FF4500] text-white shadow' : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            Support
            {supportMessages.some(m => m.senderId !== 'admin' && !m.readByAdmin) && (
              <span className="absolute top-1 right-1 w-1.5 h-1.5 bg-[#00FFCC] rounded-full animate-pulse" />
            )}
          </button>
        )}
      </div>

      {statusMsg && (
        <div className="bg-emerald-950/20 border border-emerald-500/40 p-3.5 rounded-xl text-center text-xs text-emerald-400">
          {statusMsg}
        </div>
      )}

      {/* Tab Content 1: Create Match & Manage Rooms List */}
      {activeTab === 'matches' && (
        <div className="space-y-4">
          <form onSubmit={handleCreateMatch} className="bg-[#13192B] border border-[#222D4A] rounded-2.5xl p-5 space-y-4 shadow-xl text-left">
            <h3 className="font-display font-black text-xs uppercase text-[#00FFCC] flex items-center gap-1.5">
              <Plus className="w-4 h-4" />
              <span>Publish Match Lobby</span>
            </h3>

            <div className="space-y-1.5">
              <label className="text-[9px] font-mono text-gray-400 uppercase font-black">Lobby title name</label>
              <input
                type="text"
                placeholder="e.g. Clash Squad Grand Arena"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                className="w-full bg-[#0A0E17] border border-[#222D4A] rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-[#FF4500] placeholder-gray-650"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5 font-sans">
                <label className="text-[9px] font-mono text-gray-400 uppercase font-black">Format Team Size</label>
                <select
                  value={newFormat}
                  onChange={(e) => setNewFormat(e.target.value as MatchFormat)}
                  className="w-full bg-[#0A0E17] border border-[#222D4A] rounded-xl px-2 py-2 text-xs font-mono text-white focus:outline-none focus:border-[#FF4500] cursor-pointer"
                >
                  <option value="4v4">4 vs 4 (8 slots) - Random</option>
                  <option value="6v6">6 vs 6 (12 slots) - Random</option>
                  <option value="teamvsteam4v4">Team vs Team 4v4 (8 slots)</option>
                  <option value="teamvsteam6v6">Team vs Team 6v6 (12 slots)</option>
                  <option value="BR">Custom BR Rooms</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-[9px] font-mono text-gray-400 uppercase font-black">Map Arena name</label>
                <select
                  value={newMap}
                  onChange={(e) => setNewMap(e.target.value)}
                  className="w-full bg-[#0A0E17] border border-[#222D4A] rounded-xl px-2 py-2 text-xs font-mono text-white focus:outline-none focus:border-[#FF4500] cursor-pointer"
                >
                  <option value="Bermuda (Hangar)">Bermuda (Hangar)</option>
                  <option value="Bermuda (Factory)">Bermuda (Factory)</option>
                  <option value="Kalahari (Duo)">Kalahari</option>
                  <option value="Purgatory (BR Map)">Purgatory Map</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <label className="text-[9px] font-mono text-gray-400 uppercase font-black">Entry Fee per slot (₹)</label>
                <input
                  type="number"
                  min="0"
                  value={newEntryFee}
                  onChange={(e) => setNewEntryFee(Number(e.target.value))}
                  className="w-full bg-[#0A0E17] border border-[#222D4A] rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-[#FF4500]"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[9px] font-mono text-gray-400 uppercase font-black">Winner Prize Pool (₹)</label>
                <input
                  type="number"
                  min="0"
                  value={newPrizePool}
                  onChange={(e) => setNewPrizePool(Number(e.target.value))}
                  className="w-full bg-[#0A0E17] border border-[#222D4A] rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-[#FF4500]"
                />
              </div>
            </div>

            <div className="space-y-1.5 bg-[#0A0E17] border border-[#222D4A] p-3 rounded-xl text-left">
              <label className="text-[9px] font-mono text-[#00FFCC] uppercase font-black block">Winning Prize Per Player (₹) – Optional</label>
              <input
                type="number"
                min="0"
                placeholder="e.g. 50 (Custom prize per winning team player)"
                value={newPrizePerPlayer || ''}
                onChange={(e) => setNewPrizePerPlayer(Number(e.target.value))}
                className="w-full bg-[#13192B] border border-[#222D4A] rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-[#00FFCC] placeholder-gray-650"
              />
              <p className="text-[8px] text-gray-500 font-mono leading-tight">
                For 4v4, 6v6, and Team vs Team matches: defines the guaranteed cash prize (₹) distributed instantly to EACH individually winning member. Shows up clearly on the match lobby card!
              </p>
            </div>

            <div className="bg-[#0A0E17] rounded-xl p-3 border border-[#222D4A] space-y-3">
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="per-kill-toggle"
                  checked={perKillEnabled}
                  onChange={(e) => setPerKillEnabled(e.target.checked)}
                  className="w-4 h-4 rounded border-[#222D4A] bg-[#13192B] text-[#FF4500] focus:ring-0 focus:ring-offset-0 cursor-pointer accent-[#FF4500]"
                />
                <label htmlFor="per-kill-toggle" className="text-[10px] font-mono text-gray-300 uppercase font-bold cursor-pointer select-none">
                  Enable Per-Kill Bounty Reward
                </label>
              </div>

              {perKillEnabled && (
                <div className="space-y-1.5 animate-fade-in">
                  <label className="text-[9px] font-mono text-gray-400 uppercase font-black block">Per-Kill Bounty Amount (₹)</label>
                  <input
                    type="number"
                    min="0"
                    value={perKillAmount}
                    onChange={(e) => setPerKillAmount(Number(e.target.value))}
                    className="w-full bg-[#0A0E17] border border-[#222D4A] rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-[#FF4500]"
                  />
                </div>
              )}
            </div>

            {/* Live Collection Simulator Card */}
            <div className="bg-[#0A0E17] rounded-xl p-3 border border-[#222D4A] text-xs font-mono space-y-1.5">
              <div className="flex justify-between">
                <span className="text-gray-500 uppercase text-[9px]">Lobby Capacity:</span>
                <span className="text-gray-300 font-extrabold">{calculatedStats.slots} slots</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500 uppercase text-[9px]">Gross Collection Pool:</span>
                <span className="text-yellow-500 font-extrabold">₹{calculatedStats.totalCollection}</span>
              </div>
              <div className="flex justify-between border-t border-[#222D4A]/50 pt-1.5">
                <span className="text-gray-500 uppercase text-[9px] text-orange-400">Winner Prize Pool (Manual):</span>
                <span className="text-orange-400 font-black">₹{newPrizePool}</span>
              </div>
              {perKillEnabled && (
                <div className="flex justify-between border-t border-[#222D4A]/50 pt-1.5">
                  <span className="text-gray-550 uppercase text-[9px] text-[#00FFCC]">With Per-Kill Reward:</span>
                  <span className="text-[#00FFCC] font-bold">₹{perKillAmount} / Kill</span>
                </div>
              )}
            </div>

            <button
              type="submit"
              className="w-full bg-gradient-to-r from-[#FF4500] to-[#C60000] text-white font-display font-black text-xs uppercase tracking-wider py-3.5 rounded-xl cursor-pointer"
            >
              Broadcast Esports Lobby
            </button>
          </form>

          {/* Lobbies List */}
          <div className="space-y-3 pt-2">
            <h3 className="text-xs font-mono text-gray-450 uppercase pl-1 font-bold">Active published lobbies ({matches.length})</h3>
            
            {matches.map(m => (
              <div key={m.id} className="bg-[#13192B] border border-[#222D4A] rounded-xl p-4 flex items-center justify-between text-left">
                <div>
                  <h4 className="font-mono text-xs font-black text-white">{m.title}</h4>
                  <span className="text-[9px] font-mono text-gray-500 uppercase block mt-1">
                    Entry: ₹{m.entryFee} • Prize: ₹{m.prizePool} • Model: {m.format_type}{m.perKillEnabled && m.perKillAmount ? ` • Per Kill: ₹${m.perKillAmount}` : ''}
                  </span>
                  <span className="text-[8px] font-mono block mt-0.5 text-gray-400">
                    Status: <span className="font-black text-orange-400">{m.status}</span>
                  </span>
                </div>

                <div className="flex gap-1.5">
                  <button
                    onClick={() => handleDeleteMatch(m.id)}
                    className="p-1.5 bg-red-950/20 text-red-500 rounded border border-red-900/40 hover:bg-red-900/30 transition-all cursor-pointer"
                  >
                    <Trash className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab Content 2: Credentials Distributor */}
      {activeTab === 'rooms' && (
        <div className="space-y-4">
          <div className="bg-[#13192B]/50 p-4 rounded-xl border border-[#222D4A] space-y-1 leading-relaxed">
            <h3 className="font-display font-bold text-xs uppercase text-gray-200">Custom Room Distributor</h3>
            <p className="text-[10px] text-gray-400">
              Dispatched Custom Room parameters automatically trigger the status migration to <span className="text-[#00FFCC] font-bold">ROOM_READY</span>, releasing the lock on the player screens instantly.
            </p>
          </div>

          <div className="space-y-3">
            {matches.filter(m => m.status !== 'COMPLETED').map(m => (
              <div key={m.id} className="bg-[#13192B] border border-[#222D4A] rounded-xl p-4 space-y-3 text-left">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-mono text-xs font-extrabold text-white uppercase">{m.title}</h4>
                    <span className="text-[8px] font-mono text-gray-400 block uppercase mt-0.5">
                      Type: {m.format_type} • Spots: {m.spotsFilled}/{m.spotsTotal} Filled
                    </span>
                  </div>
                  {m.roomId ? (
                    <span className="text-[8px] bg-emerald-950 text-[#00FFCC] font-mono border border-emerald-900 px-1.5 py-0.5 rounded uppercase font-bold">
                      ID: {m.roomId}
                    </span>
                  ) : (
                    <span className="text-[8px] bg-orange-950 text-orange-400 font-mono border border-orange-900 px-1.5 py-0.5 rounded uppercase font-bold">
                      Unassigned
                    </span>
                  )}
                </div>

                {/* Dynamic Timing Indicators */}
                {(m.credentialsRevealTime || m.matchStartTime) && (
                  <div className="bg-[#0A0E17]/80 rounded-xl p-2 border border-[#222D4A]/65 text-[9px] font-mono space-y-1 text-gray-400">
                    {m.credentialsRevealTime && (
                      <div className="flex justify-between">
                        <span>🔑 CREDENTIALS REVEAL CUTOFF:</span>
                        <span className="font-bold text-amber-400">{new Date(m.credentialsRevealTime).toLocaleTimeString()}</span>
                      </div>
                    )}
                    {m.matchStartTime && (
                      <div className="flex justify-between">
                        <span>⚔️ TACTICAL MATCH COMMENCEMENT:</span>
                        <span className="font-bold text-[#00FFCC]">{new Date(m.matchStartTime).toLocaleTimeString()}</span>
                      </div>
                    )}
                  </div>
                )}

                {/* Tactical Tools selection buttons */}
                <div className="grid grid-cols-4 gap-1.5 pt-1">
                  <button
                    onClick={() => {
                      if (editingMatchLineupId === m.id) {
                        setEditingMatchLineupId(null);
                      } else {
                        setEditingMatchLineupId(m.id);
                        setEditingLineupPlayers([...m.players]);
                        setEditingMatchTimingId(null);
                        setBroadcastingMatchId(null);
                      }
                    }}
                    className={`py-1.5 px-2 rounded-lg text-[9px] font-mono uppercase font-black tracking-wider transition-all cursor-pointer border ${
                      editingMatchLineupId === m.id
                        ? 'bg-[#FF4500] text-white border-[#FF4500]'
                        : 'bg-[#0A0E17] text-gray-300 border-[#222D4A] hover:border-orange-500/50'
                    }`}
                  >
                    👥 Lineup
                  </button>

                  <button
                    onClick={() => {
                      if (editingMatchTimingId === m.id) {
                        setEditingMatchTimingId(null);
                      } else {
                        setEditingMatchTimingId(m.id);
                        setRevealInMins(2);
                        setStartInMins(5);
                        setEditingMatchLineupId(null);
                        setBroadcastingMatchId(null);
                      }
                    }}
                    className={`py-1.5 px-2 rounded-lg text-[9px] font-mono uppercase font-black tracking-wider transition-all cursor-pointer border ${
                      editingMatchTimingId === m.id
                        ? 'bg-[#FF4500] text-white border-[#FF4500]'
                        : 'bg-[#0A0E17] text-gray-300 border-[#222D4A] hover:border-orange-500/50'
                    }`}
                  >
                    ⏱️ Timers
                  </button>

                  <button
                    onClick={() => {
                      if (broadcastingMatchId === m.id) {
                        setBroadcastingMatchId(null);
                      } else {
                        setBroadcastingMatchId(m.id);
                        setBroadcastRoomId(m.roomId || '');
                        setBroadcastPassword(m.roomPassword || '');
                        setBroadcastReleaseMode(m.credentialsRevealTime ? 'scheduled' : 'now');
                        setEditingMatchLineupId(null);
                        setEditingMatchTimingId(null);
                      }
                    }}
                    className={`py-1.5 px-2 rounded-lg text-[9px] font-mono uppercase font-black tracking-wider transition-all cursor-pointer border ${
                      broadcastingMatchId === m.id
                        ? 'bg-[#FF4500] text-white border-[#FF4500]'
                        : 'bg-[#0A0E17] text-gray-300 border-[#222D4A] hover:border-orange-500/50'
                    }`}
                  >
                    🔑 Set ID/PW
                  </button>

                  <button
                    onClick={() => handleForceLockAndLive(m.id)}
                    className="py-1.5 px-1 rounded-lg text-[9px] font-mono uppercase font-extrabold bg-red-950/20 text-red-500 border border-red-900/40 hover:bg-red-900/35 transition-all cursor-pointer"
                  >
                    🔒 LOCK LIVE
                  </button>
                </div>

                {/* Sub-Panel 1: Edit Grid Player Lineups */}
                {editingMatchLineupId === m.id && (
                  <div className="bg-[#0A0E17] border border-[#222D4A] rounded-xl p-3 space-y-3.5 animate-fade-in">
                    <div className="flex justify-between items-center border-b border-[#222D4A]/60 pb-1.5">
                      <span className="text-[10px] font-mono font-black text-orange-400 uppercase">👥 GRID LINEUP COORDINATION</span>
                      <span className="text-[8px] font-mono text-gray-500 uppercase">{m.format_type} FORMAT CAPACITY</span>
                    </div>

                    {editingLineupPlayers.length === 0 ? (
                      <span className="text-[9px] font-mono text-gray-550 block text-center py-6">No players have registered for this lobby yet.</span>
                    ) : (
                      <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                        {editingLineupPlayers.map((player, index) => {
                          const maxPosition = m.format_type === '1v1' ? 1 : m.format_type === '2v2' ? 2 : (m.format_type === '4v4' || m.format_type === 'teamvsteam4v4') ? 4 : (m.format_type === '6v6' || m.format_type === 'teamvsteam6v6') ? 6 : 24;
                          return (
                            <div key={index} className="bg-[#13192B]/85 border border-[#222D4A]/50 p-2 rounded-lg flex items-center justify-between text-xs gap-3">
                              <div className="min-w-0 flex-1">
                                <span className="text-[10.5px] font-mono font-black text-[#00FFCC] block truncate">{player.ign || '@' + player.username}</span>
                                <span className="text-[8px] font-mono text-gray-500 block leading-tight">@{player.username}</span>
                              </div>

                              <div className="flex gap-2 shrink-0">
                                {/* Team Allocation Dropdown */}
                                <div className="space-y-0.5">
                                  <label className="text-[7.5px] font-mono text-gray-500 uppercase block leading-none">TEAM</label>
                                  <select
                                    value={player.team}
                                    onChange={(e) => {
                                      const next = [...editingLineupPlayers];
                                      next[index] = { ...next[index], team: e.target.value as 'A' | 'B' };
                                      setEditingLineupPlayers(next);
                                    }}
                                    className="bg-[#0A0E17] border border-[#222D4A] rounded px-1 py-1 text-[9.5px] font-mono text-gray-300 focus:outline-none focus:border-orange-500"
                                  >
                                    <option value="A">Team A</option>
                                    <option value="B">Team B</option>
                                  </select>
                                </div>

                                {/* Position Allocation Dropdown */}
                                <div className="space-y-0.5">
                                  <label className="text-[7.5px] font-mono text-gray-500 uppercase block leading-none">GRID POSITION</label>
                                  <select
                                    value={player.position || 1}
                                    onChange={(e) => {
                                      const next = [...editingLineupPlayers];
                                      next[index] = { ...next[index], position: Number(e.target.value) };
                                      setEditingLineupPlayers(next);
                                    }}
                                    className="bg-[#0A0E17] border border-[#222D4A] rounded px-1 py-1 text-[9.5px] font-mono text-gray-300 focus:outline-none focus:border-orange-500"
                                  >
                                    {Array.from({ length: maxPosition }, (_, i) => i + 1).map(slotNum => (
                                      <option key={slotNum} value={slotNum}>Slot #{slotNum}</option>
                                    ))}
                                  </select>
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}

                    <div className="flex gap-2 justify-end border-t border-[#222D4A]/50 pt-2.5">
                      <button
                        onClick={() => setEditingMatchLineupId(null)}
                        className="px-3 py-1.5 text-[9px] font-mono bg-gray-900 border border-gray-750 text-gray-400 rounded-lg cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={() => handleSaveGridLineup(m.id)}
                        disabled={editingLineupPlayers.length === 0}
                        className="px-4 py-1.5 text-[9px] font-mono bg-[#FF4500] text-white rounded-lg font-bold hover:shadow-[0_0_10px_rgba(255,69,0,0.4)] disabled:opacity-50 cursor-pointer"
                      >
                        Save Grid Layout
                      </button>
                    </div>
                  </div>
                )}

                {/* Sub-Panel 2: Edit Custom Timers constraints */}
                {editingMatchTimingId === m.id && (
                  <div className="bg-[#0A0E17] border border-[#222D4A] rounded-xl p-3 space-y-3.5 animate-fade-in">
                    <span className="text-[10px] font-mono font-black text-orange-400 uppercase block border-b border-[#222D4A]/60 pb-1.5">⏱️ SCHEDULE MATCH COUNTDOWNS</span>
                    
                    <div className="grid grid-cols-2 gap-3 text-xs font-mono">
                      <div className="space-y-1">
                        <label className="text-[8px] font-mono text-gray-500 block uppercase">Reveal Credentials In</label>
                        <div className="flex items-center gap-1.5 bg-[#13192B]/85 border border-[#222D4A] px-2 rounded-lg">
                          <input
                            type="number"
                            min="1"
                            max="120"
                            value={revealInMins}
                            onChange={(e) => setRevealInMins(Number(e.target.value))}
                            className="bg-transparent py-1.5 text-xs text-white focus:outline-none w-full"
                          />
                          <span className="text-[9px] text-gray-500 uppercase">Mins</span>
                        </div>
                      </div>

                      <div className="space-y-1">
                        <label className="text-[8px] font-mono text-gray-500 block uppercase">Then Start Match In</label>
                        <div className="flex items-center gap-1.5 bg-[#13192B]/85 border border-[#222D4A] px-2 rounded-lg">
                          <input
                            type="number"
                            min="1"
                            max="120"
                            value={startInMins}
                            onChange={(e) => setStartInMins(Number(e.target.value))}
                            className="bg-transparent py-1.5 text-xs text-white focus:outline-none w-full"
                          />
                          <span className="text-[9px] text-gray-500 uppercase">Mins</span>
                        </div>
                      </div>
                    </div>

                    <p className="text-[8px] font-mono text-gray-500 leading-normal">
                      The countdown will tick down live on player contest cards. The combined starting timer integrates both the reveal countdown and startup minutes, informing players exactly when the battle officially begins!
                    </p>

                    <div className="flex gap-2 justify-end border-t border-[#222D4A]/50 pt-2.5">
                      <button
                        onClick={() => setEditingMatchTimingId(null)}
                        className="px-3 py-1.5 text-[9px] font-mono bg-gray-900 border border-gray-750 text-gray-400 rounded-lg cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={() => handleSaveMatchTimings(m.id)}
                        className="px-4 py-1.5 text-[9px] font-mono bg-[#FF4500] text-white rounded-lg font-bold hover:shadow-[0_0_10px_rgba(255,69,0,0.4)] cursor-pointer"
                      >
                        Apply Timers
                      </button>
                    </div>
                  </div>
                )}

                {/* Sub-Panel 3: Set ID & PW parameters (Credentials set) */}
                {broadcastingMatchId === m.id && (
                  <div className="p-3 bg-[#0A0E17] border border-[#222D4A] rounded-lg space-y-3.5 animate-fade-in text-left">
                    <span className="text-[10px] font-mono font-black text-orange-400 uppercase block border-b border-[#222D4A]/60 pb-1.5">🔑 DISPATCH ROOM CREDENTIALS ROOM_ID</span>
                    
                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-1">
                        <label className="text-[8px] font-mono text-gray-400 block uppercase">Room ID</label>
                        <input
                          type="text"
                          placeholder="e.g. 92104832"
                          value={broadcastRoomId}
                          onChange={(e) => setBroadcastRoomId(e.target.value)}
                          className="w-full bg-[#13192B]/85 border border-[#222D4A] rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-[#FF4500] font-mono"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[8px] font-mono text-gray-400 block uppercase">Password</label>
                        <input
                          type="text"
                          placeholder="e.g. ff920"
                          value={broadcastPassword}
                          onChange={(e) => setBroadcastPassword(e.target.value)}
                          className="w-full bg-[#13192B]/85 border border-[#222D4A] rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-[#FF4500] font-mono"
                        />
                      </div>
                    </div>

                    {/* Release Policy / Reveal option */}
                    <div className="space-y-1.5 pt-1.5 pb-0.5">
                      <span className="text-[8.5px] font-mono text-gray-400 block uppercase tracking-wider font-extrabold">Release & Reveal Policy</span>
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={() => setBroadcastReleaseMode('now')}
                          className={`px-3 py-2 rounded-lg border text-left flex flex-col gap-0.5 transition-all cursor-pointer ${
                            broadcastReleaseMode === 'now'
                              ? 'bg-orange-500/15 border-orange-500 text-orange-400 shadow-[0_0_8px_rgba(239,68,68,0.1)]'
                              : 'bg-[#13192B]/50 border-[#222D4A] text-gray-400 hover:border-gray-700'
                          }`}
                        >
                          <span className="text-[9.5px] font-mono font-black uppercase flex items-center gap-1">🚀 Broadcast Now</span>
                          <span className="text-[8px] font-sans leading-tight">Reveal parameters to players immediately</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setBroadcastReleaseMode('scheduled')}
                          className={`px-3 py-2 rounded-lg border text-left flex flex-col gap-0.5 transition-all cursor-pointer ${
                            broadcastReleaseMode === 'scheduled'
                              ? 'bg-orange-500/15 border-orange-500 text-orange-400 shadow-[0_0_8px_rgba(239,68,68,0.1)]'
                              : 'bg-[#13192B]/50 border-[#222D4A] text-gray-400 hover:border-gray-700'
                          }`}
                        >
                          <span className="text-[9.5px] font-mono font-black uppercase flex items-center gap-1">⏱️ At Timer End</span>
                          <span className="text-[8px] font-sans leading-tight">Reveal automatically when countdown ends</span>
                        </button>
                      </div>
                      {broadcastReleaseMode === 'scheduled' && m.credentialsRevealTime && (
                        <p className="text-[8.5px] font-mono text-amber-500 bg-amber-500/10 px-2.5 py-1.5 rounded-lg border border-amber-500/20 text-left">
                          ⏳ Timer ends at: <strong>{new Date(m.credentialsRevealTime).toLocaleTimeString()}</strong> ({Math.max(0, Math.round((new Date(m.credentialsRevealTime).getTime() - Date.now()) / 60000))} mins left)
                        </p>
                      )}
                    </div>

                    <div className="flex gap-2 justify-end border-t border-[#222D4A]/50 pt-2.5">
                      <button
                        onClick={() => setBroadcastingMatchId(null)}
                        className="px-2.5 py-1.5 text-[9px] font-mono bg-[#13192B] border border-gray-750 text-gray-400 rounded-lg cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={() => handleBroadcastRoom(m.id)}
                        className="px-3.5 py-1.5 text-[9px] font-mono bg-[#FF4500] text-white rounded-lg font-bold cursor-pointer font-black hover:shadow-[0_0_10px_rgba(255,69,0,0.4)] transition-all"
                      >
                        Save & Dispatch
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ))}

            {matches.filter(m => m.status !== 'COMPLETED').length === 0 && (
              <span className="text-xs font-mono text-gray-500 block pt-16 text-center">No active matches needing coordinates.</span>
            )}
          </div>
        </div>
      )}



      {/* Tab Content 4: Financial Audit Desk */}
      {activeTab === 'financials' && (
        <div className="space-y-4 animate-fade-in">
          {/* Official QR & UPI System configuration */}
          <form onSubmit={handleSavePaymentSettings} className="bg-[#13192B] border border-amber-500/35 rounded-2.5xl p-5 space-y-4 shadow-xl text-left relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/5 rounded-full blur-2xl pointer-events-none" />
            <div className="absolute top-0 left-0 w-full h-[2px] bg-gradient-to-r from-amber-500 to-orange-500" />
            
            <div className="flex items-center gap-2">
              <div className="p-2 bg-amber-500/10 border border-amber-500/25 rounded-xl text-amber-500">
                <QrCode className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-display font-black text-xs uppercase text-white tracking-wider">
                  Official Merchant QR & UPI Settings
                </h3>
                <p className="text-[9px] text-gray-400">Users scan this QR or copy this UPI to make direct deposit receipts.</p>
              </div>
            </div>

            <div className="space-y-4 pt-1">
              <div className="space-y-1.5">
                <label className="text-[9px] font-mono text-gray-400 uppercase font-black">Official Recipient UPI ID</label>
                <input
                  type="text"
                  placeholder="e.g. valent.pay@okaxis"
                  value={adminUpiId}
                  onChange={(e) => setAdminUpiId(e.target.value)}
                  className="w-full bg-[#0A0E17] border border-[#222D4A] rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-[#FF4500] placeholder-gray-650"
                />
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between items-center">
                  <label className="text-[9px] font-mono text-gray-400 uppercase font-black">Official Merchant Deposit QR Code</label>
                  <label className="text-[9px] font-mono text-amber-500 font-bold cursor-pointer hover:underline flex items-center gap-1">
                    <Upload className="w-3.5 h-3.5" />
                    <span>Upload QR from Gallery</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handlePaymentQrUpload}
                      className="hidden"
                    />
                  </label>
                </div>
                
                <input
                  type="text"
                  placeholder="Paste direct Image URL or base64 data"
                  value={adminQrCodeUrl}
                  onChange={(e) => setAdminQrCodeUrl(e.target.value)}
                  className="w-full bg-[#0A0E17] border border-[#222D4A] rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-[#FF4500] placeholder-gray-655"
                />
                
                {isCompressingPaymentQr && (
                  <span className="text-[9px] font-mono text-amber-400 animate-pulse block">⚡ Compressing scanner asset...</span>
                )}
                
                {adminQrCodeUrl && (
                  <div className="mt-2 p-2 bg-[#0A0E17] border border-[#222D4A] rounded-xl flex flex-col items-center justify-center">
                    <span className="text-[8px] font-mono text-gray-500 uppercase tracking-widest mb-1.5">LIVE PREVIEW SPECIMEN</span>
                    <img
                      src={adminQrCodeUrl}
                      alt="Deposit QR preview"
                      className="w-28 h-28 object-contain bg-white rounded-lg p-1.5 border border-gray-700"
                    />
                  </div>
                )}
              </div>

              <div className="flex justify-between items-center pt-2 border-t border-[#222D4A]/55">
                <span className="text-[9px] font-mono text-amber-500 font-bold">
                  {paymentSettingsSavedMsg ? "✨ SETTINGS COMMITTED TO CLOUD DATABASE!" : "🔄 Real-time system sync setup"}
                </span>
                <button
                  type="submit"
                  className="px-4 py-2 bg-gradient-to-r from-amber-600 to-orange-500 hover:from-amber-500 hover:to-orange-400 border border-amber-500 text-white rounded-xl text-[10px] font-mono uppercase font-black tracking-wider transition-all cursor-pointer shadow-[0_0_15px_rgba(245,158,11,0.15)]"
                >
                  Save Payment Settings
                </button>
              </div>
            </div>
          </form>

          {/* ⚡ MANUAL USER WALLET CREDIT & DEBIT SYSTEM */}
          <div className="bg-[#13192B] border border-blue-500/40 rounded-2.5xl p-6 space-y-5 shadow-2xl text-left relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute top-0 left-0 w-full h-[3px] bg-gradient-to-r from-blue-500 via-indigo-500 to-cyan-500 animate-pulse" />

            <div className="flex items-center gap-3">
              <div className="p-3 bg-blue-500/10 border border-blue-500/25 rounded-2xl text-blue-400 shrink-0">
                <Coins className="w-6 h-6 animate-pulse" />
              </div>
              <div>
                <h3 className="font-display font-black text-sm uppercase text-white tracking-widest">
                  ⚡ INSTANT WALLET CREDIT & DEBIT LEDGER
                </h3>
                <p className="text-xs text-gray-400 font-mono mt-0.5">Directly adjust and verify real-time user wallet balances with deep transactional compliance audit trail.</p>
              </div>
            </div>

            {/* Adjustment Operation Handlers Feedback notifications */}
            {adjSuccessFeedback && (
              <div className="bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 p-4 rounded-xl text-xs font-mono font-bold animate-fade-in leading-relaxed select-none">
                {adjSuccessFeedback}
              </div>
            )}
            {adjErrorFeedback && (
              <div className="bg-rose-950/45 border border-rose-500/40 text-rose-300 p-4 rounded-xl text-xs font-mono font-bold animate-fade-in leading-relaxed select-none">
                {adjErrorFeedback}
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-1">
              {/* Left Panel: Search & Select User */}
              <div className="space-y-4 bg-[#0A0E17]/65 p-4 rounded-2.5xl border border-[#222D4A]/70 flex flex-col justify-start">
                <div>
                  <label className="text-xs font-mono text-gray-300 uppercase font-black block mb-2 tracking-wider">
                    Step 1: Select Player Account
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      placeholder="Search player username, IGN or phone..."
                      value={userSearchQuery}
                      onChange={(e) => setUserSearchQuery(e.target.value)}
                      className="w-full bg-[#13192B] border border-[#222D4A] rounded-xl px-4 py-2.5 pl-10 text-xs font-mono text-white focus:outline-none focus:border-blue-500 placeholder-gray-600 transition-all font-bold"
                    />
                    <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 text-xs">🔍</div>
                  </div>
                </div>

                <div className="flex-1 max-h-56 overflow-y-auto space-y-2 pr-1 text-left">
                  {users
                    .filter(u => {
                      const query = userSearchQuery.toLowerCase();
                      return (
                        u.username.toLowerCase().includes(query) ||
                        (u.ign && u.ign.toLowerCase().includes(query)) ||
                        u.phone.includes(query)
                      );
                    })
                    .map(u => {
                      const isSelected = selectedAdjUserId === u.id;
                      return (
                        <div
                          key={u.id}
                          onClick={() => {
                            setSelectedAdjUserId(u.id);
                            setAdjSuccessFeedback(null);
                            setAdjErrorFeedback(null);
                          }}
                          className={`p-3 rounded-xl border text-left cursor-pointer transition-all flex items-center justify-between gap-2.5 ${
                            isSelected
                              ? 'bg-blue-950/20 border-blue-500 text-blue-300 shadow-[0_0_12px_rgba(59,130,246,0.18)]'
                              : 'bg-[#13192B]/50 border-[#222D4A]/50 text-gray-300 hover:border-gray-700'
                          }`}
                        >
                          <div className="min-w-0 pr-1 text-left">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="text-sm font-mono font-black truncate text-white">@{u.username}</span>
                              {u.role && u.role !== 'player' && (
                                <span className={`text-[7.5px] px-1.5 py-0.2 rounded font-mono font-bold uppercase tracking-wide shrink-0 ${
                                  u.role === 'admin' ? 'bg-red-500/10 text-red-400 border border-red-500/20' :
                                  u.role === 'wallet_manager' ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' :
                                  u.role === 'chat_manager' ? 'bg-teal-500/10 text-teal-400 border border-teal-500/20' :
                                  'bg-purple-500/10 text-purple-400 border border-purple-500/20'
                                }`}>
                                  {u.role.replace('_', ' ')}
                                </span>
                              )}
                            </div>
                            <span className="text-[10px] font-mono text-gray-400 block truncate uppercase tracking-widest mt-1">
                              {u.ign ? `IGN: ${u.ign}` : 'No Game ID Added'} • +91 {u.phone}
                            </span>
                          </div>
                          <div className="text-right shrink-0 font-mono text-[10px] bg-[#0A0E17]/90 border border-[#222D4A] rounded-lg p-2 min-w-[100px]">
                            <div className="text-gray-400 flex items-center justify-between gap-1">
                              <span>Deposits:</span>
                              <span className="text-white font-black">₹{u.wallet.deposit.toFixed(0)}</span>
                            </div>
                            <div className="text-gray-400 flex items-center justify-between gap-1 mt-1">
                              <span>Winnings:</span>
                              <span className="text-emerald-400 font-black">₹{u.wallet.winnings.toFixed(0)}</span>
                            </div>
                          </div>
                        </div>
                      );
                    })}

                  {users.filter(u => {
                    const query = userSearchQuery.toLowerCase();
                    return u.username.toLowerCase().includes(query) || (u.ign && u.ign.toLowerCase().includes(query)) || u.phone.includes(query);
                  }).length === 0 && (
                    <span className="text-xs font-mono text-gray-500 block text-center py-6">No users found</span>
                  )}
                </div>
              </div>

              {/* Right Panel: Adjustment Form */}
              <div className="bg-[#0A0E17]/65 p-4.5 rounded-2.5xl border border-[#222D4A]/70 flex flex-col justify-between min-h-[250px]">
                {selectedAdjUserId ? (
                  (() => {
                    const selectedUser = users.find(u => u.id === selectedAdjUserId);
                    if (!selectedUser) return null;
                    return (
                      <div className="w-full space-y-4">
                        <form onSubmit={handleManualWalletAdjustment} className="space-y-4 text-left w-full">
                        <div className="bg-blue-500/10 px-3 py-3 border border-blue-500/20 rounded-xl mb-1 space-y-3">
                          <div className="flex items-center justify-between">
                            <div className="min-w-0">
                              <span className="text-[9px] font-mono text-blue-400 uppercase font-black block tracking-widest leading-none mb-1">SELECTED PLAYER</span>
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="text-sm font-mono font-black text-white truncate">@{selectedUser.username}</span>
                                {selectedUser.role && selectedUser.role !== 'player' && (
                                  <span className="text-[7.5px] bg-[#FF4500]/15 text-[#FF4500] border border-[#FF4500]/30 px-1.5 py-0.5 rounded font-mono font-bold uppercase shrink-0">
                                    {selectedUser.role.replace('_', ' ')}
                                  </span>
                                )}
                              </div>
                            </div>
                            <button
                              type="button"
                              onClick={() => {
                                setSelectedAdjUserId('');
                                setAdjSuccessFeedback(null);
                                setAdjErrorFeedback(null);
                              }}
                              className="bg-[#13192B] px-2.5 py-1 rounded border border-[#222D4A] hover:text-white text-xs font-mono font-bold text-gray-400 hover:border-gray-600 transition-colors cursor-pointer"
                            >
                              ✕ Clear
                            </button>
                          </div>

                          <div className="pt-2 border-t border-[#222D4A]/55">
                            <span className="text-[8.5px] font-mono text-blue-400 uppercase font-black block tracking-widest mb-1.5">👥 PROMOTE STATUS / ACCESS ROLE:</span>
                            <div className="grid grid-cols-2 xs:grid-cols-5 gap-1 shadow-inner bg-black/45 p-1 rounded-xl border border-[#222D4A]/40">
                              {[
                                { key: 'player', label: 'Player' },
                                { key: 'admin', label: 'Admin' },
                                { key: 'wallet_manager', label: 'Wallet Mgr' },
                                { key: 'chat_manager', label: 'Chat Mgr' },
                                { key: 'rules_manager', label: 'Rules Mgr' }
                              ].map((roleOpt) => {
                                const isCurrent = selectedUser.role === roleOpt.key || (!selectedUser.role && roleOpt.key === 'player');
                                return (
                                  <button
                                    key={roleOpt.key}
                                    type="button"
                                    onClick={() => {
                                      const allUsers = getUsers();
                                      const idx = allUsers.findIndex(u => u.id === selectedUser.id);
                                      if (idx !== -1) {
                                        const r = roleOpt.key as any;
                                        allUsers[idx].role = r;
                                        allUsers[idx].is_admin = r !== 'player';
                                        saveUsers(allUsers);
                                        setUsers(allUsers);
                                        setAdjSuccessFeedback(`⭐ Promoted @${selectedUser.username} to ${roleOpt.label.toUpperCase()} successfully.`);
                                      }
                                    }}
                                    className={`py-1 rounded px-0.5 text-[8.5px] font-mono uppercase text-center transition-all cursor-pointer whitespace-nowrap min-w-0 ${
                                      isCurrent
                                        ? 'bg-[#FF4500] text-white font-extrabold shadow-sm'
                                        : 'text-gray-450 hover:text-white hover:bg-[#13192B]/50'
                                    }`}
                                  >
                                    {roleOpt.label}
                                  </button>
                                );
                              })}
                            </div>
                          </div>
                        </div>

                        {/* Adjust type */}
                        <div className="space-y-1.5">
                          <label className="text-xs font-mono text-gray-300 uppercase font-black block">Step 2: Command Action</label>
                          <div className="grid grid-cols-2 gap-3">
                            <button
                              type="button"
                              onClick={() => {
                                setAdjType('credit');
                                setAdjSuccessFeedback(null);
                                setAdjErrorFeedback(null);
                              }}
                              className={`py-2 rounded-xl border text-xs font-mono font-black uppercase transition-all tracking-wider ${
                                adjType === 'credit'
                                  ? 'bg-emerald-950/20 border-emerald-500 text-emerald-400 font-extrabold shadow-[0_0_10px_rgba(16,185,129,0.2)]'
                                  : 'bg-[#13192B]/50 border-transparent text-gray-400 hover:text-white'
                              }`}
                            >
                              ➕ Credit Funds
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setAdjType('debit');
                                setAdjSuccessFeedback(null);
                                setAdjErrorFeedback(null);
                              }}
                              className={`py-2 rounded-xl border text-xs font-mono font-black uppercase transition-all tracking-wider ${
                                adjType === 'debit'
                                  ? 'bg-rose-950/20 border-rose-500 text-rose-400 font-extrabold shadow-[0_0_10px_rgba(244,63,94,0.2)]'
                                  : 'bg-[#13192B]/50 border-transparent text-gray-400 hover:text-white'
                              }`}
                            >
                              ➖ Deduct Funds
                            </button>
                          </div>
                        </div>

                        {/* Destination Wallet Pool */}
                        <div className="space-y-1.5">
                          <label className="text-xs font-mono text-gray-300 uppercase font-black block">Step 3: Target Wallet Pool</label>
                          <div className="grid grid-cols-2 gap-3">
                            <button
                              type="button"
                              onClick={() => {
                                setAdjWalletPool('deposit');
                                setAdjSuccessFeedback(null);
                                setAdjErrorFeedback(null);
                              }}
                              className={`py-2 rounded-xl border text-xs font-mono font-bold uppercase transition-all tracking-wide ${
                                adjWalletPool === 'deposit'
                                  ? 'bg-[#13192B] border-blue-500 text-blue-300 font-black'
                                  : 'bg-[#13192B]/50 border-transparent text-gray-400 hover:text-white'
                              }`}
                            >
                              Deposit (₹{selectedUser.wallet.deposit.toFixed(2)})
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setAdjWalletPool('winnings');
                                setAdjSuccessFeedback(null);
                                setAdjErrorFeedback(null);
                              }}
                              className={`py-2 rounded-xl border text-xs font-mono font-bold uppercase transition-all tracking-wide ${
                                adjWalletPool === 'winnings'
                                  ? 'bg-[#13192B] border-emerald-500 text-emerald-300 font-black'
                                  : 'bg-[#13192B]/50 border-transparent text-gray-400 hover:text-white'
                              }`}
                            >
                              Winnings (₹{selectedUser.wallet.winnings.toFixed(2)})
                            </button>
                          </div>
                        </div>

                        {/* Amount & Reason */}
                        <div className="grid grid-cols-3 gap-3">
                          <div className="col-span-1 space-y-1.5">
                            <label className="text-xs font-mono text-gray-300 uppercase font-black block">Amount (₹)</label>
                            <input
                              type="number"
                              required
                              placeholder="500"
                              value={adjAmount}
                              onChange={(e) => setAdjAmount(e.target.value)}
                              className="w-full bg-[#13192B] border border-[#222D4A] rounded-xl px-3 py-2 text-xs font-mono text-white text-center focus:outline-none focus:border-blue-500 font-black"
                            />
                          </div>
                          <div className="col-span-2 space-y-1.5 text-left">
                            <label className="text-xs font-mono text-gray-300 uppercase font-black block">Reason Log / Audit Note</label>
                            <input
                              type="text"
                              placeholder="Reason / Correction comment"
                              value={adjNote}
                              onChange={(e) => setAdjNote(e.target.value)}
                              className="w-full bg-[#13192B] border border-[#222D4A] rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-blue-500 placeholder-gray-600 font-bold"
                            />
                          </div>
                        </div>

                        <button
                          type="submit"
                          className="w-full py-3 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white rounded-xl font-display font-black text-xs uppercase tracking-widest transition-all cursor-pointer shadow-[0_0_20px_rgba(59,130,246,0.3)] mt-2"
                        >
                          Execute Wallet Adjustment
                        </button>
                      </form>

                      {/* 🛡️ Direct Promotion & Privileges Section */}
                      {currentUser?.role === 'admin' && (
                        <div className="mt-5 pt-4 border-t border-[#222D4A]/55 space-y-2.5">
                          <label className="text-xs font-mono text-gray-350 uppercase font-black block text-left">🛡️ Role Promotion & Privileges</label>
                          <div className="grid grid-cols-4 gap-1.5 bg-black/30 p-1 rounded-xl border border-[#222D4A]/40">
                            <button
                              type="button"
                              onClick={() => handlePromoteUser(selectedUser.id, 'player')}
                              className={`py-1.5 rounded-lg text-[8px] font-mono font-bold uppercase transition-all truncate cursor-pointer ${
                                selectedUser.role === 'player' || !selectedUser.role
                                  ? 'bg-blue-600 text-white font-black hover:bg-blue-500'
                                  : 'text-gray-400 hover:text-white hover:bg-[#13192B]/40'
                              }`}
                            >
                              Player
                            </button>
                            <button
                              type="button"
                              onClick={() => handlePromoteUser(selectedUser.id, 'wallet_manager')}
                              className={`py-1.5 rounded-lg text-[8px] font-mono font-bold uppercase transition-all truncate cursor-pointer ${
                                selectedUser.role === 'wallet_manager'
                                  ? 'bg-emerald-600 text-white font-black hover:bg-emerald-500'
                                  : 'text-gray-400 hover:text-white hover:bg-[#13192B]/40'
                              }`}
                            >
                              Wallet Mgr
                            </button>
                            <button
                              type="button"
                              onClick={() => handlePromoteUser(selectedUser.id, 'chat_manager')}
                              className={`py-1.5 rounded-lg text-[8px] font-mono font-bold uppercase transition-all truncate cursor-pointer ${
                                selectedUser.role === 'chat_manager'
                                  ? 'bg-purple-600 text-white font-black hover:bg-purple-500'
                                  : 'text-gray-400 hover:text-white hover:bg-[#13192B]/40'
                              }`}
                            >
                              Chat Mgr
                            </button>
                            <button
                              type="button"
                              onClick={() => handlePromoteUser(selectedUser.id, 'admin')}
                              className={`py-1.5 rounded-lg text-[8px] font-mono font-bold uppercase transition-all truncate cursor-pointer ${
                                selectedUser.role === 'admin'
                                  ? 'bg-rose-600 text-white font-black hover:bg-rose-500'
                                  : 'text-gray-400 hover:text-white hover:bg-[#13192B]/40'
                              }`}
                            >
                              Admin
                            </button>
                          </div>
                          <span className="text-[9px] font-mono text-gray-500 block leading-normal text-left">
                            Current Rank: <span className="text-[#00FFCC] font-bold uppercase">{selectedUser.role ? selectedUser.role.replace('_', ' ') : 'PLAYER'}</span>
                            {selectedUser.role === 'wallet_manager' && " • Can access Payouts and Support Tools"}
                            {selectedUser.role === 'chat_manager' && " • Can access Disputes and Live Support"}
                            {selectedUser.role === 'admin' && " • Absolute owner rank with full module bypass"}
                          </span>
                        </div>
                      )}
                    </div>
                    );
                  })()
                ) : (
                  <div className="flex-1 flex flex-col items-center justify-center text-center p-6">
                    <Coins className="w-12 h-12 text-gray-600 mb-2 animate-pulse" />
                    <span className="text-xs font-mono font-black text-gray-300 uppercase tracking-wider block">No Player Account Selected</span>
                    <p className="text-xs text-gray-500 max-w-[220px] mt-2 leading-relaxed">
                      Select one of the players from the directory list on the left to initiate manual wallet balance modifications.
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* 🔮 CUSTOM MANUAL TRANSACTION ACCOUNTABILITY & SAFETY OVERLAY */}
            {showAdjConfirmModal && adjConfirmData && (
              <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-fade-in select-none">
                <div className="bg-[#0A0E17] border-2 border-blue-500 rounded-3xl p-6 md:p-8 max-w-lg w-full space-y-6 shadow-[0_0_50px_rgba(59,130,246,0.25)] relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />
                  <div className="absolute top-0 left-0 w-full h-[3px] bg-gradient-to-r from-blue-500 via-indigo-500 to-cyan-500" />
                  
                  <div className="text-center space-y-4">
                    <div className="w-16 h-16 bg-blue-500/10 border-2 border-blue-500/30 rounded-full flex items-center justify-center mx-auto text-blue-400">
                      <Coins className="w-8 h-8 animate-bounce" />
                    </div>
                    <div>
                      <h2 className="text-lg md:text-xl font-display font-black text-white uppercase tracking-wider">
                        Verify Transaction Compliance
                      </h2>
                      <p className="text-xs text-gray-400">Review carefully before writing these record adjustments directly to the database.</p>
                    </div>
                  </div>

                  <div className="bg-[#13192B] border border-[#222D4A] rounded-2xl p-5 space-y-4 text-left font-mono text-sm leading-relaxed">
                    <div className="flex justify-between border-b border-[#222D4A]/60 pb-2">
                      <span className="text-gray-400 uppercase font-bold">👤 TARGET PLAYER</span>
                      <span className="text-white font-extrabold text-base">@{adjConfirmData.username}</span>
                    </div>
                    <span className="text-xs block text-gray-450 tracking-wide">IGN: {adjConfirmData.ign || 'NO IGN ADDED'} • TEL: +91 {adjConfirmData.phone}</span>
                    
                    <div className="flex justify-between border-b border-[#222D4A]/60 pb-2 pt-1">
                      <span className="text-gray-400 uppercase font-bold">💸 ACTION COMMAND</span>
                      <span className={`font-extrabold px-3 py-0.5 rounded text-xs uppercase tracking-widest ${
                        adjConfirmData.type === 'credit' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                      }`}>
                        MANUAL {adjConfirmData.type.toUpperCase()}
                      </span>
                    </div>
                    
                    <div className="flex justify-between border-b border-[#222D4A]/60 pb-2 pt-1">
                      <span className="text-gray-400 uppercase font-bold">🪙 TRANSACTION VALUE</span>
                      <span className="text-amber-400 font-black text-lg">₹{adjConfirmData.amount.toFixed(2)}</span>
                    </div>
                    
                    <div className="flex justify-between border-b border-[#222D4A]/60 pb-2 pt-1">
                      <span className="text-gray-400 uppercase font-bold">💼 WALLET INSTANCE</span>
                      <span className="text-blue-300 font-extrabold uppercase text-xs">{adjConfirmData.pool.toUpperCase()} Pool</span>
                    </div>

                    <div className="border-b border-[#222D4A]/60 pb-2 pt-1">
                      <span className="text-gray-400 uppercase font-bold block mb-1">📝 AUDIT LOG NOTE</span>
                      <span className="text-gray-300 block text-xs bg-black/40 p-2.5 rounded-xl border border-[#222D4A]/30 italic font-mono font-bold">
                        "{adjConfirmData.note || 'Manual audit adjust by admin'}"
                      </span>
                    </div>

                    {adjConfirmData.isWarning && (
                      <div className="bg-rose-500/10 border border-rose-500/20 p-3 rounded-xl text-rose-400 text-xs font-sans">
                        <span className="font-extrabold block mb-1">⚠️ NEGATIVE BALANCE COMPLIANCE ALERT:</span>
                        Target player only holds ₹{adjConfirmData.currentBalance.toFixed(2)} in {adjConfirmData.pool.toUpperCase()}. Deducting ₹{adjConfirmData.amount.toFixed(2)} will force balance to ₹{(adjConfirmData.currentBalance - adjConfirmData.amount).toFixed(2)}.
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => {
                        setShowAdjConfirmModal(false);
                        setAdjConfirmData(null);
                      }}
                      className="py-3 bg-[#13192B] hover:bg-[#1C253E] text-white border border-[#222D4A] rounded-xl font-display font-black text-xs uppercase tracking-wide cursor-pointer transition-all"
                    >
                      Abort Request
                    </button>
                    <button
                      type="button"
                      onClick={commitManualWalletAdjustment}
                      className="py-3 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white rounded-xl font-display font-black text-xs uppercase tracking-wide cursor-pointer transition-all shadow-[0_0_20px_rgba(59,130,246,0.3)] animate-pulse"
                    >
                      Authorize Adjustment
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Redirect to dedicated Requests Desk */}
          <div className="bg-[#13192B]/40 hover:bg-[#13192B]/75 border border-dashed border-emerald-500/30 rounded-2.5xl p-5 flex flex-col md:flex-row items-center justify-between gap-4 text-left transition-all">
            <div className="space-y-1">
              <h4 className="font-display font-black text-xs uppercase text-[#00FFCC] tracking-wider flex items-center gap-1.5 font-bold">
                🏦 PENDING VALENT REQUESTS WORKSPACE
              </h4>
              <p className="text-[10px] text-gray-450 font-mono leading-normal max-w-xl">
                Pending player deposits, manual transfer receipt checks, and UPI or Bank cash out withdrawal request queues have been transferred to the dedicated <strong className="text-white">Requests Desk</strong> tab.
              </p>
            </div>
            <button
              type="button"
              onClick={() => { setActiveTab('requests'); setDisputeMatchId(null); setBroadcastingMatchId(null); }}
              className="px-4 py-2.5 bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-500/35 hover:border-emerald-500 text-emerald-400 font-mono text-[9px] font-black uppercase rounded-xl transition-all shadow-md shrink-0 cursor-pointer"
            >
              Go to Requests Desk →
            </button>
          </div>

          {/* =========================================================================
              🏟️ NEW TOURNAMENT MATCH PAYOUTS & RAPID CREDIT/DEBIT ENGINE
             ========================================================================= */}
          <div className="bg-[#13192B] border-2 border-emerald-500/40 rounded-2.5xl p-6 space-y-5 shadow-2.5xl text-left relative overflow-hidden">
            <div className="absolute top-0 right-0 w-36 h-36 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute top-0 left-0 w-full h-[3px] bg-gradient-to-r from-emerald-500 via-teal-500 to-green-500 animate-pulse" />

            <div className="flex items-center gap-3">
              <div className="p-3 bg-emerald-500/10 border border-emerald-500/25 rounded-2xl text-emerald-400 shrink-0">
                <Trophy className="w-6 h-6 animate-pulse" />
              </div>
              <div>
                <h3 className="font-display font-black text-sm uppercase text-white tracking-widest flex items-center gap-2">
                  🏟️ MATCH-BASED PLAYER PAYOUT DESK
                </h3>
                <p className="text-xs text-gray-400 font-mono mt-0.5">
                  Select an active or completed custom room. List all joined players, and manually add prize money directly to their platform accounts with a fast, live update!
                </p>
              </div>
            </div>

            {payoutLogsFeed && (
              <div className="bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 p-4 rounded-xl text-xs font-mono font-bold animate-fade-in leading-normal shadow">
                {payoutLogsFeed}
              </div>
            )}

            <div className="space-y-4">
              <span className="text-[10px] font-mono text-gray-400 uppercase font-bold pl-0.5 block">Select Active/Past Match Lobby:</span>
              <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-thin max-w-full">
                {matches.map(m => {
                  const isSelected = selectedPayoutMatchId === m.id;
                  const joinedCount = m.players.length;
                  return (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => {
                        setSelectedPayoutMatchId(m.id);
                        setPayoutLogsFeed(null);
                        // Prepopulate payout amounts and notes for speeds
                        const defaultAmounts: Record<string, string> = {};
                        const defaultNotes: Record<string, string> = {};
                        m.players.forEach(p => {
                          defaultAmounts[p.userId] = m.prizePerPlayer ? m.prizePerPlayer.toString() : '100';
                          defaultNotes[p.userId] = `Prize Winner: ${m.title}`;
                        });
                        setMatchPayoutAmounts(defaultAmounts);
                        setMatchPayoutNotes(defaultNotes);
                      }}
                      className={`px-4 py-2.5 rounded-xl border font-mono text-xs uppercase cursor-pointer shrink-0 transition-all text-left space-y-1 ${
                        isSelected 
                          ? 'bg-emerald-950/30 border-emerald-500 text-emerald-300 shadow-[0_0_12px_rgba(16,185,129,0.15)] font-extrabold' 
                          : 'bg-[#0A0D18]/85 border-[#222D4A]/60 text-gray-400 hover:border-gray-700 hover:text-white'
                      }`}
                    >
                      <div className="font-bold flex items-center gap-1.5">
                        <span>{m.title}</span>
                        <span className="text-[8.5px] px-1 bg-black/40 rounded">{m.format_type}</span>
                      </div>
                      <div className="text-[9.5px] text-gray-500">
                        {joinedCount} / {m.spotsTotal} Slots • {m.mapName}
                      </div>
                    </button>
                  );
                })}
              </div>

              {selectedPayoutMatchId ? (() => {
                const selMatch = matches.find(m => m.id === selectedPayoutMatchId);
                if (!selMatch) return null;
                return (
                  <div className="bg-[#0A0E17]/65 border border-[#222D4A]/70 rounded-2.5xl p-4.5 space-y-4">
                    <div className="flex justify-between items-center bg-[#13192B]/90 border border-[#222D4A] p-3 rounded-xl">
                      <div className="text-left font-mono">
                        <span className="text-[9px] text-[#00FFCC] uppercase font-black block tracking-widest mb-0.5">SELECTED ARENA LOBBY</span>
                        <h4 className="text-sm font-bold text-white uppercase">{selMatch.title} ({selMatch.format_type})</h4>
                        <span className="text-[10px] text-gray-400">Prize Pool: ₹{selMatch.prizePool} • Winner Payout Each: ₹{selMatch.prizePerPlayer || '0'}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => setSelectedPayoutMatchId('')}
                        className="px-3 py-1 bg-black/40 hover:bg-black/80 rounded border border-[#222D4A] text-xs font-mono text-gray-400 hover:text-white transition-all cursor-pointer"
                      >
                        ✕ Close
                      </button>
                    </div>

                    <div className="space-y-3 max-h-96 overflow-y-auto pr-1 scrollbar-thin">
                      <span className="text-[10px] font-mono text-gray-400 uppercase tracking-wider block font-bold pl-0.5">LOBBY ENLISTED PLAYERS DIRECTORY ({selMatch.players.length}):</span>
                      {selMatch.players.map((p, idx) => {
                        const payoutAmt = matchPayoutAmounts[p.userId] || '';
                        const payoutReason = matchPayoutNotes[p.userId] || '';
                        
                        // Find current wallet state
                        const targetUserObj = users.find(u => u.id === p.userId);
                        const currentDep = targetUserObj?.wallet.deposit || 0;
                        const currentWin = targetUserObj?.wallet.winnings || 0;

                        const executeQuickPayout = (pool: 'deposit' | 'winnings') => {
                          const amtNum = parseFloat(payoutAmt);
                          if (isNaN(amtNum) || amtNum <= 0) {
                            alert('⚠️ Specify a valid reward amount greater than 0.');
                            return;
                          }

                          try {
                            const allUsers = getUsers();
                            const userIdx = allUsers.findIndex(u => u.id === p.userId);
                            if (userIdx === -1) {
                              alert('⚠️ Player account was not found in global database.');
                              return;
                            }

                            // Credit selected pool
                            const targetUsr = allUsers[userIdx];
                            if (!targetUsr.wallet) {
                              targetUsr.wallet = { deposit: 0, winnings: 0, bonus: 0 };
                            }
                            if (pool === 'deposit') {
                              targetUsr.wallet.deposit = (targetUsr.wallet.deposit || 0) + amtNum;
                            } else {
                              targetUsr.wallet.winnings = (targetUsr.wallet.winnings || 0) + amtNum;
                            }

                            // Commit user
                            allUsers[userIdx] = targetUsr;
                            saveUsers(allUsers);
                            setUsers(allUsers);

                            // Create payout transaction
                            const txs = getTransactions();
                            txs.unshift({
                              id: `tx-payout-${Date.now()}`,
                              userId: p.userId,
                              type: 'deposit', // credits are deposit type transactions in ledger
                              amount: amtNum,
                              status: 'approved',
                              created_at: new Date().toISOString(),
                              matchId: selMatch.id,
                              matchTitle: selMatch.title,
                              note: payoutReason || `Match Payout: ${selMatch.title}`
                            });
                            saveTransactions(txs);
                            setTransactions(txs);

                            // Dispatch for immediate reload in app header & profile instantly!
                            window.dispatchEvent(new Event('valent_db_update'));

                            setPayoutLogsFeed(`🚀 SUCCESS: Paid ₹${amtNum.toFixed(2)} to @${p.username} (${p.ign}) in ${pool.toUpperCase()} instance successfully!`);
                          } catch (err) {
                            console.error('Failed paying out player:', err);
                            alert('⚠️ Failed to save balance record to database.');
                          }
                        };

                        return (
                          <div key={idx} className="bg-[#121827] border border-[#222D4A] p-3.5 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-4 font-mono">
                            <div className="flex-1 min-w-0 text-left space-y-1.5">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="text-xs font-black text-white">@{p.username}</span>
                                <span className={`text-[8px] px-1 rounded font-black ${p.team === 'A' ? 'bg-[#FF4500]/10 text-[#FF4500]' : 'bg-blue-500/10 text-blue-400'}`}>
                                  {p.team === 'A' ? 'A (ALPHA)' : 'B (BETA)'}
                                </span>
                                <span className="text-[9.5px] bg-[#00FFCC]/10 text-[#00FFCC] font-bold px-1 rounded">Lvl {p.level || '?' }</span>
                              </div>
                              <span className="text-xs font-black text-[#00FFCC] block uppercase tracking-wide">
                                IGN: {p.ign}
                              </span>
                              <div className="text-[9px] text-gray-500 flex gap-2">
                                <span>Dep: <strong className="text-gray-300">₹{Math.max(0, currentDep).toFixed(0)}</strong></span>
                                <span>Win: <strong className="text-emerald-400">₹{Math.max(0, currentWin).toFixed(0)}</strong></span>
                              </div>
                            </div>

                            <div className="flex flex-col sm:flex-row items-center gap-2 w-full md:w-auto">
                              <div className="flex gap-1.5 items-center w-full sm:w-auto">
                                <span className="text-[9px] text-gray-500 font-bold uppercase block sm:hidden">Amt:</span>
                                <input
                                  type="number"
                                  placeholder="Amt"
                                  value={payoutAmt}
                                  onChange={(e) => {
                                    setMatchPayoutAmounts(prev => ({ ...prev, [p.userId]: e.target.value }));
                                  }}
                                  className="w-16 bg-[#0A0D18] border border-[#222D4A] rounded-xl px-2.5 py-1.5 text-xs text-center text-white focus:outline-none focus:border-emerald-500 font-bold"
                                />
                                <input
                                  type="text"
                                  placeholder="payout note reason"
                                  value={payoutReason}
                                  onChange={(e) => {
                                    setMatchPayoutNotes(prev => ({ ...prev, [p.userId]: e.target.value }));
                                  }}
                                  className="flex-1 sm:w-36 bg-[#0A0D18] border border-[#222D4A] rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-emerald-500 placeholder-gray-750"
                                />
                              </div>

                              <div className="flex gap-1 w-full sm:w-auto">
                                <button
                                  type="button"
                                  onClick={() => executeQuickPayout('winnings')}
                                  className="flex-1 sm:flex-none px-3 py-1.5 bg-emerald-950 hover:bg-emerald-900 border border-emerald-500/35 hover:border-emerald-500 text-emerald-400 font-black rounded-lg text-[9px] uppercase transition-all duration-150 cursor-pointer shadow-md"
                                >
                                  🚀 PAY WIN (₹)
                                </button>
                                <button
                                  type="button"
                                  onClick={() => executeQuickPayout('deposit')}
                                  className="flex-1 sm:flex-none px-3 py-1.5 bg-blue-950 hover:bg-blue-900 border border-blue-500/35 hover:border-blue-500 text-blue-400 font-black rounded-lg text-[9px] uppercase transition-all duration-150 cursor-pointer shadow-md"
                                >
                                  💸 REF DEP (₹)
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                      {selMatch.players.length === 0 && (
                        <div className="text-center py-6 text-xs text-gray-500">No players registered for this lobby arena match...</div>
                      )}
                    </div>
                  </div>
                );
              })() : (
                <div className="text-center bg-[#070A11] rounded-2xl py-8 border border-dashed border-[#222D4A]">
                  <Trophy className="w-8 h-8 text-gray-600 mx-auto mb-2 animate-bounce" />
                  <span className="text-xs text-gray-500 uppercase font-mono font-bold block">No Arena Match Selected</span>
                  <p className="text-[10px] text-gray-600 font-mono max-w-[280px] mx-auto mt-1 leading-normal">Choose one of the matches above to pull its player registrations ledger list.</p>
                </div>
              )}
            </div>
          </div>

          {/* =========================================================================
              📢 NEW SQUAD REFERRAL NETWORK MAP & BONUS LEADS AUDIT DESK
             ========================================================================= */}
          <div className="bg-[#13192B] border border-[#FF4500]/40 rounded-2.5xl p-6 space-y-4 shadow-xl text-left relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-orange-500/5 rounded-full blur-3xl pointer-events-none" />
            
            <div className="flex items-center gap-2.5 border-b border-[#222D4A]/55 pb-3">
              <div className="p-2 bg-orange-500/15 border border-orange-500/20 rounded-xl text-[#FF4500]">
                <Sparkles className="w-5 h-5 animate-pulse" />
              </div>
              <div>
                <h3 className="font-display font-black text-xs uppercase text-white tracking-widest leading-none mb-1">
                  📢 REFERRAL NETWORK MAP & BONUS LEADS
                </h3>
                <p className="text-[10px] text-gray-400 font-mono">Real-time audit list tracking which invite code recruits linked during registration, invitees first match joins and paid bonuses.</p>
              </div>
            </div>

            <div className="max-h-72 overflow-y-auto space-y-2 pr-1 scrollbar-thin">
              {(() => {
                const referredUsers = users.filter(u => u.referredByUserId || u.referredBy);
                if (referredUsers.length === 0) {
                  return <div className="text-center py-8 text-xs font-mono text-gray-600 italic">No registrations with referral codes recorded yet...</div>;
                }
                return (
                  <div className="space-y-2 text-xs font-mono animate-fade-in" id="referral-list-desk">
                    <div className="grid grid-cols-3 text-[9px] font-bold text-gray-500 uppercase pb-1 px-2 border-b border-[#222D4A]/40">
                      <span>Recruit Username</span>
                      <span>Target Code / Inviter</span>
                      <span className="text-right">Payout Status</span>
                    </div>

                    {referredUsers.map(r => {
                      const code = r.referredBy || 'SYSTEM';
                      const inviterObj = users.find(u => u.id === r.referredByUserId || u.username.toUpperCase() === code.toUpperCase());
                      return (
                        <div key={r.id} className="grid grid-cols-3 p-2.5 bg-[#0A0D18]/80 border border-[#222D4A]/50 rounded-xl items-center">
                          <div className="space-y-0.5 min-w-0 pr-1">
                            <span className="font-extrabold text-white block truncate">@{r.username}</span>
                            <span className="text-[9px] text-[#00FFCC] block truncate">IGN: {r.ign || 'PENDING JOIN'}</span>
                          </div>
                          <div className="space-y-0.5">
                            <span className="text-amber-500 font-bold block">{code.toUpperCase()}</span>
                            {inviterObj && (
                              <span className="text-[9px] text-gray-400 block truncate">Ref: @{inviterObj.username}</span>
                            )}
                          </div>
                          <div className="text-right">
                            <span className={`text-[8.5px] px-2 py-0.5 rounded font-bold uppercase tracking-wider ${
                              r.isReferralRewardPaid
                                ? 'bg-emerald-950 text-emerald-400 border border-emerald-900/50'
                                : 'bg-gray-900 text-gray-550 border border-[#222D4A]'
                            }`}>
                              {r.isReferralRewardPaid ? '✓ ₹25 PAID' : '⏳ PENDING ₹60 DEP'}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                );
              })()}
            </div>
          </div>
        </div>
      )}

      {/* Tab Content: Dedicated Requests Desk (Durable Ledger, Verification & Voucher release) */}
      {activeTab === 'requests' && (
        <div className="space-y-5 animate-fade-in text-left">
          {/* Header Workspace Details card */}
          <div className="bg-[#13192B] border border-emerald-500/35 rounded-2.5xl p-5 shadow-xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute top-0 left-0 w-full h-[3px] bg-gradient-to-r from-emerald-500 via-teal-500 to-[#00FFCC] animate-pulse" />

            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1">
                <h2 className="font-display font-black text-sm uppercase text-[#00FFCC] tracking-widest flex items-center gap-2">
                  🏦 TREASURY & PAYOUTS DESK
                </h2>
                <p className="text-xs text-gray-400 font-mono">
                  Meticulously verify player deposit proofs and audit outgoing UPI/Bank/Google Play cash-out requests.
                </p>
              </div>

              {/* Instant Counter Stats */}
              <div className="flex gap-2 font-mono">
                <div className="bg-[#0A0E17] border border-[#222D4A] rounded-xl px-3 py-1.5 text-center">
                  <span className="text-[8px] text-gray-500 uppercase tracking-widest block">DEPOSITS</span>
                  <span className="text-xs font-bold text-emerald-400">
                    {transactions.filter(t => t.status === 'pending' && t.type === 'deposit').length} Pending
                  </span>
                </div>
                <div className="bg-[#0A0E17] border border-[#222D4A] rounded-xl px-3 py-1.5 text-center">
                  <span className="text-[8px] text-gray-500 uppercase tracking-widest block">CASHOUTS</span>
                  <span className="text-xs font-bold text-pink-400">
                    {transactions.filter(t => t.status === 'pending' && t.type === 'withdrawal').length} Pending
                  </span>
                </div>
              </div>
            </div>

            {/* Quick Actions & Search row */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-4 mt-4 border-t border-[#222D4A]/50">
              {/* Toggle Switches */}
              <div className="flex gap-1.5 bg-[#0A0D17] p-1 border border-[#222D4A] rounded-xl col-span-1 md:col-span-2">
                {[
                  { key: 'all' as const, label: '📋 All Requests' },
                  { key: 'deposit' as const, label: '📥 Deposits Proof' },
                  { key: 'withdrawal' as const, label: '📤 Cashouts Queue' },
                ].map((btn) => (
                  <button
                    key={btn.key}
                    type="button"
                    onClick={() => setRequestsFilter(btn.key)}
                    className={`flex-1 py-1.5 text-[9px] font-mono font-bold uppercase rounded-lg transition-all cursor-pointer ${
                      requestsFilter === btn.key
                        ? 'bg-gradient-to-r from-emerald-900 to-emerald-800 text-white shadow-md border border-emerald-500/20'
                        : 'text-gray-400 hover:text-gray-200 hover:bg-white/5'
                    }`}
                  >
                    {btn.label}
                  </button>
                ))}
              </div>

              {/* Dynamic search input */}
              <div className="relative">
                <input
                  type="text"
                  placeholder="SEARCH USERNAME..."
                  value={requestsSearch}
                  onChange={(e) => setRequestsSearch(e.target.value)}
                  className="w-full bg-[#0A0D17] border border-[#222D4A] rounded-xl py-2 px-3 pl-8 text-[11px] font-mono text-white placeholder-gray-600 focus:outline-none focus:border-emerald-500 transition-all uppercase"
                />
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-650 font-bold select-none text-[10px] font-mono">🔍</span>
              </div>
            </div>
          </div>

          {/* List of Filtered Requests */}
          <div className="space-y-4">
            {(() => {
              const filteredList = transactions
                .filter(t => t.status === 'pending')
                .filter(t => {
                  if (requestsFilter === 'all') return true;
                  return t.type === requestsFilter;
                })
                .filter(t => {
                  if (!requestsSearch) return true;
                  const q = requestsSearch.toLowerCase();
                  const u = users.find(usr => usr.id === t.userId);
                  const usernameMatch = u?.username?.toLowerCase().includes(q) || false;
                  const methodMatch = t.withdrawMethod?.toLowerCase().includes(q) || false;
                  const amountMatch = t.amount.toString().includes(q);
                  const upiMatch = t.upiId?.toLowerCase().includes(q) || false;
                  return usernameMatch || methodMatch || amountMatch || upiMatch;
                });

              if (filteredList.length === 0) {
                return (
                  <div className="bg-[#13192B]/30 border border-dashed border-[#222D4A] rounded-2.5xl py-12 text-center">
                    <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest block font-bold mb-1">
                      NO MATCHING PENDING REQUESTS
                    </span>
                    <span className="text-[9px] text-gray-600 font-mono block">
                      Everything has been successfully processed! Outstanding audits cleared.
                    </span>
                  </div>
                );
              }

              return filteredList.map((t) => {
                const u = users.find(usr => usr.id === t.userId);
                const isDeposit = t.type === 'deposit';
                
                return (
                  <div
                    key={t.id}
                    className={`bg-[#13192B] border rounded-2.5xl p-5 space-y-4 text-left transition-all relative overflow-hidden ${
                      isDeposit 
                        ? 'border-emerald-500/20 shadow-[0_4px_24px_rgba(16,185,129,0.03)]' 
                        : 'border-pink-500/20 shadow-[0_4px_24px_rgba(244,63,94,0.03)]'
                    }`}
                  >
                    {/* Background glows */}
                    <div className={`absolute top-0 right-0 w-24 h-24 rounded-full blur-2xl pointer-events-none ${
                      isDeposit ? 'bg-emerald-500/5' : 'bg-pink-500/5'
                    }`} />

                    {/* Top Row: Info Badge & Master Approvals */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#222D4A]/55">
                      <div className="flex items-center gap-2">
                        <span className={`text-[8.5px] px-2.5 py-1 rounded-lg font-mono font-black uppercase tracking-wider border leading-none ${
                          isDeposit 
                            ? 'bg-emerald-950/80 text-emerald-400 border-emerald-800' 
                            : 'bg-pink-950/80 text-pink-400 border-pink-850'
                        }`}>
                          {t.type.toUpperCase()} REQUEST
                        </span>
                        
                        <div className="font-mono text-xs text-gray-400">
                          ID: <span className="text-gray-500">#{t.id.slice(-8).toUpperCase()}</span>
                        </div>
                      </div>

                      {/* Decisive Approvals triggers */}
                      <div className="flex gap-2 shrink-0">
                        <button
                          type="button"
                          onClick={() => handleApproveTransaction(t.id, 'rejected')}
                          className="px-3.5 py-1.5 bg-rose-950/30 hover:bg-rose-900/60 border border-rose-500/30 hover:border-rose-500 text-rose-450 hover:text-white rounded-xl text-[9px] font-mono uppercase font-black cursor-pointer transition-all shadow"
                        >
                          ❌ Reject Request
                        </button>
                        
                        <button
                          type="button"
                          onClick={() => {
                            // Enforce input before approving Google Play cashouts
                            if (t.type === 'withdrawal' && t.withdrawMethod === 'googleplay') {
                              const gCode = adminRedeemCodes[t.id]?.trim();
                              if (!gCode || gCode.length < 5) {
                                setTxAlertMessage('⚠️ Please enter the Google Play Gift Voucher Redeem Code in the field below before approving!');
                                return;
                              }
                            }
                            handleApproveTransaction(t.id, 'approved');
                          }}
                          className={`px-4 py-1.5 rounded-xl text-[9px] font-mono uppercase font-black cursor-pointer transition-all shadow-md text-white ${
                            isDeposit
                              ? 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500'
                              : 'bg-gradient-to-r from-[#FF4500] to-pink-600 hover:from-orange-500 hover:to-pink-500'
                          }`}
                        >
                          ✓ Approve & Credit
                        </button>
                      </div>
                    </div>

                    {/* Middle Row: Player Profile Info Banner */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3 bg-[#0A0D17]/55 border border-[#222D4A]/50 p-4 rounded-xl text-xs font-mono">
                      <div>
                        <span className="text-[8.5px] text-gray-500 uppercase tracking-widest block mb-0.5">Player Handle</span>
                        <span className="font-extrabold text-[#00FFCC] block text-sm">@{u?.username || 'Esports Player'}</span>
                        <span className="text-[10px] text-gray-400 block mt-0.5">UID: {t.userId}</span>
                      </div>
                      <div>
                        <span className="text-[8.5px] text-gray-500 uppercase tracking-widest block mb-0.5">Audited Cash Target</span>
                        <span className="font-sans font-black text-white text-base">₹{t.amount.toFixed(2)}</span>
                        <span className="text-[9px] text-gray-400 block mt-0.5 uppercase">Pool: {t.withdrawSource || 'Winnings'}</span>
                      </div>
                      <div>
                        <span className="text-[8.5px] text-gray-500 uppercase tracking-widest block mb-0.5">Player Contacts</span>
                        <span className="text-gray-300 block font-bold">{u?.phone || 'No registered contact phone'}</span>
                        <span className="text-[9.5px] text-gray-400 block mt-0.5 truncate">Joined Match Count: {u?.joinedMatches?.length || 0} lobbies</span>
                      </div>
                    </div>

                    {/* Bottom Row: Validation details based on payout type */}
                    {isDeposit ? (
                      /* Deposit Layout Receipt proofs */
                      <div className="space-y-4 pt-1">
                        {/* UTR Verification Block */}
                        <div className="bg-[#0A0D17] border border-emerald-500/20 p-4 rounded-2xl space-y-3 shadow-inner text-left">
                          <div className="flex justify-between items-center bg-[#121829] border border-[#222D4A] p-3.5 rounded-xl gap-2">
                            <div className="min-w-0 flex-1">
                              <span className="text-[9px] font-mono font-bold text-gray-500 uppercase tracking-wider block mb-0.5">
                                CUSTOMER SUBMITTED UPI REFERRING UTR / REF ID
                              </span>
                              <span className="text-sm text-[#00FFCC] font-mono font-black break-all select-all block tracking-wide uppercase">
                                {t.utr || 'NO REF KEY SUBMITTED'}
                              </span>
                            </div>
                            
                            {t.utr && (
                              <button
                                type="button"
                                onClick={() => {
                                  handleCopyText(t.id + '-utr', t.utr || '');
                                }}
                                className={`px-3.5 py-2.5 rounded-xl border font-mono text-[10px] flex items-center gap-1.5 shrink-0 transition-all font-black uppercase ${
                                  copiedTxId === t.id + '-utr'
                                    ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30'
                                    : 'text-gray-300 bg-black border-gray-800 hover:text-white hover:bg-gray-900 shadow-md transition-all'
                                }`}
                              >
                                {copiedTxId === t.id + '-utr' ? (
                                  <>
                                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                                    <span>COPIED!</span>
                                  </>
                                ) : (
                                  <>
                                    <Copy className="w-3.5 h-3.5 text-gray-450" />
                                    <span>COPY UTR</span>
                                  </>
                                )}
                              </button>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center justify-between">
                          <span className="text-[9px] font-mono text-gray-450 uppercase tracking-wider block font-bold">
                            📷 custom user upload proof-of-payment receipt (Tap to full-screen audit):
                          </span>
                        </div>

                        {t.proofImageUrl ? (
                          <div className="relative group max-w-sm overflow-hidden rounded-2xl border-4 border-emerald-500/20 shadow-2xl">
                            <img
                              src={t.proofImageUrl}
                              alt="Upload payment screen reference"
                              className="w-full h-56 object-cover cursor-zoom-in group-hover:scale-[1.01] transition-all"
                              onClick={() => {
                                setActiveZoomImage(t.proofImageUrl || null);
                              }}
                            />
                            <div className="absolute inset-x-0 bottom-0 bg-black/60 backdrop-blur-xs p-2 text-center group-hover:bg-black/70 transition-all">
                              <span className="text-[9px] font-mono text-emerald-400 font-bold animate-pulse">
                                🔍 CLICK/TAP TO ENLARGE FOR DEEP AUDIT
                              </span>
                            </div>
                          </div>
                        ) : (
                          <div className="p-4 border border-dashed border-[#222D4A] rounded-2xl text-center bg-[#0A0D17]">
                            <span className="text-[10px] font-mono text-amber-500 block font-extrabold uppercase mb-0.5">
                              ⚠️ PAYMENT RECEIPT EXCEPTION ALERT:
                            </span>
                            <span className="text-[9px] text-gray-400 font-mono block leading-relaxed max-w-lg mx-auto">
                              The player did not upload an attachment screenshot for this transaction. Please manually query your payment settlement logs to confirm receipt of the exact sum before authorizing.
                            </span>
                          </div>
                        )}
                      </div>
                    ) : (
                      /* Withdrawal layout (UPI / Bank / Google Play) */
                      <div className="space-y-3 pt-1">
                        {/* 1. Google Play Code Redeem Input */}
                        {t.withdrawMethod === 'googleplay' && (
                          <div className="bg-[#0A0D17] border border-amber-500/20 p-4 rounded-xl space-y-2 animate-fade-in text-left">
                            <span className="text-[10px] font-mono text-amber-500 uppercase tracking-widest block font-black">
                              🚨 Google Play Store Redeem Gift Voucher Code Required:
                            </span>
                            <div className="flex gap-2">
                              <input
                                type="text"
                                placeholder="PASTE 16-DIGIT GOOGLE PLAY REDEEM KEY STORE PIN"
                                value={adminRedeemCodes[t.id] || ''}
                                onChange={(e) => setAdminRedeemCodes({
                                  ...adminRedeemCodes,
                                  [t.id]: e.target.value.toUpperCase()
                                })}
                                className="flex-1 bg-black border border-[#2E3547] rounded-xl py-3 px-4 text-amber-400 font-mono font-black focus:outline-none focus:border-amber-500 placeholder-gray-700 text-xs tracking-wider uppercase shadow-inner"
                              />
                            </div>
                            <span className="text-[8.5px] font-mono text-gray-400 block leading-normal">
                              Admin must write key codes accurately which the system will present inside the player transaction ledger history so they can retrieve it instantly.
                            </span>
                          </div>
                        )}

                        {/* 2. UPI Method Transfer details */}
                        {t.withdrawMethod === 'upi' && (
                          <div className="bg-[#0A0D17] border border-emerald-500/20 p-4 rounded-2xl space-y-4 shadow-inner text-left">
                            <div className="flex justify-between items-center bg-[#121829] border border-[#222D4A] p-3.5 rounded-xl gap-2">
                              <div className="min-w-0 flex-1">
                                <span className="text-[9px] font-mono font-bold text-gray-500 uppercase tracking-wider block mb-0.5 font-semibold">
                                  RECIPIENT UPI ID ADDRESS
                                </span>
                                <span className="text-sm text-[#00FFCC] font-mono font-black break-all select-all block tracking-wide">
                                  {t.upiId || 'Not Specified'}
                                </span>
                              </div>
                              
                              {t.upiId && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    handleCopyText(t.id, t.upiId || '');
                                  }}
                                  className={`px-3.5 py-2.5 rounded-xl border font-mono text-[10px] flex items-center gap-1.5 shrink-0 transition-all font-black uppercase ${
                                    copiedTxId === t.id
                                      ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30'
                                      : 'text-gray-300 bg-black border-gray-800 hover:text-white hover:bg-gray-900 shadow-md'
                                  }`}
                                >
                                  {copiedTxId === t.id ? (
                                    <>
                                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                                      <span>COPIED!</span>
                                    </>
                                  ) : (
                                    <>
                                      <Copy className="w-3.5 h-3.5 text-gray-450" />
                                      <span>COPY UPI</span>
                                    </>
                                  )}
                                </button>
                              )}
                            </div>

                            {/* Verification scanner image if present */}
                            {t.proofImageUrl ? (
                              <div className="space-y-2.5">
                                <span className="text-[8.5px] font-mono text-gray-450 block uppercase tracking-wider font-semibold">
                                  📷 PLAYER DEPOSITED PERSONAL TRANSFER UPI QR SCANNER (Click to audit zoom):
                                </span>
                                <div className="max-w-[200px] bg-white p-3.5 rounded-xl border-4 border-emerald-500/30 shadow-2xl relative overflow-hidden group">
                                  <img
                                    src={t.proofImageUrl}
                                    alt="Payment check details"
                                    className="w-full h-full object-contain rounded cursor-zoom-in"
                                    onClick={() => {
                                      setActiveZoomImage(t.proofImageUrl || null);
                                    }}
                                  />
                                </div>
                              </div>
                            ) : (
                              <div className="p-3 border border-dashed border-[#222D4A] rounded-xl text-center bg-black/40">
                                <p className="text-[9px] text-gray-500 font-mono text-center block w-full">
                                  ℹ️ No companion companion scanner QR code image attached by user. Dispatch to UPI Id as typed.
                                </p>
                              </div>
                            )}
                          </div>
                        )}

                        {/* 3. Bank Transfer netbanking details */}
                        {t.withdrawMethod === 'bank' && t.bankDetails && (
                          <div className="bg-[#0A0D17] border border-[#222D4A] rounded-xl p-4 space-y-3">
                            <span className="text-[9px] font-mono font-bold text-gray-400 uppercase tracking-widest block mb-1">
                              Player NetBanking Settlement Destination:
                            </span>

                            <div className="space-y-2 bg-[#12192A]/60 border border-[#222D4A]/50 rounded-lg p-3 text-xs">
                              <div className="flex justify-between items-center py-1 border-b border-[#222D4A]/30">
                                <span className="text-[10px] text-gray-450 font-mono">Account Holder Name</span>
                                <span className="font-sans font-bold text-white uppercase text-right truncate pl-4">{t.bankDetails.holderName}</span>
                              </div>
                              
                              <div className="flex justify-between items-center py-0.5 border-b border-[#222D4A]/30 font-mono">
                                <span className="text-[10px] text-gray-440 font-mono">Account Number</span>
                                <div className="flex items-center gap-1.5">
                                  <span className="font-bold text-[#00FFCC]">{t.bankDetails.accountNumber}</span>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      handleCopyText(t.id + '-acc', t.bankDetails?.accountNumber || '');
                                    }}
                                    className="p-1 hover:text-[#00FFCC] text-gray-450 transition-colors"
                                  >
                                    {copiedTxId === t.id + '-acc' ? (
                                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                                    ) : (
                                      <Copy className="w-3.5 h-3.5" />
                                    )}
                                  </button>
                                </div>
                              </div>

                              <div className="flex justify-between items-center py-0.5 font-mono">
                                <span className="text-[10px] text-gray-440 font-mono">Bank IFSC Route Code</span>
                                <div className="flex items-center gap-1.5 font-mono">
                                  <span className="font-bold text-[#00FFCC] uppercase">{t.bankDetails.ifscCode}</span>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      handleCopyText(t.id + '-ifsc', t.bankDetails?.ifscCode || '');
                                    }}
                                    className="p-1 hover:text-[#00FFCC] text-gray-450 transition-colors"
                                  >
                                    {copiedTxId === t.id + '-ifsc' ? (
                                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                                    ) : (
                                      <Copy className="w-3.5 h-3.5" />
                                    )}
                                  </button>
                                </div>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              });
            })()}
          </div>

          {/* Fully Zoomable screen overlay */}
          {activeZoomImage && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 p-4 backdrop-blur-md animate-fade-in" onClick={() => setActiveZoomImage(null)}>
              <button
                type="button"
                onClick={() => setActiveZoomImage(null)}
                className="absolute top-4 right-4 p-3.5 bg-[#FF4500] hover:bg-orange-600 border border-orange-500 text-white rounded-full cursor-pointer transition-all shadow-xl z-50 animate-bounce"
              >
                <X className="w-6 h-6" />
              </button>
              <div 
                className="relative max-w-4xl max-h-[90vh] overflow-auto rounded-3xl border-2 border-emerald-500/25 shadow-2xl p-2 bg-[#090D16] flex flex-col items-center"
                onClick={(e) => e.stopPropagation()}
              >
                <img
                  src={activeZoomImage}
                  alt="High Resolution Audit reference receipt"
                  className="max-h-[82vh] max-w-full object-contain rounded-2xl select-all"
                />
                <div className="mt-3 text-center">
                  <span className="text-[10px] font-mono text-[#00FFCC] uppercase tracking-widest font-bold">
                    🔍 HIGH-FIDELITY AUDIT OVERLAY SCREENSHOT (CLICK RED X TO RETURN)
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Tab Content 5: Banners Management */}
      {activeTab === 'banners' && (
        <div className="space-y-4 font-mono">
          <div className="bg-[#13192B]/50 p-4 rounded-xl border border-[#222D4A] space-y-1 text-left">
            <h3 className="font-display font-medium text-xs uppercase text-[#00FFCC]">Promotional Banners Manager</h3>
            <p className="text-[10px] text-gray-400">
              Manage the slide cards displayed to players dynamically at the top of the Home Dashboard. Change URLs, titles, and active statuses.
            </p>
          </div>

          {/* Official WhatsApp Group Link Form */}
          <form onSubmit={handleSaveWhatsAppLink} className="bg-[#13192B] border border-[#222D4A] rounded-2.5xl p-5 space-y-4 shadow-xl text-left font-mono">
            <h3 className="font-display font-black text-xs uppercase text-[#25D366] flex items-center gap-1.5 font-bold">
              <MessageCircle className="w-4 h-4 text-[#25D366]" />
              <span>Configure WhatsApp Group Link</span>
            </h3>

            <div className="space-y-1.5">
              <label className="text-[9px] font-mono text-gray-400 uppercase font-black">Official Group Link</label>
              <input
                type="text"
                placeholder="e.g. https://chat.whatsapp.com/GamerLobbyGroup11"
                value={whatsappGroupUrl}
                onChange={(e) => setWhatsappGroupUrl(e.target.value)}
                className="w-full bg-[#0A0E17] border border-[#222D4A] rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-[#25D366] placeholder-gray-650"
              />
              <p className="text-[8px] text-gray-500 font-mono leading-normal">
                Setting this URL enables a dedicated 🟢 <strong>Official WhatsApp Group</strong> instant join button inside all player Profile dashboards under their badge cards!
              </p>
            </div>

            <div className="flex justify-between items-center pt-2 border-t border-[#222D4A]/55">
              <span className="text-[9px] font-mono text-[#25D366] font-bold">
                {whatsappGroupUrlSaved && "✨ WHATSAPP GROUP LINK SYNCHRONIZED!"}
              </span>
              <button
                type="submit"
                className="px-4 py-2 bg-[#25D366]/20 hover:bg-[#25D366]/35 border border-[#25D366]/50 text-white rounded-xl text-[10px] font-mono uppercase font-black tracking-wider transition-all cursor-pointer shadow-[0_0_15px_rgba(37,211,102,0.15)]"
              >
                Save WhatsApp Link
              </button>
            </div>
          </form>

          <form onSubmit={handleCreateBanner} className="bg-[#13192B] border border-[#222D4A] rounded-2.5xl p-5 space-y-4 shadow-xl text-left">
            <h3 className="font-display font-black text-xs uppercase text-[#00FFCC] flex items-center gap-1.5">
              <Plus className="w-4 h-4" />
              <span>Create Dynamic Promo Banner</span>
            </h3>

            <div className="space-y-1.5">
              <label className="text-[9px] font-mono text-gray-400 uppercase font-black">Banner Title (Optional)</label>
              <input
                type="text"
                placeholder="e.g. UPI Withdrawals Processed Instantly within 10 Mins!"
                value={newBannerTitle}
                onChange={(e) => setNewBannerTitle(e.target.value)}
                className="w-full bg-[#0A0E17] border border-[#222D4A] rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-[#FF4500] placeholder-gray-650"
              />
            </div>

            <div className="space-y-1.5">
              <div className="flex justify-between items-center">
                <label className="text-[9px] font-mono text-gray-400 uppercase font-black">Banner Image (URL or Upload File)</label>
                <label className="text-[9px] font-mono text-[#00FFCC] font-bold cursor-pointer hover:underline flex items-center gap-1">
                  <Upload className="w-3 h-3" />
                  <span>Upload local JPG/PNG</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleBannerImageUpload}
                    className="hidden"
                  />
                </label>
              </div>
              <input
                type="text"
                placeholder="e.g. https://images.unsplash.com/... or base64"
                value={newBannerImageUrl}
                onChange={(e) => setNewBannerImageUrl(e.target.value)}
                className="w-full bg-[#0A0E17] border border-[#222D4A] rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-[#FF4500] placeholder-gray-650"
              />
              {isCompressingBanner && (
                <span className="text-[9px] font-mono text-[#00FFCC] animate-pulse block">⚡ Optimizing photo sizes...</span>
              )}
            </div>

            <div className="space-y-1.5">
              <label className="text-[9px] font-mono text-gray-400 uppercase font-black">Redirect Link URL (Optional)</label>
              <input
                type="text"
                placeholder="e.g. uptracker or telegram channel link"
                value={newBannerLinkUrl}
                onChange={(e) => setNewBannerLinkUrl(e.target.value)}
                className="w-full bg-[#0A0E17] border border-[#222D4A] rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-[#FF4500] placeholder-gray-650"
              />
            </div>

            {/* Quick Preview Area */}
            {newBannerImageUrl && (
              <div className="space-y-1.5 bg-[#0A0E17] p-2.5 rounded-xl border border-[#222D4A]/50">
                <span className="text-[8px] font-mono text-gray-500 uppercase block pl-1">Live Banner Layout Preview:</span>
                <div className="relative aspect-[21/9] rounded-lg overflow-hidden border border-[#222D4A]">
                  <img src={newBannerImageUrl} alt="Preview" className="w-full h-full object-cover" />
                  {newBannerTitle && (
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent flex items-end p-2.5">
                      <p className="text-[10px] font-display font-medium text-white line-clamp-2 leading-snug">{newBannerTitle}</p>
                    </div>
                  )}
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={isCompressingBanner}
              className="w-full bg-gradient-to-r from-[#FF4500] to-[#C60000] text-white font-display font-black text-xs uppercase tracking-wider py-3.5 rounded-xl cursor-pointer disabled:opacity-50"
            >
              Publish Dynamic Banner Slot
            </button>
          </form>

          {/* Active / Inactive promo banner list */}
          <div className="space-y-3 pt-2">
            <h3 className="text-xs font-mono text-gray-455 uppercase pl-1 font-bold">Existing active slides ({banners.length})</h3>

            {banners.map((b) => (
              <div key={b.id} className="bg-[#13192B] border border-[#222D4A] rounded-2xl p-4.5 space-y-3.5 text-left">
                <div className="relative aspect-[21/9] rounded-xl overflow-hidden border border-[#222D4A]/50 bg-[#0A0E17]">
                  <img src={b.imageUrl} alt={b.title || 'Promo'} className="w-full h-full object-cover" />
                  {b.title && (
                    <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent flex items-end p-3">
                      <p className="text-[10.5px] font-display font-medium text-white leading-snug line-clamp-2">{b.title}</p>
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-between text-xs font-mono border-t border-[#222D4A]/50 pt-2.5">
                  <span className="text-gray-500 text-[10px] uppercase truncate max-w-[150px]">
                    ID: {b.id}
                  </span>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleToggleBanner(b.id)}
                      className={`px-3 py-1 rounded-lg text-[9px] font-bold uppercase transition-all tracking-wider border cursor-pointer ${
                        b.active
                          ? 'bg-emerald-950/20 text-[#00FFCC] border-emerald-500/40'
                          : 'bg-gray-850 text-gray-400 border-gray-700'
                      }`}
                    >
                      {b.active ? '● Active' : '○ Inactive'}
                    </button>
                    <button
                      onClick={() => handleDeleteBanner(b.id)}
                      className="p-1 px-2.5 bg-red-950/20 text-red-500 rounded-lg border border-red-900/40 hover:bg-red-900/30 transition-all cursor-pointer"
                    >
                      <Trash className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}

            {banners.length === 0 && (
              <div className="text-xs text-gray-500 text-center font-mono py-10">No banners published yet.</div>
            )}
          </div>
        </div>
      )}

      {/* Tab Content 6: Global Rulebook Configuration */}
      {activeTab === 'rules' && (
        <div className="space-y-5 animate-fade-in text-left">
          <div className="bg-[#13192B]/50 p-5 rounded-2xl border border-[#222D4A] space-y-2 leading-relaxed">
            <h3 className="font-display font-black text-sm uppercase text-[#00FFCC] tracking-widest flex items-center gap-2 pl-0.5 animate-pulse">
              <ShieldAlert className="w-6 h-6 text-[#00FFCC]" />
              <span>Global Rulebook Customizer</span>
            </h3>
            <p className="text-xs text-gray-300 leading-relaxed font-semibold">
              Draft any official rules, guidelines, warnings, announcements or policies. This is synchronized globally and printed instantly inside the **VALENT Rules Section** visible to every active player. This writes directly to the Firestore collection <code className="text-[#00FFCC] font-mono bg-black/40 px-2 py-1 rounded font-black text-xs">valent_global_configurations</code>.
            </p>
          </div>

          <div className="bg-[#13192B] border border-[#222D4A] rounded-2.5xl p-6 space-y-5 shadow-2xl">
            <div className="space-y-3">
              <label className="block text-xs font-mono text-gray-300 uppercase tracking-widest pl-1 font-black">
                Official Rulebook Text Paragraphs (Unlimited length)
              </label>
              <textarea
                value={globalRulesText}
                onChange={(e) => setGlobalRulesText(e.target.value)}
                placeholder={`⚠️ TYPE CRITICAL LEAGUE RULES HERE...
• Use double returns to start a new paragraph.
• Text will be rendered with exact layout spacing and compliance parameters on all players dashboards.`}
                rows={14}
                className="w-full bg-[#0A0E17] border border-[#222D4A] rounded-2xl px-5 py-4 text-sm text-white font-mono placeholder-gray-600 focus:outline-none focus:border-[#00FFCC] transition-all resize-y leading-relaxed font-medium"
              />
            </div>

            <button
              onClick={() => {
                saveGlobalRules(globalRulesText);
                setStatusMsg("⚡ Global Rulebook updated successfully! Broadcasting Live...");
                setTimeout(() => setStatusMsg(null), 3000);
              }}
              className="w-full py-5 bg-gradient-to-r from-[#00FFCC]/20 to-[#00E5FF]/20 text-[#00FFCC] border-2 border-[#00FFCC]/35 hover:from-[#00FFCC]/30 hover:to-[#00E5FF]/30 hover:border-[#00FFCC]/65 rounded-2xl font-display font-black text-xs uppercase tracking-widest transition-all cursor-pointer flex items-center justify-center gap-2 shadow-[0_0_25px_rgba(0,255,204,0.08)]"
            >
              <Check className="w-5 h-5" />
              <span>Save and Broadcast Rules Globally</span>
            </button>
          </div>
        </div>
      )}

      {/* Tab Content 7: Live Customer Support Center */}
      {activeTab === 'support' && (
        <div className="space-y-5 animate-fade-in text-left">
          <div className="bg-[#13192B]/50 p-5 rounded-2xl border border-[#222D4A] space-y-2 leading-relaxed">
            <h3 className="font-display font-black text-sm uppercase text-[#00FFCC] tracking-widest flex items-center gap-2 pl-0.5 animate-pulse">
              <MessageSquare className="w-6 h-6 text-[#00FFCC]" />
              <span>Tactical Helpdesk & Support Chats</span>
            </h3>
            <p className="text-xs text-gray-300 leading-relaxed font-semibold">
              Communicate with active players regarding game disputes, wallet balances, refunds or rule consultations. Writes to Firestore collection <code className="text-[#00FFCC] font-mono bg-black/40 px-2 py-1 rounded font-black text-xs">valent_support_messages</code>.
            </p>
          </div>

          <div className="bg-[#13192B] border border-[#222D4A] rounded-2.5xl p-5 shadow-2xl relative overflow-hidden min-h-[500px] flex flex-col md:flex-row gap-5">
            {/* Ambient background glow inside cards */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-[#00FFCC]/5 rounded-full blur-[80px] pointer-events-none" />

            {/* Left Column / Rail: Chats list grouped by User */}
            <div className={`w-full md:w-[240px] border-r border-[#222D4A]/50 pr-0 md:pr-4 flex flex-col shrink-0 ${selectedChatUserId ? 'hidden md:flex' : 'flex'}`}>
              <h4 className="font-mono text-[10px] text-gray-550 uppercase font-black tracking-widest pb-2.5 border-b border-[#222D4A]/40 mb-3 pl-1">
                Active Player Chats ({Array.from(new Set(supportMessages.map(m => m.userId))).length})
              </h4>

              <div className="flex-1 overflow-y-auto space-y-2 max-h-[440px] pr-1">
                {Array.from(new Set(supportMessages.map(m => m.userId))).length === 0 ? (
                  <div className="text-[11px] font-mono text-gray-500 text-center py-10 leading-normal">
                    No active support dialogues found.
                  </div>
                ) : (
                  Array.from(new Set(supportMessages.map(m => m.userId))).map(userId => {
                    const userMsgs = supportMessages.filter(m => m.userId === userId);
                    const lastMsg = userMsgs[userMsgs.length - 1];
                    const unreadCount = userMsgs.filter(m => m.senderId !== 'admin' && !m.readByAdmin).length;
                    
                    // Locate associated player info for user details
                    const pInfo = users.find(u => u.id === userId);
                    const displayName = pInfo ? pInfo.username : (lastMsg?.username || 'Esports Player');
                    const isActive = selectedChatUserId === userId;

                    return (
                      <button
                        key={userId}
                        onClick={() => setSelectedChatUserId(userId)}
                        className={`w-full text-left p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-2.5 relative group ${
                          isActive
                            ? 'bg-gradient-to-r from-teal-950/40 via-emerald-950/20 to-teal-950/40 border-[#00FFCC]/55 text-white'
                            : 'bg-[#0A0E17] border-[#222D4A] hover:border-[#222D4A]/95 hover:bg-[#13192B] text-gray-300'
                        }`}
                      >
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5 min-w-0">
                            <span className="text-xs font-display font-black uppercase tracking-wide truncate block group-hover:text-white transition-colors">
                              {displayName}
                            </span>
                            {pInfo?.is_admin && (
                              <span className="text-[7.5px] scale-90 bg-[#00FFCC]/10 text-[#00FFCC] border border-[#00FFCC]/20 px-1.5 py-0.2 rounded font-mono font-bold uppercase shrink-0">ADMIN</span>
                            )}
                          </div>
                          <span className="text-[9px] font-mono text-gray-500 block truncate mt-0.5">
                            {lastMsg?.text || 'No messages'}
                          </span>
                        </div>

                        {/* Unread dot count indicator badge */}
                        {unreadCount > 0 && (
                          <span className="h-4 w-4 rounded-full bg-[#00FFCC] text-black text-[9px] font-black flex items-center justify-center shrink-0 shadow animate-pulse">
                            {unreadCount}
                          </span>
                        )}
                      </button>
                    );
                  })
                )}
              </div>
            </div>

            {/* Right Column/Panel: Conversational Room */}
            <div className={`flex-1 flex flex-col justify-between ${!selectedChatUserId ? 'hidden md:flex justify-center items-center opacity-85' : 'flex'}`}>
              {selectedChatUserId ? (
                (() => {
                  const targetUser = users.find(u => u.id === selectedChatUserId);
                  const chatUserMsgs = supportMessages.filter(m => m.userId === selectedChatUserId);
                  const displayName = targetUser ? targetUser.username : 'Esports Player';

                  return (
                    <div className="flex-1 flex flex-col h-full justify-between min-h-[440px]">
                      {/* Chat Room Top bar */}
                      <div className="flex items-center justify-between pb-3 border-b border-[#222D4A]/55 shrink-0">
                        <div className="flex items-center gap-3">
                          {/* Close/Back context on mobile */}
                          <button
                            onClick={() => setSelectedChatUserId(null)}
                            className="p-1.5 bg-[#0A0E17] border border-[#222D4A] hover:bg-teal-950/10 rounded-lg text-gray-400 hover:text-white block md:hidden cursor-pointer"
                          >
                            <ArrowLeft className="w-4 h-4" />
                          </button>
                          
                          <div className="text-left">
                            <h3 className="font-display font-black uppercase text-white tracking-wide text-xs flex items-center gap-1.5">
                              <span>Chat with {displayName}</span>
                              <span className="w-1.5 h-1.5 bg-[#00FFCC] rounded-full animate-ping" />
                            </h3>
                            <span className="text-[9px] font-mono text-gray-500 block mt-0.5">
                              ID: {selectedChatUserId.substring(0,14).toUpperCase()} • PH: +91 {targetUser?.phone || 'N/A'}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          {/* Shortcut command to jump straight to credits manager */}
                          <button
                            onClick={() => {
                              setSelectedAdjUserId(selectedChatUserId);
                              setActiveTab('financials');
                              setStatusMsg(`⚡ Transferred user context directly to manual balances updater!`);
                              setTimeout(() => setStatusMsg(null), 3500);
                            }}
                            className="bg-teal-950/30 border border-teal-500/35 hover:border-teal-400 text-[#00FFCC] font-mono text-[8.5px] font-extrabold uppercase px-2.5 py-1.5 rounded-lg hover:bg-teal-950/60 transition-all cursor-pointer shadow-sm"
                          >
                            💰 CREDIT WALLET
                          </button>
                          
                          <button
                            onClick={() => setSelectedChatUserId(null)}
                            className="p-1 px-2.5 py-1 text-[9px] bg-[#0A0E17] border border-[#222D4A] text-gray-400 hover:text-white rounded-lg cursor-pointer"
                          >
                            CLOSE
                          </button>
                        </div>
                      </div>

                      {/* Chat Message Box container */}
                      <div className="flex-1 overflow-y-auto my-4 space-y-3.5 pr-1 max-h-[310px]">
                        {chatUserMsgs.length === 0 ? (
                          <div className="text-center text-xs text-gray-500 font-mono py-16">No messages in this chat.</div>
                        ) : (
                          chatUserMsgs.map((m) => {
                            const isAdmin = m.senderId === 'admin';
                            return (
                              <div
                                key={m.id}
                                className={`flex flex-col ${isAdmin ? 'items-end' : 'items-start'} max-w-[85%] ${
                                  isAdmin ? 'ml-auto' : 'mr-auto'
                                }`}
                              >
                                <span className="text-[8px] font-mono text-gray-500 mb-0.5 px-0.5 uppercase tracking-wide">
                                  {m.senderName} • {new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                </span>
                                <div
                                  className={`rounded-2xl px-3.5 py-2.5 text-[11.5px] font-sans leading-relaxed break-words font-medium text-left ${
                                    isAdmin
                                      ? 'bg-gradient-to-r from-teal-700 to-emerald-600 text-white rounded-tr-none shadow-md'
                                      : 'bg-[#0A0E17] border border-[#222D4A] text-gray-200 rounded-tl-none font-semibold'
                                  }`}
                                >
                                  {m.imageUrl && (
                                    <div 
                                      onClick={() => setAdminZoomImage(m.imageUrl || null)} 
                                      className="mb-1.5 rounded-xl overflow-hidden border border-[#222D4A]/60 max-w-[190px] cursor-pointer hover:opacity-95 active:scale-95 transition-all text-center mx-auto"
                                    >
                                      <img 
                                        src={m.imageUrl} 
                                        alt="Chat attachment" 
                                        className="w-full h-auto object-cover max-h-36" 
                                        referrerPolicy="no-referrer"
                                      />
                                    </div>
                                  )}
                                  {m.text}
                                </div>
                              </div>
                            );
                          })
                        )}
                        <div ref={adminChatEndRef} />
                      </div>

                      {/* Send reply message Box */}
                      <form onSubmit={handleAdminSendReply} className="pt-3 border-t border-[#222D4A]/50 flex flex-col gap-2 shrink-0">
                        {adminReplyImage && (
                          <div className="relative bg-[#0A0E17]/95 border border-[#222D4A] p-2 rounded-xl flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <img src={adminReplyImage} className="w-10 h-10 object-cover rounded-lg border border-[#222D4A]" referrerPolicy="no-referrer" />
                              <span className="text-[10px] text-gray-400 font-mono">Photo Attachment Selected</span>
                            </div>
                            <button
                              type="button"
                              onClick={() => setAdminReplyImage('')}
                              className="p-1.5 bg-[#13192B] border border-[#222D4A] rounded-lg text-gray-400 hover:text-red-400 transition-colors"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}

                        <div className="flex items-center gap-2">
                          <input
                            type="file"
                            ref={adminChatFileInputRef}
                            onChange={handleAdminSupportImageSelect}
                            accept="image/*"
                            className="hidden"
                          />
                          <button
                            type="button"
                            disabled={isAdminCompressing}
                            onClick={() => adminChatFileInputRef.current?.click()}
                            className="p-3 bg-[#13192B] border border-[#222D4A] text-gray-400 hover:text-white rounded-xl transition-all cursor-pointer shrink-0 hover:scale-[1.03] active:scale-[0.97] flex items-center justify-center"
                          >
                            {isAdminCompressing ? (
                              <Loader2 className="w-4 h-4 animate-spin text-[#00FFCC]" />
                            ) : (
                              <ImageIcon className="w-4 h-4" />
                            )}
                          </button>

                          <input
                            type="text"
                            placeholder={`Reply to ${displayName}...`}
                            value={adminReplyText}
                            onChange={(e) => setAdminReplyText(e.target.value)}
                            maxLength={500}
                            className="flex-1 bg-[#0A0E17] border border-[#222D4A] rounded-xl px-4 py-3 text-xs text-white placeholder-gray-600 focus:outline-none focus:border-[#00FFCC]"
                          />
                          <button
                            type="submit"
                            disabled={!adminReplyText.trim() && !adminReplyImage}
                            className="p-3 bg-gradient-to-r from-[#00FFCC]/20 to-[#00E5FF]/20 text-[#00FFCC] border border-[#00FFCC]/40 disabled:border-[#222D4A] disabled:text-gray-600 disabled:from-transparent rounded-xl transition-all cursor-pointer shadow-md shrink-0 flex items-center justify-center hover:scale-[1.03] active:scale-[0.97]"
                          >
                            <Send className="w-4 h-4" />
                          </button>
                        </div>
                      </form>
                    </div>
                  );
                })()
              ) : (
                <div className="flex h-full flex-col items-center justify-center text-center p-6 space-y-4 py-20">
                  <div className="w-14 h-14 rounded-full bg-[#0A0E17] border border-[#222D4A] flex items-center justify-center text-gray-500 animate-pulse">
                    <MessageSquare className="w-7 h-7" />
                  </div>
                  <div className="space-y-1">
                    <h4 className="font-display font-black text-xs uppercase tracking-wide text-white">No conversation selected</h4>
                    <p className="text-[10px] text-gray-400 font-sans leading-relaxed max-w-[280px] mx-auto">
                      Click any registered player chat on the left panel queue to review client dispute tickets and live message them instantly.
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 🔮 CUSTOM BILLION DOLLAR DELETION MATCH CONFIRMATION MODAL */}
      {deleteMatchConfirmation && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
          <div className="bg-[#0A0E17] border border-red-500/30 rounded-3xl p-6 max-w-sm w-full space-y-5 shadow-[0_0_50px_rgba(239,68,68,0.15)] relative overflow-hidden text-center">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-red-500 via-orange-500 to-red-500" />
            
            <div className="space-y-2">
              <div className="inline-flex p-3 bg-red-500/10 border border-red-500/20 rounded-2xl mb-1 text-red-500 animate-pulse">
                <Trash className="w-8 h-8" />
              </div>
              <h3 className="text-md font-display font-black uppercase text-white tracking-wide">
                Confirm Lobby Deletion?
              </h3>
              <p className="text-[10px] font-mono text-gray-400 leading-relaxed px-2">
                Are you absolutely sure you want to permanently delete the custom esports lobby:
                <span className="block text-red-500 font-extrabold mt-2 font-mono uppercase bg-red-955/25 border border-red-900/40 py-2 px-2.5 rounded-lg text-xs leading-tight">
                  {deleteMatchConfirmation.matchTitle}
                </span>
                <span className="block text-[8px] text-gray-500 mt-2 leading-relaxed">
                  All registered tournament slots and user positions will be permanently wiped out. This action is terminal and irreversible!
                </span>
              </p>
            </div>
            
            <div className="flex gap-3 pt-2">
              <button
                onClick={handleCancelDeleteMatch}
                className="flex-1 py-3 bg-[#13192B] border border-[#222D4A] hover:bg-[#1C253F] hover:text-white rounded-xl text-xs font-mono font-bold uppercase transition-all cursor-pointer"
              >
                No, Keep
              </button>
              <button
                onClick={handleConfirmDeleteMatch}
                className="flex-1 py-3 bg-gradient-to-r from-red-600 to-red-500 border border-red-500 hover:from-red-500 hover:to-red-400 text-white rounded-xl text-xs font-display font-black uppercase tracking-wider transition-all cursor-pointer shadow-[0_0_15px_rgba(239,68,68,0.3)]"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 🔮 CUSTOM BILLION DOLLAR DELETION BANNER CONFIRMATION MODAL */}
      {deleteBannerConfirmation && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
          <div className="bg-[#0A0E17] border border-red-500/30 rounded-3xl p-6 max-w-sm w-full space-y-5 shadow-[0_0_50px_rgba(239,68,68,0.15)] relative overflow-hidden text-center">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-red-500 via-orange-500 to-red-500" />
            
            <div className="space-y-2">
              <div className="inline-flex p-3 bg-red-500/10 border border-red-500/20 rounded-2xl mb-1 text-red-500 animate-pulse">
                <Trash className="w-8 h-8" />
              </div>
              <h3 className="text-md font-display font-black uppercase text-white tracking-wide">
                Confirm Banner Deletion?
              </h3>
              <p className="text-[10px] font-mono text-gray-400 leading-relaxed px-2">
                Are you absolutely sure you want to permanently delete this promotional banner:
                <span className="block text-red-500 font-extrabold mt-2 font-mono uppercase bg-red-955/25 border border-red-900/40 py-2 px-2.5 rounded-lg text-xs leading-tight">
                  {deleteBannerConfirmation.bannerTitle}
                </span>
                <span className="block text-[8px] text-gray-500 mt-2 leading-relaxed">
                  This promo item will be immediately purged across all active devices in the lobby carousel slider.
                </span>
              </p>
            </div>
            
            <div className="flex gap-3 pt-2">
              <button
                onClick={handleCancelDeleteBanner}
                className="flex-1 py-3 bg-[#13192B] border border-[#222D4A] hover:bg-[#1C253F] hover:text-white rounded-xl text-xs font-mono font-bold uppercase transition-all cursor-pointer"
              >
                No, Keep
              </button>
              <button
                onClick={handleConfirmDeleteBanner}
                className="flex-1 py-3 bg-gradient-to-r from-red-650 to-red-550 border border-red-500 hover:from-red-600 hover:to-red-500 text-white rounded-xl text-xs font-display font-black uppercase tracking-wider transition-all cursor-pointer shadow-[0_0_15px_rgba(239,68,68,0.3)]"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 🔮 CUSTOM SECURE TRANSACTION AUDIT CONFIRMATION MODAL */}
      {txAuditConfirm && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-fade-in text-left">
          <div className="bg-[#0A0E17] border border-[#222D4A] rounded-3xl p-6 max-w-sm w-full space-y-5 shadow-[0_0_50px_rgba(0,0,0,0.8)] relative overflow-hidden">
            <div className={`absolute top-0 left-0 w-full h-1 ${
              txAuditConfirm.action === 'approved' 
                ? 'bg-gradient-to-r from-emerald-500 via-teal-500 to-[#00FFCC]' 
                : 'bg-gradient-to-r from-rose-500 via-pink-500 to-rose-500'
            }`} />

            <div className="space-y-3">
              <div className={`inline-flex p-3 rounded-2xl mb-1 ${
                txAuditConfirm.action === 'approved'
                  ? 'bg-emerald-500/10 border border-emerald-500/25 text-emerald-400 animate-pulse'
                  : 'bg-rose-500/10 border border-rose-500/25 text-rose-500'
              }`}>
                {txAuditConfirm.action === 'approved' ? (
                  <Check className="w-8 h-8 text-emerald-400" />
                ) : (
                  <X className="w-8 h-8 text-rose-500" />
                )}
              </div>
              
              <h3 className="text-sm font-display font-black uppercase text-white tracking-wide leading-tight">
                Confirm Transaction Audit?
              </h3>
              
              <p className="text-[10.5px] font-mono text-gray-400 leading-relaxed">
                Are you sure you want to <span className={txAuditConfirm.action === 'approved' ? 'text-emerald-400 font-bold' : 'text-rose-500 font-bold'}>{txAuditConfirm.action.toUpperCase()}</span> the following {txAuditConfirm.type} request?
              </p>

              <div className="bg-[#121829] border border-[#222D4A] p-3 rounded-xl font-mono text-[10px] space-y-1">
                <div>
                  <span className="text-gray-500">Player:</span> <span className="text-[#00FFCC] font-bold">@{txAuditConfirm.username}</span>
                </div>
                <div>
                  <span className="text-gray-500">Amount:</span> <span className="text-white font-bold text-xs">₹{txAuditConfirm.amount.toFixed(2)}</span>
                </div>
                {txAuditConfirm.withdrawMethod && (
                  <div>
                    <span className="text-gray-500">Method:</span> <span className="text-gray-300 font-bold uppercase">{txAuditConfirm.withdrawMethod}</span>
                  </div>
                )}
              </div>

              {txAuditConfirm.action === 'rejected' && txAuditConfirm.type === 'withdrawal' && (
                <p className="text-[8px] text-amber-500 font-mono leading-tight bg-amber-500/5 border border-amber-500/15 p-2 rounded-lg">
                  💡 Note: Rejecting a withdrawal automatically refunds the exact cash sums instantly back into the player's primary account balances. No manual correction required!
                </p>
              )}
            </div>

            <div className="flex gap-3 pt-2">
              <button
                onClick={() => setTxAuditConfirm(null)}
                className="flex-1 py-3 bg-[#13192B] border border-[#222D4A] hover:bg-[#1C253F] hover:text-white rounded-xl text-[10px] font-mono font-black uppercase transition-all cursor-pointer"
              >
                No, Back
              </button>
              <button
                onClick={commitApproveTransaction}
                className={`flex-1 py-3 border text-[10px] font-display font-black uppercase tracking-wider transition-all cursor-pointer shadow-md text-white ${
                  txAuditConfirm.action === 'approved'
                    ? 'bg-gradient-to-r from-emerald-600 to-teal-600 border-emerald-500 hover:from-emerald-500 hover:to-teal-500'
                    : 'bg-gradient-to-r from-rose-600 to-rose-500 border-rose-500 hover:from-rose-500 hover:to-rose-450'
                }`}
              >
                Yes, Commit
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Zoom Lightbox Modal */}
      {adminZoomImage && (
        <div 
          className="fixed inset-0 bg-black/95 flex items-center justify-center p-4 z-[120] animate-fade-in"
          onClick={() => setAdminZoomImage(null)}
        >
          <div className="absolute top-4 right-4 z-50">
            <button 
              onClick={() => setAdminZoomImage(null)}
              className="p-2.5 bg-gray-950/90 hover:bg-gray-900 border border-[#222D4A] rounded-full text-white cursor-pointer transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          <img 
            src={adminZoomImage} 
            alt="Magnified Attachment" 
            className="max-w-full max-h-[85vh] object-contain rounded-xl shadow-2xl border border-[#222D4A]"
            referrerPolicy="no-referrer"
            onClick={(e) => e.stopPropagation()} 
          />
        </div>
      )}

      {/* 🔮 CUSTOM SECURE WARNING OVERLAY POPUP */}
      {txAlertMessage && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/95 backdrop-blur-md animate-fade-in text-left">
          <div className="bg-[#0A0E17] border border-amber-500/20 rounded-3xl p-6 max-w-sm w-full space-y-5 shadow-[0_0_50px_rgba(245,158,11,0.1)] relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-500 animate-pulse" />
            
            <div className="space-y-3 text-center">
              <span className="text-2xl block animate-bounce">⚠️</span>
              <h3 className="text-xs font-display font-black uppercase text-amber-500 tracking-wide">
                Validation Warning
              </h3>
              <p className="text-[10px] font-mono text-gray-400 leading-relaxed text-center px-1 font-bold">
                {txAlertMessage}
              </p>
            </div>

            <div>
              <button
                onClick={() => setTxAlertMessage(null)}
                className="w-full py-3 bg-[#13192B] border border-[#222D4A] hover:bg-black text-amber-500 rounded-xl text-xs font-mono font-black uppercase transition-all cursor-pointer shadow"
              >
                Dismiss & Correct
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
