import React, { useState, useEffect, useRef } from 'react';
import { Match, MatchPlayer, MatchSubmission, MatchChatMsg, User } from '../types';
import { getCurrentUser, setCurrentUser, getMatches, saveMatches, getTransactions, saveTransactions, getUsers, saveUsers, joinMatchAtomic, reserveTeammateAtomic } from '../db';
import { isConfigured } from '../firebase';
import {
  ArrowLeft,
  ShieldCheck,
  Lock,
  Unlock,
  Copy,
  Upload,
  Send,
  MessageSquare,
  Coins,
  CheckCircle,
  HelpCircle,
  Trophy,
  Users,
  Clock,
  Sparkles,
  AlertTriangle,
  Gamepad2,
  TrendingUp
} from 'lucide-react';

interface MatchWorkspaceProps {
  match: Match;
  onBack: () => void;
  userId: string;
  onNavigateToWallet: () => void;
}

export default function MatchWorkspace({ match, onBack, userId, onNavigateToWallet }: MatchWorkspaceProps) {
  const [currentMatch, setCurrentMatch] = useState<Match>(match);
  const [currentUser, setLocalCurrentUser] = useState<User | null>(() => getCurrentUser());
  const [ignInput, setIgnInput] = useState<string>(currentUser?.ign || '');
  const [levelInput, setLevelInput] = useState<string>('');
  const [copiedRoomId, setCopiedRoomId] = useState(false);
  const [copiedPass, setCopiedPass] = useState(false);
  const [showModal, setShowModal] = useState<'none' | 'insufficient' | 'confirm'>('none');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [tick, setTick] = useState<number>(0);

  // New Team vs Team & Reservation state variables
  const [selectedTeamForVsMatch, setSelectedTeamForVsMatch] = useState<'A' | 'B'>('A');
  const [showReserveModal, setShowReserveModal] = useState<boolean>(false);
  const [teammateIGN, setTeammateIGN] = useState<string>('');
  const [teammateLevel, setTeammateLevel] = useState<string>('');
  
  // Alert for admin reassigning team
  const [adminReassignAlert, setAdminReassignAlert] = useState<{
    show: boolean;
    oldTeam: string;
    newTeam: string;
    newPosition: number;
  } | null>(null);

  // Read stored team representation to verify updates from admin side
  const [lastAssignedTeam, setLastAssignedTeam] = useState<string | null>(() => {
    return localStorage.getItem(`valent_last_team_${match.id}_${userId}`);
  });

  const getFormatMaxPerTeam = (format: string): number => {
    if (format === '1v1') return 1;
    if (format === '2v2') return 2;
    if (format === '4v4' || format === 'teamvsteam4v4') return 4;
    if (format === '6v6' || format === 'teamvsteam6v6') return 6;
    return 24; // BR
  };

  const isTeamVsTeam = currentMatch.format_type === 'teamvsteam4v4' || currentMatch.format_type === 'teamvsteam6v6';
  const maxPerTeam = getFormatMaxPerTeam(currentMatch.format_type);

  // Sync state dynamically from database updates
  useEffect(() => {
    const reload = () => {
      const allMatches = getMatches();
      const updated = allMatches.find(m => m.id === match.id);
      if (updated) {
        setCurrentMatch(updated);

        // Notify player if admin assigned them to a new team
        const playerSlot = updated.players.find(p => p.userId === userId);
        if (playerSlot) {
          const stored = localStorage.getItem(`valent_last_team_${match.id}_${userId}`);
          if (!stored) {
            // First time detecting user in lobby: seed initial assignment without alert
            localStorage.setItem(`valent_last_team_${match.id}_${userId}`, playerSlot.team);
          } else if (stored !== playerSlot.team) {
            // Player already existed in this lobby, and admin moved them. Show alert!
            setAdminReassignAlert({
              show: true,
              oldTeam: stored,
              newTeam: playerSlot.team,
              newPosition: playerSlot.position || 1
            });
            localStorage.setItem(`valent_last_team_${match.id}_${userId}`, playerSlot.team);
          }
          setLastAssignedTeam(playerSlot.team);
        }
      }
      setLocalCurrentUser(getCurrentUser());
    };
    window.addEventListener('valent_db_update', reload);

    const timerInterval = setInterval(() => {
      setTick(t => t + 1);

      // Auto-room reveal transition evaluator inside active Match Workspace
      const currentMatches = getMatches();
      const matchInDb = currentMatches.find(m => m.id === match.id);
      if (matchInDb && matchInDb.status === 'PENDING_START' && matchInDb.roomId && matchInDb.roomPassword && matchInDb.credentialsRevealTime) {
        const revealTimeMs = new Date(matchInDb.credentialsRevealTime).getTime();
        if (Date.now() >= revealTimeMs) {
          const updatedMatches = currentMatches.map(m => {
            if (m.id === match.id) {
              return {
                ...m,
                status: 'ROOM_READY' as const
              };
            }
            return m;
          });
          saveMatches(updatedMatches);
          window.dispatchEvent(new Event('valent_db_update'));
        }
      }
    }, 1000);

    return () => {
      window.removeEventListener('valent_db_update', reload);
      clearInterval(timerInterval);
    };
  }, [match.id, userId]);

  // Is user registered?
  const isJoined = currentMatch.players.some(p => p.userId === userId);
  const userSlot = currentMatch.players.find(p => p.userId === userId);

  // Balance calculator (Deposit + Winnings)
  const userCombinedBalance = currentUser
    ? Math.max(0, currentUser.wallet.deposit) + Math.max(0, currentUser.wallet.winnings)
    : 0;

  // Handle register and payment deduction (Validation & Trigger Popup)
  const handleJoinMatch = () => {
    if (!currentUser) return;

    const isStarted = currentMatch.matchStartTime 
      ? new Date(currentMatch.matchStartTime).getTime() <= Date.now()
      : false;

    if (isStarted || currentMatch.status === 'LIVE' || currentMatch.status === 'COMPLETED') {
      alert('⚠️ Lobby Locked: The start time has been reached or been completed! Safe lock prevents further entries.');
      return;
    }

    if (!ignInput.trim()) {
      alert('⚠️ Please specify your Free Fire Username (IGN) before joining.');
      return;
    }
    if (!levelInput.trim()) {
      alert('⚠️ Please specify your In-Game Level.');
      return;
    }
    const levelNum = Number(levelInput);
    if (isNaN(levelNum) || levelNum <= 0) {
      alert('⚠️ Please enter a valid numerical In-Game Level.');
      return;
    }

    const cost = currentMatch.entryFee;
    if (userCombinedBalance < cost) {
      setShowModal('insufficient');
      return;
    }

    // Single Team Rule Check
    if (isJoined) {
      alert('⚠️ You have already registered for this custom room!');
      return;
    }

    setShowModal('confirm');
  };

  // Execute Core Join & Deduction flow
  const executeJoinMatch = async () => {
    if (!currentUser) return;
    if (isSubmitting) return;
    setIsSubmitting(true);
    const levelNum = Number(levelInput);
    const cost = currentMatch.entryFee;

    // Joining match for first time gets a random Team 'A' or 'B' safely based on vacancy
    const activeTeamAPs = currentMatch.players.filter(p => p.team === 'A').length;
    const activeTeamBPs = currentMatch.players.filter(p => p.team === 'B').length;

    let allocatedTeam: 'A' | 'B' = 'A';
    if (activeTeamAPs >= maxPerTeam) {
      allocatedTeam = 'B';
    } else if (activeTeamBPs >= maxPerTeam) {
      allocatedTeam = 'A';
    } else {
      allocatedTeam = Math.random() < 0.5 ? 'A' : 'B';
    }

    // Assign a random unoccupied grid position within the allocated team
    const vacantPositions = Array.from({ length: maxPerTeam }, (_, i) => i + 1)
      .filter(pos => !currentMatch.players.some(p => p.team === allocatedTeam && (p.position || 1) === pos));
    const assignedPosition = vacantPositions.length > 0
      ? vacantPositions[Math.floor(Math.random() * vacantPositions.length)]
      : 1;

    // HIGH SECURITY: If the database is connected online, perform an ATOMIC transaction
    if (isConfigured) {
      const res = await joinMatchAtomic(
        currentMatch.id, 
        currentUser.id, 
        ignInput.trim(), 
        levelNum, 
        allocatedTeam, 
        assignedPosition
      );

      if (res.success && res.updatedUser && res.updatedMatch) {
        // Update local memory to stay in perfect sync immediately
        setCurrentUser(res.updatedUser);
        setLocalCurrentUser(res.updatedUser);
        
        // Update the current local match state
        setCurrentMatch(res.updatedMatch);

        // Record last team block lock
        localStorage.setItem(`valent_last_team_${currentMatch.id}_${currentUser.id}`, allocatedTeam);
        setLastAssignedTeam(allocatedTeam);
        
        setShowModal('none');
        setIsSubmitting(false);
        alert("🎉 Success: Roster slot secured atomically!");
        return;
      } else {
        const isNetworkOrTimeout = res.error && (
          res.error.includes("Network timeout") || 
          res.error.includes("offline") || 
          res.error.includes("connection") || 
          res.error.includes("Failed to get document") ||
          res.error.includes("unreachable")
        );

        if (isNetworkOrTimeout) {
          alert(`⚠️ Connection timed out or database unreachable.\n\nFalling back to Secure Local Sync to instantly register your slot on Team ${allocatedTeam === 'A' ? 'Alpha' : 'Beta'} Slot #${assignedPosition}. Your data will sync in the background!`);
          // DO NOT return! Continue to execute the local fallback sequence below.
        } else {
          alert(`❌ Slot Already Taken or Concurrency Limit Rejected: ${res.error || "Please reload Lobbies."}`);
          setShowModal('none');
          setIsSubmitting(false);
          return;
        }
      }
    }

    // Deduct cost following standard wallet debit prioritization
    let updatedDeposit = currentUser.wallet.deposit;
    let updatedWinnings = currentUser.wallet.winnings;

    if (updatedDeposit >= cost) {
      updatedDeposit -= cost;
    } else {
      const carry = cost - updatedDeposit;
      updatedDeposit = 0;
      updatedWinnings -= carry;
    }

    // Save user update
    const nextUser: User = {
      ...currentUser,
      ign: ignInput.trim(),
      wallet: {
        ...currentUser.wallet,
        deposit: updatedDeposit,
        winnings: updatedWinnings
      }
    };

    // --- AUTOMATED REFERRAL REWARD TRIGGER ---
    if (!nextUser.hasJoinedFirstGame) {
      nextUser.hasJoinedFirstGame = true;
      if (nextUser.referredByUserId) {
        try {
          const allUsers = getUsers();
          const inviterIdx = allUsers.findIndex(u => u.id === nextUser.referredByUserId);
          if (inviterIdx !== -1) {
            const inviter = allUsers[inviterIdx];
            // Auto credit ₹25 reward to the inviter
            inviter.wallet.deposit = (inviter.wallet.deposit || 0) + 25;
            allUsers[inviterIdx] = inviter;
            saveUsers(allUsers);

            // Create a premium companion transaction for the inviter
            const rtxs = getTransactions();
            rtxs.unshift({
              id: `tx-referral-reward-${Date.now()}`,
              userId: inviter.id,
              type: 'deposit',
              amount: 25,
              status: 'approved',
              created_at: new Date().toISOString(),
              matchTitle: `Referral Reward: @${nextUser.username} Joined First Game`
            });
            saveTransactions(rtxs);

            nextUser.isReferralRewardPaid = true;
          }
        } catch (err) {
          console.error('Failed paying out referral reward:', err);
        }
      }
    }

    setCurrentUser(nextUser);

    // Save transaction
    const txs = getTransactions();
    txs.unshift({
      id: `tx-entry-${Date.now()}`,
      userId: currentUser.id,
      type: 'withdrawal',
      amount: cost,
      status: 'approved',
      created_at: new Date().toISOString(),
      matchId: currentMatch.id,
      matchTitle: currentMatch.title
    });
    saveTransactions(txs);

    // Set last assigned team lock to prevent showing re-assignment alert on join
    localStorage.setItem(`valent_last_team_${currentMatch.id}_${currentUser.id}`, allocatedTeam);
    setLastAssignedTeam(allocatedTeam);

    const newPlayer: MatchPlayer = {
      userId: currentUser.id,
      username: currentUser.username,
      ign: ignInput.trim(),
      level: levelNum,
      team: allocatedTeam,
      status: 'READY',
      position: assignedPosition
    };

    const nextPlayers = [...currentMatch.players, newPlayer];
    const nextSpotsFilled = currentMatch.spotsFilled + 1;
    
    // Automatically transition to ROOM_READY if spots total reached
    let nextStatus = currentMatch.status;
    if (nextSpotsFilled >= currentMatch.spotsTotal && nextStatus === 'PENDING_START') {
      nextStatus = 'ROOM_READY';
    }

    const nextMatch: Match = {
      ...currentMatch,
      spotsFilled: nextSpotsFilled,
      players: nextPlayers,
      status: nextStatus
    };

    const allMatches = getMatches();
    const midx = allMatches.findIndex(m => m.id === currentMatch.id);
    if (midx !== -1) {
      allMatches[midx] = nextMatch;
      saveMatches(allMatches);
    }
    setCurrentMatch(nextMatch);
    setShowModal('none');
    setIsSubmitting(false);
  };

  // Execute Teammate Reservation payment & slot booking
  const handleReserveTeammateSlot = async () => {
    if (!currentUser || !userSlot) return;
    if (isSubmitting) return;
    if (!teammateIGN.trim()) {
      alert("⚠️ Please specify your teammate's In-Game Name (IGN).");
      return;
    }
    if (!teammateLevel.trim()) {
      alert("⚠️ Please specify teammate's In-Game Level.");
      return;
    }
    const lvl = Number(teammateLevel);
    if (isNaN(lvl) || lvl <= 0) {
      alert('⚠️ Please enter a valid numerical Level.');
      return;
    }

    const myTeam = userSlot.team;
    
    // Check if team is full
    const currentTeamCount = currentMatch.players.filter(p => p.team === myTeam).length;
    if (currentTeamCount >= maxPerTeam) {
      alert(`⚠️ Your Team ${myTeam === 'A' ? 'Alpha' : 'Beta'} is already full! No additional positions are available to reserve.`);
      return;
    }

    // Verify balance
    const cost = currentMatch.entryFee;
    if (userCombinedBalance < cost) {
      alert(`⚠️ Insufficient Balance to reserve! Real entry fee of ₹${cost} is required.`);
      return;
    }

    // Pick random unoccupied grid position within teammate's team
    const vacantPositions = Array.from({ length: maxPerTeam }, (_, i) => i + 1)
      .filter(pos => !currentMatch.players.some(p => p.team === myTeam && (p.position || 1) === pos));
    const teammatePosition = vacantPositions.length > 0
      ? vacantPositions[Math.floor(Math.random() * vacantPositions.length)]
      : 1;

    // HIGH SECURITY: If online database is configured, perform atomic reservation transaction
    if (isConfigured) {
      setIsSubmitting(true);
      const res = await reserveTeammateAtomic(
        currentMatch.id,
        currentUser.id,
        teammateIGN.trim(),
        lvl,
        myTeam,
        teammatePosition
      );

      if (res.success && res.updatedUser && res.updatedMatch) {
         setCurrentUser(res.updatedUser);
         setLocalCurrentUser(res.updatedUser);
         setCurrentMatch(res.updatedMatch);

         setTeammateIGN('');
         setTeammateLevel('');
         setShowReserveModal(false);
         setIsSubmitting(false);
         alert(`🎉 Teammate slot reserved successfully! ${teammateIGN} is assigned to Team ${myTeam === 'A' ? 'Alpha' : 'Beta'} Slot #${teammatePosition}.`);
         return;
      } else {
        const isNetworkOrTimeout = res.error && (
          res.error.includes("Network timeout") || 
          res.error.includes("offline") || 
          res.error.includes("connection") || 
          res.error.includes("Failed to get document") ||
          res.error.includes("unreachable")
        );

        if (isNetworkOrTimeout) {
          alert(`⚠️ Live database is unreachable or connection timed out.\n\nFalling back to Secure Local Sync to instantly reserve Team ${myTeam === 'A' ? 'Alpha' : 'Beta'} Slot #${teammatePosition} for your teammate. All updates will sync in the background!`);
          // DO NOT return! Continue to execute local fallback below.
        } else {
          alert(`❌ Slot Already Taken or Reservation Rejected: ${res.error || "Please try again."}`);
          setShowReserveModal(false);
          setIsSubmitting(false);
          return;
        }
      }
    }

    // Deduct entry fee from captain/reserving user wallet
    let updatedDeposit = currentUser.wallet.deposit;
    let updatedWinnings = currentUser.wallet.winnings;

    if (updatedDeposit >= cost) {
      updatedDeposit -= cost;
    } else {
      const carry = cost - updatedDeposit;
      updatedDeposit = 0;
      updatedWinnings -= carry;
    }

    // Save reserving user update
    const nextUser: User = {
      ...currentUser,
      wallet: {
        ...currentUser.wallet,
        deposit: updatedDeposit,
        winnings: updatedWinnings
      }
    };
    setCurrentUser(nextUser);
    setLocalCurrentUser(nextUser);

    // Save transaction for reservation
    const txs = getTransactions();
    txs.unshift({
      id: `tx-reserve-${Date.now()}`,
      userId: currentUser.id,
      type: 'withdrawal',
      amount: cost,
      status: 'approved',
      created_at: new Date().toISOString(),
      matchId: currentMatch.id,
      matchTitle: `${currentMatch.title} (Teammate slot reserved)`
    });
    saveTransactions(txs);

    // Pick random unoccupied grid position within teammate's team
    const fallbackVacantPositions = Array.from({ length: maxPerTeam }, (_, i) => i + 1)
      .filter(pos => !currentMatch.players.some(p => p.team === myTeam && (p.position || 1) === pos));
    const fallbackTeammatePosition = fallbackVacantPositions.length > 0
      ? fallbackVacantPositions[Math.floor(Math.random() * fallbackVacantPositions.length)]
      : 1;

    // Create teammate MatchPlayer record
    const reservedPlayer: MatchPlayer = {
      userId: `reserved-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      username: `${currentUser.username}'s Teammate`,
      ign: teammateIGN.trim(),
      level: lvl,
      team: myTeam,
      status: 'READY',
      position: fallbackTeammatePosition
    };

    const nextPlayers = [...currentMatch.players, reservedPlayer];
    const nextSpotsFilled = currentMatch.spotsFilled + 1;

    let nextStatus = currentMatch.status;
    if (nextSpotsFilled >= currentMatch.spotsTotal && nextStatus === 'PENDING_START') {
      nextStatus = 'ROOM_READY';
    }

    const nextMatch: Match = {
      ...currentMatch,
      spotsFilled: nextSpotsFilled,
      players: nextPlayers,
      status: nextStatus
    };

    const allMatches = getMatches();
    const midx = allMatches.findIndex(m => m.id === currentMatch.id);
    if (midx !== -1) {
      allMatches[midx] = nextMatch;
      saveMatches(allMatches);
    }
    setCurrentMatch(nextMatch);
    
    // Clear reservation fields and close modal
    setTeammateIGN('');
    setTeammateLevel('');
    setShowReserveModal(false);
    setIsSubmitting(false);
    alert(`🎉 Teammate slot reserved successfully! ${teammateIGN} is assigned to Team ${myTeam === 'A' ? 'Alpha' : 'Beta'} Slot #${teammatePosition}.`);
  };

  // Helpers to copy credentials
  const copyText = (text: string, setCopied: (v: boolean) => void) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const spotsRemaining = currentMatch.spotsTotal - currentMatch.spotsFilled;
  const isFull = spotsRemaining <= 0;

  return (
    <div className="max-w-md mx-auto p-4 space-y-6 animate-fade-in text-white pb-28">
      {/* Header back menu row */}
      <button
        onClick={onBack}
        className="flex items-center gap-2.5 text-sm font-mono text-gray-300 hover:text-white transition-colors cursor-pointer mr-auto py-1"
      >
        <ArrowLeft className="w-4.5 h-4.5" />
        <span>Exit custom lobby board</span>
      </button>

      {/* Hero match brief card */}
      <div className="bg-gradient-to-br from-[#121A2E] to-[#0A0E17] border border-[#222D4A] rounded-2.5xl p-6 relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-44 h-44 bg-[#FF4500]/10 rounded-full blur-2xl pointer-events-none" />
        
        <span className="text-[10px] font-mono text-emerald-400 font-extrabold uppercase bg-emerald-950/50 border border-emerald-950 px-2.5 py-1 rounded-lg tracking-wider">
          {currentMatch.format_type} MATCH
        </span>
        
        <h2 className="text-xl font-display font-black text-white uppercase mt-3.5 select-none tracking-wide">
          {currentMatch.title}
        </h2>

        {/* Big visual stat indicators - MatchWorkspace Hero Redesign */}
        <div className="grid grid-cols-3 gap-2 mt-5 pt-4 border-t border-[#222D4A]/55 text-center">
          <div className="bg-[#13192B]/50 rounded-xl p-2 border border-[#222D4A]/40 flex flex-col justify-center min-w-0">
            <span className="text-[9px] uppercase tracking-widest block text-gray-400 font-bold mb-1">Map Arena</span>
            <span className="text-[10.5px] sm:text-xs text-gray-100 uppercase font-black break-words leading-tight">{currentMatch.mapName}</span>
          </div>
          
          <div className="bg-[#13192B]/50 rounded-xl p-2 border border-[#222D4A]/40 flex flex-col justify-center min-w-0">
            <span className="text-[9px] uppercase tracking-widest block text-orange-400 font-bold mb-1">Entry Fee</span>
            <span className="text-[10.5px] sm:text-xs text-orange-400 uppercase font-black break-words leading-tight">₹{currentMatch.entryFee}</span>
          </div>

          <div className="bg-[#13192B]/90 border border-[#00FFCC]/20 rounded-xl p-2 text-center flex flex-col justify-center min-w-0 shadow-[inset_0_0_12px_rgba(0,255,204,0.035)]">
            <span className="text-[9px] uppercase tracking-widest block text-[#00FFCC]/80 font-bold mb-1">Prize Pool</span>
            <span className="text-xs sm:text-sm text-[#00FFCC] font-black break-words leading-tight">₹{currentMatch.prizePool}</span>
          </div>
        </div>
      </div>

      {/* Conditional Registration Card vs Live Room Credentials Panel */}
      {!isJoined ? (
        <div className="bg-[#111625] border-2 border-[#1c243a] rounded-2.5xl p-6 mt-2.5 space-y-5 shadow-2xl relative overflow-hidden transition-all duration-300 hover:border-[#222d4a]">
          {/* Subtle background dynamic highlight blooms */}
          <div className="absolute -top-16 -right-16 w-32 h-32 bg-orange-500/5 rounded-full blur-2xl pointer-events-none" />
          <div className="absolute -bottom-16 -left-16 w-32 h-32 bg-[#00FFCC]/5 rounded-full blur-2xl pointer-events-none" />

          <div className="flex items-center justify-between pb-3.5 border-b border-[#1c243a]">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-orange-500/10 rounded-xl border border-orange-500/25">
                <Gamepad2 className="w-5.5 h-5.5 text-orange-400 animate-pulse" />
              </div>
              <div className="text-left">
                <h3 className="font-display font-black text-sm text-white uppercase tracking-wider">Tournament Registration</h3>
                <p className="text-[10px] text-gray-400 font-mono font-bold uppercase tracking-wider">Enter Game Credentials</p>
              </div>
            </div>
            <div className="bg-[#181f33] px-3 py-1 rounded-lg border border-[#222d4a] flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-ping" />
              <span className="text-[9.5px] font-mono font-black text-gray-300 uppercase tracking-widest">Entry: ₹{currentMatch.entryFee}</span>
            </div>
          </div>

          <p className="text-[12.5px] text-gray-300 leading-relaxed font-sans bg-[#161c2e]/40 p-3 rounded-xl border border-[#1e273e]/50 text-left">
            Please supply your authentic <span className="font-bold text-orange-400">Free Fire username & player level</span>. Your ticket of <span className="font-bold text-white">₹{currentMatch.entryFee}</span> will be debited directly from your wallet balance.
          </p>

          {/* Team choice removed per specification. Assigned purely randomly upon completion */}

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2 text-left">
              <label className="text-[10px] font-mono font-black uppercase tracking-widest text-gray-400 block pl-1">
                Free Fire Username (IGN)
              </label>
              <div className="relative group transition-all">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-500 group-focus-within:text-orange-400 transition-colors">
                  <Gamepad2 className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  placeholder="e.g. ALPHA_CHIEF"
                  value={ignInput}
                  onChange={(e) => setIgnInput(e.target.value)}
                  className="w-full bg-[#080b13] border border-[#222d4a]/80 rounded-xl pl-10 pr-3.5 py-3 text-xs font-mono font-bold text-white placeholder-gray-600 focus:outline-none focus:border-orange-500 focus:ring-1 focus:ring-orange-500/30 transition-all shadow-[inset_0_2px_4px_rgba(0,0,0,0.6)]"
                />
              </div>
            </div>

            <div className="space-y-2 text-left">
              <label className="text-[10px] font-mono font-black uppercase tracking-widest text-gray-400 block pl-1">
                In-Game Level
              </label>
              <div className="relative group transition-all">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-500 group-focus-within:text-orange-400 transition-colors">
                  <TrendingUp className="w-4 h-4" />
                </div>
                <input
                  type="number"
                  placeholder="e.g. 68"
                  min="1"
                  value={levelInput}
                  onChange={(e) => setLevelInput(e.target.value)}
                  className="w-full bg-[#080b13] border border-[#222d4a]/80 rounded-xl pl-10 pr-3.5 py-3 text-xs font-mono font-bold text-white placeholder-gray-650 focus:outline-none focus:border-orange-500 focus:ring-1 focus:ring-orange-500/30 transition-all shadow-[inset_0_2px_4px_rgba(0,0,0,0.6)]"
                />
              </div>
            </div>
          </div>

          {/* ⚠️ Warning Banner - Highly visible, professional & beautiful */}
          <div className="bg-[#1a0f12] border border-red-500/25 rounded-2xl p-4 flex items-start gap-3.5 shadow-md shadow-red-950/20">
            <div className="p-1.5 bg-red-500/10 rounded-lg border border-red-500/30 shrink-0 mt-0.5">
              <AlertTriangle className="w-4.5 h-4.5 text-red-400" />
            </div>
            <div className="text-left space-y-1">
              <span className="font-mono font-black tracking-wider text-[11px] uppercase text-red-400 flex items-center gap-1.5">
                ⚠️ STRICT ANTI-CHEAT CHECK
              </span>
              <p className="text-[11.5px] font-sans text-red-200/90 leading-relaxed font-medium">
                Your <span className="font-bold text-white">IGN & Level</span> must exactly match your real profile in-game. Discrepancies will trigger instant kick & disqualification with <span className="underline decoration-red-500/50 underline-offset-2 font-bold text-white">zero refunds</span>.
              </p>
            </div>
          </div>

          <div className="flex justify-between items-center pt-4 border-t border-[#1c243a]">
            <div className="text-left">
              <span className="text-[9.5px] font-mono text-gray-400 block uppercase tracking-widest font-black">YOUR WALLET</span>
              <span className="text-lg font-display font-black text-[#00FFCC] tracking-tight">₹{userCombinedBalance.toFixed(0)}</span>
            </div>

            <button
              onClick={handleJoinMatch}
              className={`px-6 py-3.5 font-display font-black text-xs uppercase tracking-widest rounded-xl transition-all cursor-pointer ${
                isFull || (currentMatch.matchStartTime ? new Date(currentMatch.matchStartTime).getTime() <= Date.now() : false) || currentMatch.status !== 'PENDING_START'
                  ? 'bg-gray-800 text-gray-500 border border-gray-700 cursor-not-allowed opacity-50'
                  : 'bg-gradient-to-r from-orange-500 via-[#FF4500] to-red-600 text-white hover:scale-103 active:scale-97 shadow-xl shadow-orange-950/20 hover:shadow-orange-500/20 hover:brightness-110'
              }`}
              disabled={isFull || (currentMatch.matchStartTime ? new Date(currentMatch.matchStartTime).getTime() <= Date.now() : false) || currentMatch.status !== 'PENDING_START'}
            >
              {isFull 
                ? 'Lobby Full' 
                : (currentMatch.matchStartTime ? new Date(currentMatch.matchStartTime).getTime() <= Date.now() : false) 
                  ? 'Match Started' 
                  : 'Join and Register'}
            </button>
          </div>
        </div>
      ) : (
        /* Joined Details: Room ID & Password screen */
        <div className="bg-[#13192B] border border-[#FF4500]/50 rounded-2.5xl p-6 space-y-5 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 py-1.5 px-4.5 bg-[#FF4500] text-black text-[10px] font-mono font-black uppercase tracking-widest rounded-bl-xl shadow-md">
            LOCKED & REGISTERED
          </div>

          <div className="flex items-center gap-2.5 text-[#00FFCC] pb-1.5 border-b border-[#222D4A]/50">
            <ShieldCheck className="w-5.5 h-5.5 text-[#00FFCC]" />
            <h3 className="font-display font-black text-sm text-white uppercase tracking-wider">Lobby Entry Parameters</h3>
          </div>

          {currentMatch.status === 'PENDING_START' && (currentMatch.credentialsRevealTime ? new Date() < new Date(currentMatch.credentialsRevealTime) : true) ? (
            /* Waiting screen credentials */
            (() => {
              const now = new Date();
              const revealTime = currentMatch.credentialsRevealTime ? new Date(currentMatch.credentialsRevealTime) : null;
              const startTime = currentMatch.matchStartTime ? new Date(currentMatch.matchStartTime) : null;

              const isBeforeReveal = revealTime && now < revealTime;
              const isBeforeStart = startTime && now < startTime;

              let revealMins = 0, revealSecs = "00";
              let startMins = 0, startSecs = "00";

              if (isBeforeReveal) {
                const revealDiff = revealTime.getTime() - now.getTime();
                revealMins = Math.floor(revealDiff / 60000);
                revealSecs = Math.floor((revealDiff % 60000) / 1000).toString().padStart(2, '0');
              }

              if (isBeforeStart) {
                const startDiff = startTime.getTime() - now.getTime();
                startMins = Math.floor(startDiff / 60000);
                startSecs = Math.floor((startDiff % 60000) / 1000).toString().padStart(2, '0');
              }

              return (
                <div className="bg-[#0A0E17]/80 rounded-2xl p-5 border border-[#222D4A] flex flex-col items-center justify-center text-center space-y-4 py-8">
                  <Lock className="w-10 h-10 text-orange-500 mb-1 animate-bounce" />
                  
                  <div className="space-y-1">
                    <h4 className="font-mono text-xs font-black text-orange-400 uppercase tracking-widest">Custom ID & Password is coming</h4>
                    <p className="text-[11px] text-gray-400 max-w-xs leading-relaxed">
                      Lobby is locked. Free Fire Room ID and Password will display in this container automatically as soon as reveal ticks to zero.
                    </p>
                  </div>

                  {startTime || revealTime ? (
                    <div className="grid grid-cols-2 gap-3 w-full max-w-xs pt-2">
                      <div className="bg-[#13192B] border border-[#222D4A] p-2.5 rounded-xl text-center">
                        <span className="text-[8px] font-mono font-black text-gray-500 uppercase tracking-wider block">Starting In</span>
                        <span className="text-sm font-mono font-black text-[#00FFCC] animate-pulse block mt-1">
                          {isBeforeStart ? `${startMins}:${startSecs}` : 'LIVE'}
                        </span>
                      </div>
                      <div className="bg-[#13192B] border border-[#222D4A] p-2.5 rounded-xl text-center">
                        <span className="text-[8px] font-mono font-black text-gray-500 uppercase tracking-wider block">ID Reveal In</span>
                        <span className="text-sm font-mono font-black text-amber-500 animate-pulse block mt-1">
                          {isBeforeReveal ? `${revealMins}:${revealSecs}` : 'UNLOCKED'}
                        </span>
                      </div>
                    </div>
                  ) : null}
                </div>
              );
            })()
          ) : (
            /* Credentials are live */
            <div className="space-y-4">
              <div className="bg-emerald-950/10 border border-emerald-500/20 rounded-xl p-3.5 flex flex-col gap-1.5 align-start text-left">
                <div className="flex items-center gap-2.5">
                  <Unlock className="w-5 h-5 text-emerald-400 shrink-0 animate-pulse" />
                  <span className="text-[11px] font-mono text-emerald-400 font-bold leading-relaxed">
                    LOBBY DISPATCHED! Spawn inside Free Fire Custom room immediately.
                  </span>
                </div>
                {/* Embedded Game starts indicator inside revealed view! */}
                {(() => {
                  const now = new Date();
                  const startTime = currentMatch.matchStartTime ? new Date(currentMatch.matchStartTime) : null;
                  const isBeforeStart = startTime && now < startTime;
                  if (startTime) {
                    return (
                      <div className="mt-1.5 pt-1.5 border-t border-emerald-500/10 w-full flex items-center justify-between text-[10px] font-mono">
                        <span className="text-gray-400 uppercase font-black">🕹️ CUSTOM MATCH STATUS:</span>
                        {isBeforeStart ? (
                          (() => {
                            const startDiff = startTime.getTime() - now.getTime();
                            const startMins = Math.floor(startDiff / 60000);
                            const startSecs = Math.floor((startDiff % 60000) / 1000).toString().padStart(2, '0');
                            return (
                              <span className="text-orange-400 font-black animate-pulse bg-orange-500/10 px-2 py-0.5 rounded-md border border-orange-500/20">
                                STARTING IN {startMins}:{startSecs}
                              </span>
                            );
                          })()
                        ) : (
                          <span className="text-[#00FFCC] font-black animate-pulse bg-[#00FFCC]/10 px-2 py-0.5 rounded-md border border-[#00FFCC]/20">
                            🔴 MATCH IN PROGRESS / LIVE
                          </span>
                        )}
                      </div>
                    );
                  }
                  return null;
                })()}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-[#0A0E17] border border-[#222D4A] rounded-xl p-4 flex flex-col justify-between relative group">
                  <span className="text-[9px] font-mono text-gray-400 uppercase tracking-widest block font-bold">ROOM ID</span>
                  <span className="text-base font-mono font-black text-white mt-1.5 block">
                    {currentMatch.roomId || '928014'}
                  </span>
                  <button
                    onClick={() => copyText(currentMatch.roomId || '928014', setCopiedRoomId)}
                    className="absolute top-3.5 right-3 text-gray-500 hover:text-[#00FFCC] transition-colors p-1"
                  >
                    {copiedRoomId ? (
                      <span className="text-[9px] text-[#00FFCC] font-mono uppercase font-black">Copied!</span>
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </button>
                </div>

                <div className="bg-[#0A0E17] border border-[#222D4A] rounded-xl p-4 flex flex-col justify-between relative group">
                  <span className="text-[9px] font-mono text-gray-400 uppercase tracking-widest block font-bold">ROOM PASSWORD</span>
                  <span className="text-base font-mono font-black text-white mt-1.5 block">
                    {currentMatch.roomPassword || 'cs_pass'}
                  </span>
                  <button
                    onClick={() => copyText(currentMatch.roomPassword || 'cs_pass', setCopiedPass)}
                    className="absolute top-3.5 right-3 text-gray-500 hover:text-[#00FFCC] transition-colors p-1"
                  >
                    {copiedPass ? (
                      <span className="text-[9px] text-[#00FFCC] font-mono uppercase font-black">Copied!</span>
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </button>
                </div>
              </div>
            </div>
          )}

        </div>
      )}

      {isJoined && isTeamVsTeam && (
        <div className="bg-gradient-to-r from-[#172237] to-[#0D1426] border border-[#222D4A] rounded-2.5xl p-5 space-y-3.5 shadow-xl">
          <div className="flex justify-between items-center text-left">
            <div className="space-y-1">
              <h4 className="text-xs font-display font-black text-white uppercase tracking-wider">
                👥 Reserve Spot for Teammates
              </h4>
              <p className="text-[10px] text-gray-400 font-mono leading-relaxed max-w-xs">
                Pay ₹{currentMatch.entryFee} from your balance to book a custom slot inside Team {userSlot?.team === 'A' ? 'ALPHA' : 'BETA'}.
              </p>
            </div>
          </div>
          
          <div className="flex items-center justify-between gap-3 pt-3 border-t border-[#222D4A]/55">
            <div className="text-left">
              <span className="text-[8px] font-mono text-gray-500 block uppercase font-bold leading-none mb-1">
                Team Capacity
              </span>
              <span className="text-xs text-[#00FFCC] font-mono font-black">
                {currentMatch.players.filter(p => p.team === userSlot?.team).length} / {maxPerTeam} Slots Booked
              </span>
            </div>
            
            <button
              onClick={() => setShowReserveModal(true)}
              disabled={currentMatch.players.filter(p => p.team === userSlot?.team).length >= maxPerTeam}
              className="px-4.5 py-2.5 bg-gradient-to-r from-[#FF4500] to-[#C60000] text-white hover:scale-103 active:scale-97 text-[10px] font-mono font-black uppercase tracking-wider rounded-xl transition-all disabled:opacity-40 disabled:scale-100 disabled:cursor-not-allowed cursor-pointer shadow-md"
            >
              Reserve Spot Now
            </button>
          </div>
        </div>
      )}

      {/* Split/Double rosters display inside lobby */}
      <div className="bg-[#13192B] border border-[#222D4A] rounded-2.5xl p-6 space-y-4 shadow-xl">
        <div className="flex justify-between items-center pb-2.5 border-b border-[#222D4A]/50">
          <div className="flex items-center gap-2">
            <Users className="w-5.5 h-5.5 text-[#00FFCC]" />
            <h3 className="font-display font-black text-[14px] uppercase text-white tracking-wide">Lobby Combatants</h3>
          </div>
          <span className="text-[10px] font-mono px-2.5 py-0.5 rounded bg-gray-800 text-gray-300 font-extrabold border border-gray-700 tracking-wider">
            {currentMatch.spotsFilled} / {currentMatch.spotsTotal} SLOTS
          </span>
        </div>

        <div className="grid grid-cols-2 gap-4">
          {/* Team A Roster Column */}
          <div className="space-y-3">
            <h4 className="text-[10px] font-mono font-black text-[#FF4500] uppercase tracking-widest pl-1">
              🟥 TEAM ALPHA ({currentMatch.players.filter(p => p.team === 'A').length})
            </h4>
            
            <div className="space-y-2.5 home-feed-players max-h-72 overflow-y-auto pr-1">
              {currentMatch.players.filter(p => p.team === 'A').map((p, idx) => (
                <div key={idx} className="bg-[#0D1527] border-2 border-[#1E2C4F] hover:border-[#FF4500]/40 rounded-xl p-3.5 flex items-center justify-between shadow-md transition-all">
                  <div className="min-w-0 pr-2 space-y-1 text-left">
                    <span className="text-sm font-display font-black text-[#00FFCC] block truncate tracking-wide leading-tight uppercase">
                      {p.ign}
                    </span>
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="text-[9px] bg-red-500/10 text-red-400 font-black border border-red-500/20 px-1.5 py-0.5 rounded font-mono uppercase shrink-0">
                        Slot #{p.position || idx + 1}
                      </span>
                      {p.level && (
                        <span className="text-[9px] bg-gradient-to-r from-red-650 to-orange-600 text-white font-black px-1.5 py-0.5 rounded font-mono uppercase shrink-0 shadow-sm">
                          Lvl {p.level}
                        </span>
                      )}
                    </div>
                    <span className="text-[9.5px] text-gray-400 font-mono truncate block">
                      @{p.username}
                    </span>
                  </div>
                  <ShieldCheck className="w-5 h-5 text-emerald-450 shrink-0 select-none animate-pulse" title="IGN Verified" />
                </div>
              ))}
              {currentMatch.players.filter(p => p.team === 'A').length === 0 && (
                <span className="text-[10px] font-mono text-gray-500 pl-1 block">No players joined...</span>
              )}
            </div>
          </div>

          {/* Team B Roster Column */}
          <div className="space-y-3">
            <h4 className="text-[10px] font-mono font-black text-blue-400 uppercase tracking-widest pl-1">
              🟦 TEAM BETA ({currentMatch.players.filter(p => p.team === 'B').length})
            </h4>

            <div className="space-y-2.5 home-feed-players max-h-72 overflow-y-auto pr-1">
              {currentMatch.players.filter(p => p.team === 'B').map((p, idx) => (
                <div key={idx} className="bg-[#0D1527] border-2 border-[#1E2C4F] hover:border-blue-550/40 rounded-xl p-3.5 flex items-center justify-between shadow-md transition-all">
                  <div className="min-w-0 pr-2 space-y-1 text-left">
                    <span className="text-sm font-display font-black text-[#00FFCC] block truncate tracking-wide leading-tight uppercase">
                      {p.ign}
                    </span>
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="text-[9px] bg-blue-500/10 text-blue-400 font-black border border-blue-500/20 px-1.5 py-0.5 rounded font-mono uppercase shrink-0">
                        Slot #{p.position || idx + 1}
                      </span>
                      {p.level && (
                        <span className="text-[9px] bg-gradient-to-r from-red-650 to-orange-600 text-white font-black px-1.5 py-0.5 rounded font-mono uppercase shrink-0 shadow-sm">
                          Lvl {p.level}
                        </span>
                      )}
                    </div>
                    <span className="text-[9.5px] text-gray-400 font-mono truncate block">
                      @{p.username}
                    </span>
                  </div>
                  <ShieldCheck className="w-5 h-5 text-emerald-450 shrink-0 select-none animate-pulse" title="IGN Verified" />
                </div>
              ))}
              {currentMatch.players.filter(p => p.team === 'B').length === 0 && (
                <span className="text-[10px] font-mono text-gray-500 pl-1 block">No players joined...</span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* 🔮 CUSTOM ESCROW MODALS (FOR PAYMENT CHECKS & CONFIRMATION) */}
      {showModal !== 'none' && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-fade-in text-white">
          <div className="bg-[#0D1426] border border-[#222D4A] rounded-2.5xl max-w-sm w-full p-6 shadow-2xl relative overflow-hidden space-y-5">
            <div className="absolute top-0 right-0 w-32 h-32 bg-[#FF4500]/10 rounded-full blur-2xl pointer-events-none" />
            
            {showModal === 'insufficient' ? (
              <>
                <div className="text-center space-y-3">
                  <div className="mx-auto w-12 h-12 bg-red-500/10 border border-red-500/20 text-red-500 rounded-2xl flex items-center justify-center mb-1">
                    <AlertTriangle className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-display font-black text-white uppercase tracking-wider">
                    Balance Insufficient!
                  </h3>
                  <p className="text-[12.5px] text-gray-300 leading-normal">
                    You have <span className="text-red-400 font-extrabold">₹{userCombinedBalance.toFixed(0)}</span>, but this custom esports arena requires an entry fee of <span className="text-white font-extrabold font-mono">₹{currentMatch.entryFee}</span> to secure your slot.
                  </p>
                </div>

                <div className="bg-[#13192B]/80 rounded-xl p-3.5 border border-[#222D4A]/60 flex justify-between items-center text-xs font-mono">
                  <div className="text-left">
                    <span className="text-gray-400 uppercase text-[9px] block font-bold leading-none mb-1">Lobby Fee</span>
                    <span className="text-white font-black text-sm">₹{currentMatch.entryFee}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-gray-400 uppercase text-[9px] block font-bold leading-none mb-1">Shortfall Amount</span>
                    <span className="text-red-400 font-extrabold text-sm">₹{currentMatch.entryFee - userCombinedBalance}</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3.5 pt-2">
                  <button
                    onClick={() => setShowModal('none')}
                    className="w-full bg-[#13192B] border border-[#222D4A] text-gray-300 py-3 rounded-xl font-display font-bold text-xs uppercase tracking-wider hover:bg-gray-850 hover:text-white transition-all cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => {
                      setShowModal('none');
                      onNavigateToWallet();
                    }}
                    className="w-full bg-gradient-to-r from-[#FF4500] to-[#C60000] text-white py-3 rounded-xl font-display font-black text-xs uppercase tracking-wider hover:shadow-[0_0_12px_rgba(255,69,0,0.3)] shadow-md transition-all cursor-pointer text-center"
                  >
                    Deposit Funds
                  </button>
                </div>
              </>
            ) : (
              <>
                <div className="text-center space-y-3">
                  <div className="mx-auto w-12 h-12 bg-[#00FFCC]/10 border border-[#00FFCC]/20 text-[#00FFCC] rounded-2xl flex items-center justify-center mb-1">
                    <Coins className="w-6 h-6 animate-pulse" />
                  </div>
                  <h3 className="text-lg font-display font-black text-white uppercase tracking-wider">
                    Confirm Entry Fee?
                  </h3>
                  <p className="text-[12.5px] text-gray-300 leading-normal">
                    Are you absolutely sure you want to deduct <span className="text-[#00FFCC] font-extrabold font-mono">₹{currentMatch.entryFee}</span> from your balance to register for this lobby?
                  </p>
                </div>

                <div className="bg-[#13192B]/80 rounded-xl p-4 border border-[#222D4A]/60 space-y-2.5 text-xs font-mono text-left">
                  <div className="flex justify-between items-center text-gray-300">
                    <span>Present Balance:</span>
                    <span className="text-white font-bold">₹{userCombinedBalance.toFixed(0)}</span>
                  </div>
                  <div className="flex justify-between items-center text-gray-300 border-t border-[#222D4A]/40 pt-2">
                    <span>Entry Fee Deduction:</span>
                    <span className="text-orange-400 font-extrabold">- ₹{currentMatch.entryFee}</span>
                  </div>
                  <div className="flex justify-between items-center text-gray-200 border-t border-[#222D4A]/55 pt-2 font-bold">
                    <span>Final Balance:</span>
                    <span className="text-[#00FFCC] font-black">₹{(userCombinedBalance - currentMatch.entryFee).toFixed(0)}</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3.5 pt-2">
                  <button
                    onClick={() => !isSubmitting && setShowModal('none')}
                    disabled={isSubmitting}
                    className="w-full bg-[#13192B] border border-[#222D4A] text-gray-300 py-3 rounded-xl font-display font-bold text-xs uppercase tracking-wider hover:bg-gray-850 hover:text-white transition-all cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={executeJoinMatch}
                    disabled={isSubmitting}
                    className={`w-full bg-gradient-to-r from-[#FF4500] to-[#C60000] text-white py-3 rounded-xl font-display font-black text-xs uppercase tracking-widest transition-all text-center ${
                      isSubmitting 
                        ? 'opacity-55 cursor-not-allowed border border-[#FF4500]/30' 
                        : 'hover:shadow-[0_0_15px_rgba(255,69,0,0.4)] shadow-md cursor-pointer'
                    }`}
                  >
                    {isSubmitting ? 'Securing Slot...' : 'Confirm Join'}
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* 👥 CUSTOM TEAMMATE RESERVATION MODAL */}
      {showReserveModal && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-fade-in text-white font-sans">
          <div className="bg-[#0D1426] border border-[#222D4A] rounded-2.5xl max-w-sm w-full p-6 shadow-2xl relative overflow-hidden space-y-5 text-left">
            <div className="absolute top-0 right-0 w-32 h-32 bg-[#FF4500]/10 rounded-full blur-2xl pointer-events-none" />
            
            <div className="space-y-1.5">
              <h3 className="text-base font-display font-black text-white uppercase tracking-wider">
                Reserve Teammate Slot
              </h3>
              <p className="text-xs text-gray-305">
                Enter details for your teammate. ₹{currentMatch.entryFee} entry fee will be deducted from your combined balance to lock their space on Team {userSlot?.team === 'A' ? 'ALPHA' : 'BETA'}.
              </p>
            </div>
            
            <div className="space-y-3.5">
              <div className="space-y-1.5">
                <label className="text-[9px] font-mono text-gray-400 uppercase font-black">
                  Teammate In-Game Name (IGN)
                </label>
                <input
                  type="text"
                  placeholder="e.g. SNIPER_PRO_FF"
                  value={teammateIGN}
                  onChange={(e) => setTeammateIGN(e.target.value)}
                  className="w-full bg-[#0A0E17] border border-[#222D4A] rounded-xl px-3.5 py-3 text-xs font-mono font-bold text-white focus:outline-none focus:border-[#FF4500]"
                />
              </div>
              
              <div className="space-y-1.5">
                <label className="text-[9px] font-mono text-gray-400 uppercase font-black">
                  Teammate In-Game Level
                </label>
                <input
                  type="number"
                  placeholder="e.g. 55"
                  value={teammateLevel}
                  onChange={(e) => setTeammateLevel(e.target.value)}
                  className="w-full bg-[#0A0E17] border border-[#222D4A] rounded-xl px-3.5 py-3 text-xs font-mono font-bold text-white focus:outline-none focus:border-[#FF4500]"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                onClick={() => {
                  if (!isSubmitting) {
                    setShowReserveModal(false);
                    setTeammateIGN('');
                    setTeammateLevel('');
                  }
                }}
                disabled={isSubmitting}
                className="w-full bg-[#13192B] border border-[#222D4A] text-gray-300 py-3 rounded-xl font-mono font-bold text-xs uppercase tracking-wider hover:bg-gray-850 hover:text-white transition-all cursor-pointer disabled:opacity-55 disabled:cursor-not-allowed"
              >
                Cancel
              </button>
              <button
                onClick={handleReserveTeammateSlot}
                disabled={isSubmitting}
                className={`w-full bg-gradient-to-r from-[#FF4500] to-[#C60000] text-white py-3 rounded-xl font-mono font-black text-xs uppercase tracking-wider transition-all text-center ${
                  isSubmitting
                    ? 'opacity-55 cursor-not-allowed border border-[#FF4500]/30'
                    : 'hover:shadow-[0_0_12px_rgba(255,69,0,0.3)] shadow-md cursor-pointer'
                }`}
              >
                {isSubmitting ? 'Reserving...' : 'Pay & Reserve'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 🎯 ADMIN REASSIGNMENT NOTIFICATION MODAL */}
      {adminReassignAlert?.show && (
        <div className="fixed inset-0 bg-black/95 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-fade-in text-white font-sans text-left">
          <div className={`border rounded-2.5xl max-w-sm w-full p-6 shadow-2xl relative overflow-hidden space-y-5 ${
            adminReassignAlert.newTeam === 'A'
              ? 'bg-[#150A0D]/95 border-red-500/40 shadow-red-950/20'
              : 'bg-[#0A0D15]/95 border-blue-500/40 shadow-blue-950/20'
          }`}>
            <div className="absolute top-0 right-0 w-32 h-32 bg-[#00FFCC]/5 rounded-full blur-2xl pointer-events-none" />
            
            <div className="text-center space-y-3.5">
              <div className={`mx-auto w-14 h-14 rounded-2xl flex items-center justify-center border animate-pulse ${
                adminReassignAlert.newTeam === 'A'
                  ? 'bg-red-500/10 border-red-500/30 text-red-500'
                  : 'bg-blue-500/10 border-blue-500/30 text-blue-450'
              }`}>
                <ShieldCheck className="w-8 h-8" />
              </div>
              
              <h3 className="text-base font-display font-black text-white uppercase tracking-wider">
                Lineup Deployment Update!
              </h3>
              
              <p className="text-xs text-gray-300 leading-relaxed font-sans max-w-xs mx-auto">
                The tournament Admin has dynamically re-assigned your lobby slot placement! You are officially deployed onto combat duty representation:
              </p>
              
              <div className={`rounded-xl p-4 border text-center font-mono ${
                adminReassignAlert.newTeam === 'A'
                  ? 'bg-red-950/20 border-red-500/20 text-red-400'
                  : 'bg-blue-950/20 border-blue-500/20 text-blue-400'
              }`}>
                <span className="text-[9px] uppercase tracking-widest block text-gray-400 font-bold mb-1 leading-none">
                  Active Combat representation
                </span>
                <span className="text-lg font-black tracking-wide block uppercase leading-none mt-1.5">
                  {adminReassignAlert.newTeam === 'A' ? '🟥 TEAM ALPHA' : '🟦 TEAM BETA'}
                </span>
                <span className="text-[10px] text-gray-200 mt-2 block font-extrabold font-mono">
                  Grid Position: Slot #{adminReassignAlert.newPosition}
                </span>
              </div>
            </div>
            
            <button
              onClick={() => {
                setAdminReassignAlert(null);
              }}
              className={`w-full text-white py-3 rounded-xl font-mono font-black text-xs uppercase tracking-widest transition-all cursor-pointer shadow-md text-center ${
                adminReassignAlert.newTeam === 'A'
                  ? 'bg-gradient-to-r from-[#FF4500] to-[#C60000] hover:shadow-[0_0_12px_rgba(255,69,0,0.3)]'
                  : 'bg-gradient-to-r from-[#00D2FF] to-[#0055C6] hover:shadow-[0_0_12px_rgba(0,210,255,0.3)]'
              }`}
            >
              Ready for Battle, let's rock!
            </button>
          </div>
        </div>
      )}

    </div>
  );
}
