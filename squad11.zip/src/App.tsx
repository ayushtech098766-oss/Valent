import React, { useState, useEffect } from 'react';
import { User, Match } from './types';
import { initializeDB, getCurrentUser, setCurrentUser, isQuotaExceeded, forceSyncAll, getMatches } from './db';
import { getFirestoreConsoleUrl, isConfigured } from './firebase';
import { scrollToTop } from './utils';
import LoginSignup from './components/LoginSignup';
import HomeFeed from './components/HomeFeed';
import MatchWorkspace from './components/MatchWorkspace';
import WalletTab from './components/WalletTab';
import MyJoinedContests from './components/MyJoinedContests';
import AdminPanel from './components/AdminPanel';
import TacticalRadar from './components/TacticalRadar';
import ProfileTab from './components/ProfileTab';
import SquadLogo from './components/SquadLogo';
import {
  Flame,
  Home,
  Trophy,
  Wallet,
  Settings,
  LogOut,
  Sparkles,
  RefreshCw,
  User as UserIcon,
  ShieldAlert,
  ArrowLeft,
} from 'lucide-react';

type Screen = 'lobby' | 'my_contests' | 'wallet' | 'profile' | 'admin';

export default function App() {
  const [userState, setUserState] = useState<User | null>(null);
  const setUser = (u: User | null) => {
    if (u) {
      if (u.phone === '9260914905') {
        u.is_admin = true;
        u.role = 'admin';
      } else {
        if (u.role === 'admin') {
          u.role = 'player';
        }
        if (u.role === 'wallet_manager' || u.role === 'chat_manager') {
          u.is_admin = true;
        } else {
          u.is_admin = false;
        }
      }
    }
    setUserState(u);
  };
  const user = userState;
  const [quotaExceeded, setQuotaExceededState] = useState(isQuotaExceeded());
  
  // Navigation
  const [activeScreen, setActiveScreen] = useState<Screen>('lobby');
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Match interaction
  const [selectedMatch, setSelectedMatch] = useState<Match | null>(null);

  // Grid Assignment Alert modal state
  const [positionAlert, setPositionAlert] = useState<{ matchId: string; title: string; team: string; position: number } | null>(null);

  // Auto-scroll to top when primary screen changes
  useEffect(() => {
    scrollToTop();
  }, [activeScreen, selectedMatch]);


  // Initial database seeding trigger and live coordinate updater
  useEffect(() => {
    initializeDB();
    const activeUser = getCurrentUser();
    if (activeUser) {
      setUser(activeUser);
    }

    const handleDBUpdate = () => {
      const freshUser = getCurrentUser();
      setUser(freshUser);
      setQuotaExceededState(isQuotaExceeded());

      // Grid Assignment Alert Detection logic
      if (freshUser) {
        const allMatches = getMatches();
        const cachedStr = localStorage.getItem('valent_user_assignments');
        const cached = cachedStr ? JSON.parse(cachedStr) : {};
        let cacheChanged = false;
        let alertToSet: any = null;

        allMatches.forEach(m => {
          const pl = m.players.find(p => p.userId === freshUser.id);
          if (pl) {
            const matchId = m.id;
            const currentAlloc = { team: pl.team, position: pl.position || 0 };
            const pastAlloc = cached[matchId];

            if (!pastAlloc) {
              cached[matchId] = currentAlloc;
              cacheChanged = true;
              // Silent baseline on first join - do NOT trigger popup.
            } else if (pastAlloc.team !== currentAlloc.team || pastAlloc.position !== currentAlloc.position) {
              cached[matchId] = currentAlloc;
              cacheChanged = true;
              alertToSet = {
                matchId: m.id,
                title: m.title,
                team: pl.team === 'A' ? 'ALPHA (Team A)' : 'BETA (Team B)',
                position: currentAlloc.position || pl.position || 1
              };
            }
          }
        });

        if (cacheChanged) {
          localStorage.setItem('valent_user_assignments', JSON.stringify(cached));
        }
        if (alertToSet) {
          setPositionAlert(alertToSet);
        }
      }
    };

    window.addEventListener('valent_db_update', handleDBUpdate);
    // Run initially
    handleDBUpdate();

    return () => {
      window.removeEventListener('valent_db_update', handleDBUpdate);
    };
  }, []);

  const handleAuthSuccess = (authenticatedUser: User) => {
    setUser(authenticatedUser);
    setActiveScreen('lobby');
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setUser(null);
    setSelectedMatch(null);
    setActiveScreen('lobby');
  };

  const handleRefreshData = () => {
    setIsRefreshing(true);
    // Reload database updates globally across all components listening to this event helper
    window.dispatchEvent(new Event('valent_db_update'));
    setTimeout(() => {
      setIsRefreshing(false);
    }, 750);
  };

  const navigateToScreen = (screen: Screen) => {
    // Interception guard: if is_admin is false, prevent entering Admin tab manually
    if (screen === 'admin' && (!user || !user.is_admin)) {
      alert('🔒 Access Denied! Tactical Override Intercepted. Player registration permits do not authorize special console access.');
      setActiveScreen('lobby');
      return;
    }
    setSelectedMatch(null); // Clear match views on nav
    setActiveScreen(screen);
  };

  if (!user) {
    return (
      <div className="fixed inset-0 bg-[#0A0E17] flex flex-col items-center justify-start md:justify-center p-4 overflow-y-auto py-8 md:py-12">
        <LoginSignup onAuthSuccess={handleAuthSuccess} />
      </div>
    );
  }

  return (
    <div className="fixed inset-0 md:relative md:min-h-screen md:h-auto bg-[#03060C] font-sans antialiased text-gray-200 selection:bg-[#00FFCC]/30 flex flex-col lg:flex-row items-center justify-center p-0 md:p-6 lg:p-8 xl:p-12 gap-8 overflow-hidden md:overflow-visible">
      
      {/* Handheld Mobile Emulator Frame */}
      <div className="w-full max-w-md bg-[#0A0E17] border-x md:border border-[#222D4A] md:rounded-[40px] shadow-[0_0_80px_rgba(0,0,0,0.85)] h-full md:h-[840px] flex flex-col justify-between relative overflow-hidden shrink-0">
        
        {/* Quota Exceeded Error Warning Banner */}
        {quotaExceeded && (
          <div className="bg-gradient-to-r from-amber-950 to-orange-900 border-b border-orange-500/35 px-4 py-2.5 flex items-start gap-2.5 shrink-0 z-30 shadow-lg select-none">
            <ShieldAlert className="w-4 h-4 text-orange-400 mt-0.5 shrink-0 animate-pulse" />
            <div className="text-[10px] leading-relaxed text-orange-200 flex-1">
              <span className="font-bold text-orange-400 uppercase tracking-wider block mb-0.5 font-mono">⚠️ Free Tier Quota Exceeded</span>
              <span className="block mb-1 text-gray-300">Firestore write quota exceeded. Running gracefully in offline mode: app remains fully functional with local persistence.</span>
              
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1.5 mt-1">
                <button
                  type="button"
                  onClick={async () => {
                    setIsRefreshing(true);
                    await forceSyncAll();
                    setTimeout(() => setIsRefreshing(false), 1000);
                  }}
                  className="bg-orange-800/80 hover:bg-orange-700 hover:text-white text-orange-100 px-2 py-0.5 rounded border border-orange-500/40 text-[9px] font-mono tracking-wide font-extrabold uppercase transition-all flex items-center gap-1 shrink-0 cursor-pointer"
                >
                  {isRefreshing ? 'Syncing...' : '🔄 Retry & Sync Now'}
                </button>
                
                {isConfigured && (
                  <a
                    href={getFirestoreConsoleUrl()}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="font-bold underline text-orange-300 hover:text-orange-100 text-[9px] transition-colors hover:no-underline font-mono"
                  >
                    Manage Firestore Project ID →
                  </a>
                )}
              </div>
            </div>
          </div>
        )}
        


        {/* Global Brand Navigation Header block */}
        <header className="bg-[#111520]/95 backdrop-blur-md border-b border-[#222D4A] px-4 py-3 flex items-center justify-between z-20 shrink-0">
          <div className="flex items-center gap-2">
            {(selectedMatch || activeScreen !== 'lobby') && (
              <button
                type="button"
                onClick={() => {
                  setSelectedMatch(null);
                  setActiveScreen('lobby');
                }}
                className="p-1.5 bg-[#0C1222] hover:bg-[#16213E] border border-[#222D4A] rounded-xl text-gray-400 hover:text-white transition-all cursor-pointer shadow-md flex items-center justify-center mr-1"
                title="Back to Lobby"
              >
                <ArrowLeft className="w-4 h-4 text-[#FF4500]" />
              </button>
            )}
            <div
              className="flex items-center cursor-pointer gap-2"
              onClick={() => {
                setSelectedMatch(null);
                setActiveScreen('lobby');
              }}
            >
              <SquadLogo size="sm" showText={false} />
              <span className="font-display font-black tracking-widest text-white text-xs md:text-sm uppercase shrink-0">
                <span className="text-[#FF0043]">V</span>ALENT LOBBIES
              </span>
            </div>
          </div>

          {/* Sticky Wallet Capsule shown everywhere! */}
          {user && (
            <button
              onClick={() => { setSelectedMatch(null); setActiveScreen('wallet'); }}
              className="flex items-center gap-2 bg-[#0C1222] hover:bg-[#16213E] hover:border-[#FF4500] border-2 border-[#223354] rounded-full px-4 py-2 transition-all cursor-pointer shadow-[0_0_12px_rgba(255,69,0,0.15)] mx-3"
              title="Click to Manage Wallet"
            >
              <div className="w-5 h-5 bg-gradient-to-br from-[#FF4500] to-[#E63900] rounded-full flex items-center justify-center font-display font-black text-white text-xs leading-none shrink-0 shadow-md">
                ₹
              </div>
              <span className="text-xs md:text-sm font-mono font-black text-amber-400 leading-none tracking-wide">
                ₹{(Math.max(0, user.wallet.deposit) + Math.max(0, user.wallet.winnings)).toFixed(0)}
              </span>
              <span className="text-[8.5px] text-[#00FFCC] font-mono leading-none border border-[#00FFCC]/35 px-1.5 py-0.5 rounded bg-[#00FFCC]/10 font-bold uppercase tracking-wider shrink-0">
                WALLET
              </span>
            </button>
          )}

          {/* Refresh/Maintenance actions */}
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={handleRefreshData}
              title="Refresh Live Data"
              className="p-1.5 bg-[#0A0E17]/60 hover:bg-[#13192B] border border-[#222D4A] rounded-lg text-gray-400 hover:text-[#00FFCC] transition-colors"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-[#00FFCC]' : ''}`} />
            </button>
          </div>
        </header>

        {/* Dynamic Body render space */}
        <main className="flex-1 overflow-y-auto min-h-0">
          {selectedMatch ? (
            /* Selected Match Workspace (Room credentials & submissions) */
            <MatchWorkspace
              match={selectedMatch}
              userId={user.id}
              onBack={() => setSelectedMatch(null)}
              onNavigateToWallet={() => {
                setSelectedMatch(null);
                setActiveScreen('wallet');
              }}
            />
          ) : activeScreen === 'lobby' ? (
            /* Lobby Matches List */
            <HomeFeed
              onSelectMatch={(m) => setSelectedMatch(m)}
              onNavigateToWallet={() => setActiveScreen('wallet')}
            />
          ) : activeScreen === 'my_contests' ? (
            /* Users contests joined logs history */
            <MyJoinedContests
              userId={user.id}
              onExploreMatches={() => setActiveScreen('lobby')}
            />
          ) : activeScreen === 'wallet' ? (
            /* Interactive financial gateway tab */
            <WalletTab />
          ) : activeScreen === 'profile' ? (
            /* User profile menu where they edit handle or logo */
            <ProfileTab onLogout={handleLogout} />
          ) : activeScreen === 'admin' && user.is_admin ? (
            /* Master privileged system settings desk */
            <AdminPanel onBackToDashboard={() => setActiveScreen('lobby')} />
          ) : (
            <div className="p-8 text-center bg-red-900/10 border border-red-500/10 rounded-2xl m-4 space-y-3">
              <ShieldAlert className="w-10 h-10 text-red-500 mx-auto" />
              <h3 className="font-display font-bold">Lobby Boundary Alert</h3>
              <p className="text-xs text-gray-400">Tactical override has reset active window parameters.</p>
              <button
                onClick={() => setActiveScreen('lobby')}
                className="px-4 py-2 bg-gradient-to-r from-[#FF4500] to-[#C60000] rounded-xl font-bold text-xs"
              >
                Return to Lobby
              </button>
            </div>
          )}
        </main>

        {/* BOTTOM NAVIGATION FOOTER BAR (Exactly 5 distributed items) */}
        <nav className="absolute bottom-0 left-0 right-0 bg-[#13192B]/95 backdrop-blur-md border-t border-[#222D4A] py-2.5 px-3 flex items-center justify-between z-30 shadow-[0_-10px_35px_rgba(0,0,0,0.85)] shrink-0">
          {/* Nav item 1: [Home] */}
          <button
            onClick={() => navigateToScreen('lobby')}
            id="footer-nav-home"
            className={`flex-1 flex flex-col items-center justify-center py-1 transition-all cursor-pointer ${
              activeScreen === 'lobby' && !selectedMatch ? 'text-[#FF4500]' : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            <Home className="w-5.5 h-5.5 mb-0.5" />
            <span className="text-[11px] font-display font-bold uppercase tracking-wider">Home</span>
          </button>

          {/* Nav item 2: [Contests] */}
          <button
            onClick={() => navigateToScreen('my_contests')}
            id="footer-nav-my-contests"
            className={`flex-1 flex flex-col items-center justify-center py-1 transition-all cursor-pointer ${
              activeScreen === 'my_contests' ? 'text-[#FF4500]' : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            <Trophy className="w-5.5 h-5.5 mb-0.5" />
            <span className="text-[11px] font-display font-bold uppercase tracking-wider">Contests</span>
          </button>

          {/* Nav item 3: [Wallet] */}
          <button
            onClick={() => navigateToScreen('wallet')}
            id="footer-nav-wallet"
            className={`flex-1 flex flex-col items-center justify-center py-1 transition-all cursor-pointer ${
              activeScreen === 'wallet' ? 'text-[#FF4500]' : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            <Wallet className="w-5.5 h-5.5 mb-0.5" />
            <span className="text-[11px] font-display font-bold uppercase tracking-wider">Wallet</span>
          </button>

          {/* Nav item 4: [Profile] */}
          <button
            onClick={() => navigateToScreen('profile')}
            id="footer-nav-profile"
            className={`flex-1 flex flex-col items-center justify-center py-1 transition-all cursor-pointer ${
              activeScreen === 'profile' ? 'text-[#FF4500]' : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            <UserIcon className="w-5.5 h-5.5 mb-0.5" />
            <span className="text-[11px] font-display font-bold uppercase tracking-wider">Profile</span>
          </button>

          {/* Nav item 5: [Admin] (only visible to is_admin === true) */}
          {user.is_admin && (
            <button
              onClick={() => navigateToScreen('admin')}
              id="footer-nav-admin"
              className={`flex-1 flex flex-col items-center justify-center py-1 transition-all cursor-pointer ${
                activeScreen === 'admin' ? 'text-[#00FFCC]' : 'text-gray-400 hover:text-gray-200'
              }`}
            >
              <Settings className="w-5.5 h-5.5 text-[#00FFCC] mb-0.5" />
              <span className="text-[11px] font-display font-bold uppercase tracking-wider text-[#00FFCC]">Console</span>
            </button>
          )}
        </nav>
      </div>

      {/* Grid Allocation Position Alert Modal Overlay */}
      {positionAlert && (
        <div className="fixed inset-0 bg-[#03060C]/90 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fade-in select-none">
          <div className="w-full max-w-sm bg-[#13192B] border border-[#FF4500]/40 rounded-2.5xl p-6 text-center space-y-4 shadow-[0_0_50px_rgba(255,69,0,0.25)]">
            <div className="w-12 h-12 bg-[#FF4500]/10 border border-[#FF4550]/40 rounded-full flex items-center justify-center mx-auto text-[#FF4500]">
              <Trophy className="w-6 h-6 animate-bounce" />
            </div>
            
            <div className="space-y-1">
              <h3 className="font-display font-black text-sm uppercase tracking-wide text-orange-500">🎮 LOBBY GRID SLOT ASSIGNED!</h3>
              <p className="text-[11px] text-gray-400">
                The match coordinator has finalized player layouts for the following contest:
              </p>
              <div className="py-2.5 px-3 bg-[#0A0E17] rounded-xl border border-[#222D4A] mt-2">
                <span className="text-xs font-mono font-extrabold text-white block uppercase truncate mb-1">
                  {positionAlert.title}
                </span>
                <div className="flex justify-center gap-3 text-[10px] font-mono mt-1 pt-1 border-t border-[#222D4A]/50">
                  <span className="text-gray-400">TEAM: <span className="text-[#FF4500] font-bold">{positionAlert.team}</span></span>
                  <span className="text-gray-450">•</span>
                  <span className="text-gray-400">POSITION: <span className="text-[#00FFCC] font-bold">Slot #{positionAlert.position}</span></span>
                </div>
              </div>
            </div>

            <p className="text-[10px] text-gray-500 leading-normal">
              Please join your custom game custom room seat utilizing this exact slot to ensure your score matches the live validation grid coordinates.
            </p>

            <button
              onClick={() => setPositionAlert(null)}
              className="w-full bg-gradient-to-r from-[#FF4500] to-[#C60000] text-white font-display font-black text-xs uppercase tracking-wider py-3 rounded-xl hover:shadow-[0_0_15px_rgba(255,69,0,0.5)] transition-all cursor-pointer"
            >
              Acknowledge Position Coord
            </button>
          </div>
        </div>
      )}

      {/* Right Column: Tactical Radar Side Panel (Hidden on Mobile, Visible on Desktop Layouts) */}
      <div className="hidden lg:flex lg:flex-col lg:w-[480px] lg:h-[840px] shrink-0">
        <TacticalRadar selectedMatch={selectedMatch} isDrafting={false} currentUser={user} />
      </div>

    </div>
  );
}
