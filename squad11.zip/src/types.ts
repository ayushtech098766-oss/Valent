export interface User {
  id: string;
  email: string;
  username: string;
  role: 'admin' | 'player' | 'wallet_manager' | 'chat_manager' | 'rules_manager';
  is_admin: boolean;
  wallet: {
    deposit: number;
    winnings: number;
    bonus: number;
  };
  photoUrl?: string;
  ign?: string; // In-Game Name for FF profile integration
  password?: string;
  pin?: string;
  phone?: string;
  isBanned?: boolean;
  referralCode?: string;
  referredBy?: string; // Referral code entered during signup
  referredByUserId?: string; // User ID of the inviter
  isReferralRewardPaid?: boolean; // Has the inviter been paid ₹25 for this invitee's first game join
  hasJoinedFirstGame?: boolean; // Has this user joined at least one game
}

export type MatchFormat = '1v1' | '2v2' | '4v4' | '6v6' | 'BR' | 'teamvsteam4v4' | 'teamvsteam6v6';
export type MatchStatus = 'PENDING_START' | 'ROOM_READY' | 'DISPUTED' | 'COMPLETED' | 'LIVE';

export interface MatchPlayer {
  userId: string;
  username: string;
  ign: string;
  team: 'A' | 'B';
  status: 'READY' | 'PENDING';
  position?: number; // 1-indexed position/slot within the team (e.g. 1st, 2nd, 3rd, 4th)
  level?: number;     // in-game level submitted during joining
}

export interface MatchSubmission {
  userId: string;
  username: string;
  team: 'A' | 'B';
  screenshotUrl: string; // Base64
  submittedAt: string;
}

export interface MatchChatMsg {
  id: string;
  senderId: string;
  senderName: string;
  text: string;
  timestamp: string;
}

export interface Match {
  id: string;
  title: string;
  mapName: string;
  format_type: MatchFormat;
  entryFee: number;
  prizePool: number;
  spotsTotal: number;
  spotsFilled: number;
  status: MatchStatus;
  roomId?: string;      // Free Fire Custom Room ID
  roomPassword?: string;  // Custom Room Password
  players: MatchPlayer[];
  submissions: MatchSubmission[];
  disputeChat: MatchChatMsg[];
  winningTeam?: 'A' | 'B';
  winnerNote?: string;
  rakePercent?: number; // custom rake percentage (default 10%, now optional)
  perKillEnabled?: boolean; // optional per kill reward toggle
  perKillAmount?: number;   // optional per kill bounty amount
  credentialsRevealTime?: string; // ISO string indicating when Room ID & Password are revealed
  matchStartTime?: string;        // ISO string indicating when the match starting countdown ends
  prizePerPlayer?: number;        // Optional prize per winning player for specific modes
}

export interface Transaction {
  id: string;
  userId: string;
  type: 'deposit' | 'withdrawal' | 'prize' | 'entry_refund';
  amount: number;
  status: 'pending' | 'approved' | 'rejected';
  created_at: string;
  proofImageUrl?: string; // Base64 of payment receipt
  utr?: string;
  upiId?: string;
  bankDetails?: {
    accountNumber: string;
    ifscCode: string;
    holderName: string;
  };
  withdrawSource?: 'winnings' | 'deposit';
  withdrawMethod?: 'upi' | 'bank' | 'googleplay';
  redeemCode?: string;
  matchId?: string;
  matchTitle?: string;
  note?: string;
}

export interface PromoBanner {
  id: string;
  imageUrl: string; 
  title?: string;
  linkUrl?: string;
  active: boolean;
  created_at: string;
}

export interface Player {
  id: string;
  matchId: string;
  name: string;
  team: string;
  role: string;
  credits: number;
  photo?: string;
}

export interface Team {
  id: string;
  userId: string;
  matchId: string;
  name: string;
  playerIds: string[];
  captainId: string;
  viceCaptainId: string;
}

export interface UserContest {
  id: string;
  userId: string;
  contestId: string;
  teamId: string;
  joined_at: string;
}

export interface SupportMessage {
  id: string;
  userId: string;
  username: string;
  senderId: string;
  senderName: string;
  text: string;
  imageUrl?: string;
  timestamp: string;
  readByAdmin: boolean;
  readByUser: boolean;
}


