import { Player } from './types';

/**
 * Helper to compress and resize dynamic user-uploaded image base64 strings
 * using HTML5 Canvas to prevent LocalStorage QuotaExceededError.
 */
export const compressImage = (base64Str: string, maxWidth = 400, maxHeight = 400, quality = 0.6): Promise<string> => {
  return new Promise((resolve) => {
    // If it's already small or empty, or not base64, return immediately
    if (!base64Str || base64Str.length < 30000 || !base64Str.startsWith('data:image/')) {
      resolve(base64Str);
      return;
    }

    const img = new Image();
    img.src = base64Str;
    img.onload = () => {
      let width = img.width;
      let height = img.height;

      // Calculate ratio & new dimensions
      if (width > height) {
        if (width > maxWidth) {
          height = Math.round((height * maxWidth) / width);
          width = maxWidth;
        }
      } else {
        if (height > maxHeight) {
          width = Math.round((width * maxHeight) / height);
          height = maxHeight;
        }
      }

      const canvas = document.createElement("canvas");
      canvas.width = width;
      canvas.height = height;

      const ctx = canvas.getContext("2d");
      if (!ctx) {
        resolve(base64Str);
        return;
      }

      ctx.drawImage(img, 0, 0, width, height);
      // Compress with specified quality as standard jpeg format (much smaller)
      const compressed = canvas.toDataURL("image/jpeg", quality);
      resolve(compressed);
    };

    img.onerror = () => {
      resolve(base64Str);
    };
  });
};

export const calculateContestPayouts = (
  entryFee: number,
  totalEntries: number,
  mode?: 'h2h' | 'mid' | 'mega',
  rakePercent?: number
) => {
  // Fallback to a smart mode based on totalEntries if mode isn't explicitly defined
  const resolvedMode = mode || (totalEntries <= 5 ? 'h2h' : totalEntries <= 20 ? 'mid' : 'mega');

  // Use dynamic platform rake percentage, defaulting to 10%
  const resolvedRakePercent = typeof rakePercent === 'number' ? rakePercent : 10;

  const grossPool = entryFee * totalEntries;
  const platformRake = Math.round(grossPool * (resolvedRakePercent / 100)); // Dynamic Rake
  const netPrizePool = grossPool - platformRake;
  const totalWinnersCount = Math.max(1, Math.floor(totalEntries * 0.30)); 
  let prizeBreakdown: { rank: string; prize: number }[] = [];

  if (resolvedMode === 'h2h' || totalEntries <= 5) {
    prizeBreakdown.push({ rank: "Rank 1", prize: netPrizePool });
  } else if (resolvedMode === 'mid' || totalEntries <= 20) {
    prizeBreakdown.push({ rank: "Rank 1", prize: Math.round(netPrizePool * 0.60) });
    prizeBreakdown.push({ rank: "Rank 2", prize: Math.round(netPrizePool * 0.30) });
    prizeBreakdown.push({ rank: "Rank 3", prize: Math.round(netPrizePool * 0.10) });
  } else if (resolvedMode === 'mega') {
    prizeBreakdown.push({ rank: "Rank 1", prize: Math.round(netPrizePool * 0.40) });
    prizeBreakdown.push({ rank: "Rank 2", prize: Math.round(netPrizePool * 0.20) });
    prizeBreakdown.push({ rank: "Rank 3", prize: Math.round(netPrizePool * 0.10) });
    
    const tier2Pool = Math.round(netPrizePool * 0.15);
    const tier2Winners = Math.min(7, totalWinnersCount - 3);
    if (tier2Winners > 0) {
      const prizePerPerson = Math.round(tier2Pool / tier2Winners);
      prizeBreakdown.push({ rank: "Rank 4-10", prize: prizePerPerson });
    }
    
    const tier3Pool = Math.round(netPrizePool * 0.15);
    const tier3Winners = totalWinnersCount - 3 - tier2Winners;
    if (tier3Winners > 0) {
      const prizePerPerson = Math.round(tier3Pool / tier3Winners);
      prizeBreakdown.push({ rank: `Rank 11-${totalWinnersCount}`, prize: prizePerPerson });
    }
  }

  return {
    rakeAmount: platformRake,
    totalPrizePool: netPrizePool,
    winnersCount: resolvedMode === 'h2h' ? 1 : (resolvedMode === 'mid' ? 3 : totalWinnersCount),
    breakdown: prizeBreakdown
  };
};

/**
 * Parses cleaner rank range lists such as "11-30" or "Rank 1-5" to figure out how many actual winners exist.
 */
export function getWinnersCountFromRankString(rankStr: string): number {
  if (!rankStr) return 1;
  const cleaned = rankStr.toLowerCase().replace(/rank/g, '').replace(/\s+/g, '');
  if (cleaned.includes('-')) {
    const parts = cleaned.split('-');
    const start = parseInt(parts[0]);
    const end = parseInt(parts[1]);
    if (!isNaN(start) && !isNaN(end)) {
      return Math.max(1, end - start + 1);
    }
  }
  const single = parseInt(cleaned);
  if (!isNaN(single)) return 1;
  return 1;
}

/**
 * Calculates the total prize pool based on the custom rank ranges and prize value (each rank receives the prize value).
 */
export function calculateTotalCustomPrizePool(tiers: { rank: string; prize: number }[]): number {
  if (!tiers || tiers.length === 0) return 0;
  return tiers.reduce((sum, tier) => {
    const count = getWinnersCountFromRankString(tier.rank);
    return sum + (count * tier.prize);
  }, 0);
}

/**
 * Universal scroll-to-top handler to ensure screens and sub-screens
 * start at the very top of their contents.
 */
export const scrollToTop = () => {
  if (typeof window !== 'undefined') {
    window.scrollTo({ top: 0, behavior: 'instant' });
    document.querySelectorAll('.overflow-y-auto, main').forEach((el) => {
      el.scrollTop = 0;
    });
  }
};

/**
 * Returns a high-quality stylized cyberpunk/esports avatar image
 * if a custom player photo is loaded, or maps to a unique generated SVG avatar.
 */
export const getPlayerPhoto = (player: Player): string => {
  if (player.photo) return player.photo;

  // Clean initials
  const initials = player.name.replace('EV ', '').replace('FA ', '').substring(0, 3).toUpperCase();
  const themeColor = player.team === 'EV' ? '#FFD700' : '#00FFCC';
  const bgColor = player.team === 'EV' ? '#2A1F0C' : '#0B1C24';
  const visorColor = player.team === 'EV' ? '#FF4500' : '#00D2FF';

  // Return a super styled, high-impact SVG that acts as a real profile photo!
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="100" height="100">
    <defs>
      <linearGradient id="grad-${player.id}" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="${bgColor}" />
        <stop offset="100%" stop-color="#070913" />
      </linearGradient>
    </defs>
    <!-- Background circle -->
    <circle cx="50" cy="50" r="48" fill="url(#grad-${player.id})" stroke="${themeColor}" stroke-width="2" />
    
    <!-- Neck -->
    <path d="M40 75 L60 75 L55 85 L45 85 Z" fill="#1A2D42" opacity="0.8" />
    
    <!-- Helmet or hair outline based on role -->
    ${
      player.role === 'Sniper' 
      ? '<path d="M25 50 C25 25, 75 25, 75 50 C75 58, 65 65, 50 68 C35 65, 25 58, 25 50 Z" fill="#2d3748" />'
      : '<path d="M22 52 C22 20, 78 20, 78 52 C78 60, 68 68, 50 70 C32 68, 22 60, 22 52 Z" fill="#1e293b" />'
    }
    
    <!-- Face plate / visor plate -->
    <path d="M28 46 L72 46 L68 62 L32 62 Z" fill="#0f172a" />
    
    <!-- Team accent highlights -->
    <path d="M30 46 L70 46 L65 50 L35 50 Z" fill="${themeColor}" opacity="0.3" />
    
    <!-- Neon Gaming Goggles / Visor -->
    <polygon points="30,48 70,48 66,56 34,56" fill="${visorColor}" />
    <!-- Visor shine -->
    <polygon points="32,49 48,49 45,52 32,52" fill="#FFFFFF" opacity="0.6" />
    <polygon points="52,49 64,49 62,52 50,52" fill="#FFFFFF" opacity="0.4" />
    
    <!-- Headset -->
    <rect x="15" y="42" width="6" height="16" rx="2" fill="${themeColor}" />
    <rect x="79" y="42" width="6" height="16" rx="2" fill="${themeColor}" />
    <path d="M18 44 C18 18, 82 18, 82 44" fill="none" stroke="${themeColor}" stroke-width="3" opacity="0.7" />
    
    <!-- Initials overlay label -->
    <rect x="25" y="70" width="50" height="15" rx="3" fill="#0A0E17" stroke="${themeColor}" stroke-width="1.5" />
    <text x="50" y="80.5" font-family="system-ui, -apple-system, sans-serif" font-size="8.5" font-weight="bold" fill="#FFFFFF" text-anchor="middle" letter-spacing="0.5">${initials}</text>
  </svg>`;
  
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
};

/**
 * Generates a professional 6-digit uppercase alphanumeric referral code (e.g. VAL29X)
 */
export const generateReferralCode = (): string => {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // Avoid ambiguous letters like O, I, 0, 1
  let code = '';
  for (let i = 0; i < 6; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
};


