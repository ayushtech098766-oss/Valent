import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore, initializeFirestore } from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';

const isConfigured = !!(firebaseConfig && firebaseConfig.projectId && firebaseConfig.projectId !== "");

let app: any = null;
let db: any = null;
let auth: any = null;

if (isConfigured) {
  try {
    app = initializeApp(firebaseConfig);
    // Enable long polling to prevent WebChannel streams from hanging/refusing on cellular mobile or behind iframe/CDN proxies like Netlify
    const firestoreSettings = {
      experimentalAutoDetectLongPolling: true,
    };
    if (firebaseConfig.firestoreDatabaseId && firebaseConfig.firestoreDatabaseId !== "" && firebaseConfig.firestoreDatabaseId !== "(default)") {
      db = initializeFirestore(app, firestoreSettings, firebaseConfig.firestoreDatabaseId);
    } else {
      db = initializeFirestore(app, firestoreSettings);
    }
    auth = getAuth(app);
  } catch (error) {
    console.error("Failed to initialize Firebase:", error);
  }
}

export const getFirestoreConsoleUrl = () => {
  if (!isConfigured || !firebaseConfig) return "";
  const dbId = firebaseConfig.firestoreDatabaseId || '(default)';
  return `https://console.firebase.google.com/project/${firebaseConfig.projectId}/firestore/databases/${dbId}/data?openUpgradeDialog=true`;
};

export { app, db, auth, isConfigured, firebaseConfig };
